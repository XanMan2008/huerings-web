import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.leftyxan.huerings',
  appName: 'Hue Rings',
  webDir: 'dist'
};

export default config;
