import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings, X, ShoppingCart, RotateCcw, HelpCircle, Play, Trophy, Home, Video, FileText, Shield, Mail, Twitter, MessageCircle, Facebook, Instagram, Share2, Star, Lock, AlertCircle, Palette, ChevronDown, Award, Zap, Sun, Moon, Hammer, RefreshCw, PlayCircle, Check, LogIn, LogOut, User as UserIcon, Globe, Loader2, Apple, Hand, ArrowDown, ArrowUp, Cloud } from 'lucide-react';
import { AdMob, BannerAdSize, BannerAdPosition, BannerAdPluginEvents, AdMobBannerSize, RewardAdPluginEvents, AdLoadInfo } from '@capacitor-community/admob';
import { Capacitor } from '@capacitor/core';
import { auth, db, googleProvider, appleProvider, signInWithPopup, signOut, onAuthStateChanged, doc, setDoc, getDoc, collection, query, orderBy, limit, onSnapshot, Timestamp, User } from './firebase';

type ViewState = 'menu' | 'tutorial' | 'game' | 'gameover' | 'settings' | 'achievements' | 'leaderboard';
type Color = 'cyan' | 'pink' | 'lime' | 'amber';
type Size = 'small' | 'medium' | 'large';

interface Ring { id: string; size: Size; color: Color; }
interface Cell { small: Ring | null; medium: Ring | null; large: Ring | null; }
interface QueuePiece { id: string; small: Color | null; medium: Color | null; large: Color | null; }

const GRID_SIZE = 3;
const COLORS: Color[] = ['cyan', 'pink', 'lime'];
const SIZES: Size[] = ['small', 'medium', 'large'];
const COLOR_MAP = { cyan: '#00F3FF', pink: '#FF007F', lime: '#39FF14', amber: '#FFBF00' };
const SIZE_MAP = { small: 12, medium: 26, large: 40 };

const TRACKS = [
  { name: 'Neon Pulse', url: 'https://actions.google.com/sounds/v1/science_fiction/sci_fi_pulse.ogg', theme: 'synthwave' },
  { name: 'Deep Space', url: 'https://actions.google.com/sounds/v1/science_fiction/space_ambience.ogg', theme: 'nebula' },
  { name: 'Techno Core', url: 'https://actions.google.com/sounds/v1/science_fiction/techno_pulse.ogg', theme: 'cyberpunk' },
  { name: 'Cyber Grid', url: 'https://actions.google.com/sounds/v1/science_fiction/cybernetic_pulse.ogg', theme: 'minimalist' },
  { name: 'Future Flow', url: 'https://actions.google.com/sounds/v1/science_fiction/futuristic_pulse.ogg', theme: 'supernova' },
  { name: 'Magma Chamber', url: 'https://actions.google.com/sounds/v1/science_fiction/sci_fi_hum.ogg', theme: 'volcano' },
  { name: 'Abyssal Echo', url: 'https://actions.google.com/sounds/v1/science_fiction/ambient_sci_fi.ogg', theme: 'oceanic' },
  { name: 'Disco Fever', url: 'https://actions.google.com/sounds/v1/science_fiction/techno_pulse.ogg', theme: 'disco_grid' },
  { name: 'Rainbow Road', url: 'https://actions.google.com/sounds/v1/science_fiction/futuristic_pulse.ogg', theme: 'rainbow_rings' },
];

// AdMob Test IDs
const AD_IDS = {
  banner: 'ca-app-pub-6321815770837741/2203571324',
  interstitial: 'ca-app-pub-6321815770837741/3641392020',
  rewarded: 'ca-app-pub-6321815770837741/6283616245'
};

const HeatMeter = ({ combo, progress, activeUnlockables }: { combo: number, progress: number, activeUnlockables: Record<string, boolean> }) => {
  const isHighCombo = combo >= 5;
  const isExtremeCombo = combo >= 10;
  const color = isExtremeCombo ? '#ef4444' : isHighCombo ? '#f59e0b' : '#00f2ff';
  
  return (
    <div className="relative w-full">
      {/* Outer Glow / Aura */}
      {isHighCombo && (
        <motion.div 
          className="absolute -inset-2 rounded-full blur-md z-0"
          animate={{ 
            backgroundColor: color,
            scale: isExtremeCombo ? [1, 1.1, 1] : [1, 1.05, 1],
            opacity: isExtremeCombo ? [0.5, 0.9, 0.5] : [0.3, 0.6, 0.3]
          }}
          transition={{ duration: isExtremeCombo ? 0.3 : 0.6, repeat: Infinity }}
        />
      )}

      {/* Main Bar Container */}
      <motion.div 
        className={`relative w-full h-3 rounded-full overflow-hidden border z-10 ${activeUnlockables.light_theme ? 'bg-slate-900/10 border-slate-900/10' : 'bg-black/60 border-white/20 backdrop-blur-md'}`}
        animate={isHighCombo ? {
          x: isExtremeCombo ? [-2, 2, -2, 2, 0] : [-1, 1, -1, 1, 0],
          y: isExtremeCombo ? [-2, 2, 2, -2, 0] : [-1, 1, 1, -1, 0],
          rotate: isExtremeCombo ? [-0.5, 0.5, -0.5, 0.5, 0] : 0
        } : {}}
        transition={{ duration: 0.15, repeat: Infinity, repeatType: 'mirror' }}
      >
        <motion.div 
          className="absolute inset-y-0 left-0 bg-gradient-to-r from-[#00f2ff] via-[#ff007f] to-[#39FF14]"
          initial={{ width: 0 }}
          animate={{ width: `${progress * 100}%` }}
          transition={{ type: 'spring', damping: 20, stiffness: 100 }}
        />
        
        {/* Heat Glow Inside */}
        <motion.div 
          className="absolute inset-0 pointer-events-none mix-blend-overlay"
          animate={{ 
            boxShadow: isHighCombo ? `inset 0 0 20px ${color}` : 'none',
            backgroundColor: isExtremeCombo ? 'rgba(239, 68, 68, 0.5)' : (isHighCombo ? 'rgba(245, 158, 11, 0.2)' : 'transparent')
          }}
        />
      </motion.div>

      {/* Sparks flying outside */}
      {isHighCombo && (
        <div className="absolute inset-0 pointer-events-none z-20">
          {[...Array(Math.min(combo * 3, 40))].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1.5 h-1.5 rounded-full"
              style={{ backgroundColor: i % 3 === 0 ? '#facc15' : (i % 3 === 1 ? '#ef4444' : '#ffffff') }}
              initial={{ left: `${progress * 100}%`, top: '50%', opacity: 1, scale: 1 }}
              animate={{ 
                x: [0, (Math.random() - 0.5) * 150],
                y: [0, (Math.random() - 0.5) * 150],
                opacity: [1, 0],
                scale: [1, 0],
                rotate: [0, 360]
              }}
              transition={{ 
                duration: 0.3 + Math.random() * 0.5, 
                repeat: Infinity,
                delay: Math.random() * 0.5
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const ParticleSystem = React.forwardRef((props, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particles = useRef<any[]>([]);
  const requestRef = useRef<number>(null);

  const createParticles = (x: number, y: number, color: string, count: number = 20) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 8 + 2;
      particles.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: Math.random() * 5 + 2,
        color,
        life: 1.0,
        decay: Math.random() * 0.015 + 0.005,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.2,
        type: Math.random() > 0.7 ? 'square' : 'circle'
      });
    }
  };

  React.useImperativeHandle(ref, () => ({
    trigger: (x: number, y: number, color: string, count?: number) => {
      createParticles(x, y, color, count);
    }
  }));

  const animate = (time: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let i = particles.current.length - 1; i >= 0; i--) {
      const p = particles.current[i];
      
      // Physics
      p.vx *= 0.96; // friction
      p.vy *= 0.96; // friction
      p.vy += 0.15; // gravity
      
      p.x += p.vx;
      p.y += p.vy;
      p.life -= p.decay;
      p.rotation += p.rotationSpeed;

      if (p.life <= 0) {
        particles.current.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      ctx.shadowBlur = 15 * p.life;
      ctx.shadowColor = p.color;
      
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);
      
      if (p.type === 'square') {
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
        ctx.fill();
      }
      
      ctx.restore();
    }

    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-[60]"
      style={{ mixBlendMode: 'screen' }}
    />
  );
});

const getThemeColor = (color: Color, activeUnlockables: Record<string, boolean> = {}) => {
  if (activeUnlockables.volcano) {
    const map = { cyan: '#ff4500', pink: '#ffffff', lime: '#ffff00', amber: '#8b0000' };
    return map[color] || COLOR_MAP[color];
  }
  if (activeUnlockables.oceanic) {
    const map = { cyan: '#00ffff', pink: '#008b8b', lime: '#00ced1', amber: '#1e90ff' };
    return map[color] || COLOR_MAP[color];
  }
  if (activeUnlockables.synthwave) {
    const map = { cyan: '#00f2ff', pink: '#ff007f', lime: '#7b00ff', amber: '#ff7700' };
    return map[color] || COLOR_MAP[color];
  }
  if (activeUnlockables.nebula) {
    const map = { cyan: '#00ffff', pink: '#ff00ff', lime: '#9400d3', amber: '#4b0082' };
    return map[color] || COLOR_MAP[color];
  }
  if (activeUnlockables.cyberpunk) {
    const map = { cyan: '#39ff14', pink: '#ff003c', lime: '#f3f315', amber: '#00f2ff' };
    return map[color] || COLOR_MAP[color];
  }
  return COLOR_MAP[color];
};

const triggerHaptic = (enabled: boolean, pattern: number | number[] = 10) => {
  if (enabled && typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
    window.navigator.vibrate(pattern);
  }
};

type Difficulty = 'easy' | 'medium' | 'hard';

type Achievement = {
  id: string;
  title: string;
  description: string;
  icon: string;
  difficulty: Difficulty;
  target?: number;
  statKey?: keyof GameStats | 'score' | 'combo';
};

const ACHIEVEMENTS: Achievement[] = [
  // Easy (16)
  { id: 'score_1k', title: 'Getting Started', description: 'Score 1,000 points', icon: '🌟', difficulty: 'easy', target: 1000, statKey: 'score' },
  { id: 'score_5k', title: 'Warming Up', description: 'Score 5,000 points', icon: '⭐', difficulty: 'easy', target: 5000, statKey: 'score' },
  { id: 'score_10k', title: 'High Roller', description: 'Score 10,000 points', icon: '💰', difficulty: 'easy', target: 10000, statKey: 'score' },
  { id: 'combo_2', title: 'Double Trouble', description: 'Reach a 2x Combo', icon: '✌️', difficulty: 'easy', target: 2, statKey: 'combo' },
  { id: 'combo_3', title: 'Triple Threat', description: 'Reach a 3x Combo', icon: '🔥', difficulty: 'easy', target: 3, statKey: 'combo' },
  { id: 'combo_4', title: 'Quadruple', description: 'Reach a 4x Combo', icon: '✨', difficulty: 'easy', target: 4, statKey: 'combo' },
  { id: 'combo_5', title: 'Combo Master', description: 'Reach a 5x Combo', icon: '☄️', difficulty: 'easy', target: 5, statKey: 'combo' },
  { id: 'play_1', title: 'First Blood', description: 'Play your first game', icon: '🎮', difficulty: 'easy', target: 1, statKey: 'gamesPlayed' },
  { id: 'play_5', title: 'Regular', description: 'Play 5 games', icon: '🎲', difficulty: 'easy', target: 5, statKey: 'gamesPlayed' },
  { id: 'place_10', title: 'Ring Bearer', description: 'Place 10 rings', icon: '⭕', difficulty: 'easy', target: 10, statKey: 'ringsPlaced' },
  { id: 'place_50', title: 'Ring Collector', description: 'Place 50 rings', icon: '💍', difficulty: 'easy', target: 50, statKey: 'ringsPlaced' },
  { id: 'clear_1', title: 'First Match', description: 'Clear your first line', icon: '💥', difficulty: 'easy', target: 1, statKey: 'linesCleared' },
  { id: 'clear_10', title: 'Line Sweeper', description: 'Clear 10 lines', icon: '🧹', difficulty: 'easy', target: 10, statKey: 'linesCleared' },
  { id: 'hint_1', title: 'Need a Hand?', description: 'Use your first hint', icon: '💡', difficulty: 'easy', target: 1, statKey: 'hintsUsed' },
  { id: 'crit_1', title: 'Critical Hit!', description: 'Land your first critical hit', icon: '🎯', difficulty: 'easy', target: 1, statKey: 'critsLanded' },
  { id: 'score_first', title: 'First Points', description: 'Score your first points', icon: '🔰', difficulty: 'easy', target: 1, statKey: 'score' },

  // Medium (17)
  { id: 'score_25k', title: 'Rising Star', description: 'Score 25,000 points', icon: '🌠', difficulty: 'medium', target: 25000, statKey: 'score' },
  { id: 'score_50k', title: 'Ring Lord', description: 'Score 50,000 points', icon: '👑', difficulty: 'medium', target: 50000, statKey: 'score' },
  { id: 'score_75k', title: 'Expert', description: 'Score 75,000 points', icon: '🏅', difficulty: 'medium', target: 75000, statKey: 'score' },
  { id: 'score_100k', title: 'Centurion', description: 'Score 100,000 points', icon: '💯', difficulty: 'medium', target: 100000, statKey: 'score' },
  { id: 'combo_6', title: 'Hexakill', description: 'Reach a 6x Combo', icon: '🔮', difficulty: 'medium', target: 6, statKey: 'combo' },
  { id: 'combo_7', title: 'Lucky Seven', description: 'Reach a 7x Combo', icon: '🎰', difficulty: 'medium', target: 7, statKey: 'combo' },
  { id: 'combo_8', title: 'Octopus', description: 'Reach an 8x Combo', icon: '🐙', difficulty: 'medium', target: 8, statKey: 'combo' },
  { id: 'combo_9', title: 'Cloud Nine', description: 'Reach a 9x Combo', icon: '☁️', difficulty: 'medium', target: 9, statKey: 'combo' },
  { id: 'combo_10', title: 'Unstoppable', description: 'Reach a 10x Combo', icon: '⚡', difficulty: 'medium', target: 10, statKey: 'combo' },
  { id: 'play_10', title: 'Enthusiast', description: 'Play 10 games', icon: '🕹️', difficulty: 'medium', target: 10, statKey: 'gamesPlayed' },
  { id: 'play_25', title: 'Addicted', description: 'Play 25 games', icon: '😵', difficulty: 'medium', target: 25, statKey: 'gamesPlayed' },
  { id: 'place_100', title: 'Jeweler', description: 'Place 100 rings', icon: '💎', difficulty: 'medium', target: 100, statKey: 'ringsPlaced' },
  { id: 'place_500', title: 'Hoarder', description: 'Place 500 rings', icon: '📦', difficulty: 'medium', target: 500, statKey: 'ringsPlaced' },
  { id: 'clear_50', title: 'Eraser', description: 'Clear 50 lines', icon: '🧽', difficulty: 'medium', target: 50, statKey: 'linesCleared' },
  { id: 'clear_100', title: 'Bulldozer', description: 'Clear 100 lines', icon: '🚜', difficulty: 'medium', target: 100, statKey: 'linesCleared' },
  { id: 'hint_5', title: 'Strategist', description: 'Use 5 hints', icon: '🧠', difficulty: 'medium', target: 5, statKey: 'hintsUsed' },
  { id: 'crit_10', title: 'Sharpshooter', description: 'Land 10 critical hits', icon: '🏹', difficulty: 'medium', target: 10, statKey: 'critsLanded' },

  // Hard (17)
  { id: 'score_150k', title: 'Legend', description: 'Score 150,000 points', icon: '🐉', difficulty: 'hard', target: 150000, statKey: 'score' },
  { id: 'score_200k', title: 'Mythic', description: 'Score 200,000 points', icon: '🦄', difficulty: 'hard', target: 200000, statKey: 'score' },
  { id: 'score_250k', title: 'Quarter Million', description: 'Score 250,000 points', icon: '🏦', difficulty: 'hard', target: 250000, statKey: 'score' },
  { id: 'score_500k', title: 'Half Million', description: 'Score 500,000 points', icon: '🏰', difficulty: 'hard', target: 500000, statKey: 'score' },
  { id: 'score_750k', title: 'Diamond Hands', description: 'Score 750,000 points', icon: '💎', difficulty: 'hard', target: 750000, statKey: 'score' },
  { id: 'score_1m', title: 'Millionaire', description: 'Score 1,000,000 points', icon: '🤑', difficulty: 'hard', target: 1000000, statKey: 'score' },
  { id: 'combo_12', title: 'Dozen', description: 'Reach a 12x Combo', icon: '🍩', difficulty: 'hard', target: 12, statKey: 'combo' },
  { id: 'combo_15', title: 'Godlike', description: 'Reach a 15x Combo', icon: '👼', difficulty: 'hard', target: 15, statKey: 'combo' },
  { id: 'combo_20', title: 'Transcendent', description: 'Reach a 20x Combo', icon: '🌌', difficulty: 'hard', target: 20, statKey: 'combo' },
  { id: 'play_50', title: 'Veteran', description: 'Play 50 games', icon: '🎖️', difficulty: 'hard', target: 50, statKey: 'gamesPlayed' },
  { id: 'place_1000', title: 'Lord of the Rings', description: 'Place 1000 rings', icon: '🌋', difficulty: 'hard', target: 1000, statKey: 'ringsPlaced' },
  { id: 'clear_500', title: 'Annihilator', description: 'Clear 500 lines', icon: '💣', difficulty: 'hard', target: 500, statKey: 'linesCleared' },
  { id: 'hint_10', title: 'Mastermind', description: 'Use 10 hints', icon: '👁️', difficulty: 'hard', target: 10, statKey: 'hintsUsed' },
  { id: 'crit_50', title: 'Assassin', description: 'Land 50 critical hits', icon: '🗡️', difficulty: 'hard', target: 50, statKey: 'critsLanded' },
  { id: 'megacrit_1', title: 'Mega Crit', description: 'Land a Mega Critical Hit', icon: '💥', difficulty: 'hard', target: 1, statKey: 'megaCritsLanded' },
  { id: 'megacrit_5', title: 'Devastator', description: 'Land 5 Mega Critical Hits', icon: '🌋', difficulty: 'hard', target: 5, statKey: 'megaCritsLanded' },
  { id: 'perfect_clear', title: 'Clean Slate', description: 'Clear the entire board', icon: '🧼', difficulty: 'hard', target: 1, statKey: 'perfectClears' },
  { id: 'score_2m', title: 'Multi-Millionaire', description: 'Score 2,000,000 points', icon: '💎', difficulty: 'hard', target: 2000000, statKey: 'score' },
  { id: 'combo_25', title: 'Zenith', description: 'Reach a 25x Combo', icon: '🌌', difficulty: 'hard', target: 25, statKey: 'combo' },
  { id: 'place_5000', title: 'Ring Emperor', description: 'Place 5,000 rings', icon: '👑', difficulty: 'hard', target: 5000, statKey: 'ringsPlaced' },
  { id: 'clear_1000', title: 'World Eater', description: 'Clear 1,000 lines', icon: '🌍', difficulty: 'hard', target: 1000, statKey: 'linesCleared' },
  { id: 'perfect_clear_5', title: 'Clean Freak', description: 'Clear the entire board 5 times', icon: '✨', difficulty: 'hard', target: 5, statKey: 'perfectClears' },
  { id: 'play_100', title: 'Legendary Player', description: 'Play 100 games', icon: '🏆', difficulty: 'hard', target: 100, statKey: 'gamesPlayed' },
  { id: 'crit_100', title: 'Deadeye', description: 'Land 100 critical hits', icon: '🎯', difficulty: 'hard', target: 100, statKey: 'critsLanded' },
  { id: 'megacrit_10', title: 'Cataclysm', description: 'Land 10 Mega Critical Hits', icon: '☄️', difficulty: 'hard', target: 10, statKey: 'megaCritsLanded' },
];

type UnlockableType = 'theme' | 'style' | 'effect' | 'mode';

interface Unlockable {
  id: string;
  name: string;
  description: string;
  type: UnlockableType;
  conditionText: string;
  checkUnlock: (achievements: string[]) => boolean;
  getProgress: (achievements: string[], stats: GameStats, score: number, highScore: number, combo: number) => { current: number, total: number };
}

const UNLOCKABLES: Unlockable[] = [
  { 
    id: 'neon_trails', 
    name: 'Neon Trails', 
    description: 'Pieces glow while dragging', 
    type: 'effect', 
    conditionText: 'Unlock 5 Easy Achievements', 
    checkUnlock: (achs) => achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'easy').length >= 5,
    getProgress: (achs) => ({ 
      current: achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'easy').length, 
      total: 5 
    })
  },
  { 
    id: 'synthwave', 
    name: 'Synthwave Theme', 
    description: 'Retro 80s background', 
    type: 'theme', 
    conditionText: 'Unlock ALL Easy Achievements', 
    checkUnlock: (achs) => achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'easy').length >= 16,
    getProgress: (achs) => ({ 
      current: achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'easy').length, 
      total: 16 
    })
  },
  { 
    id: 'zen_mode', 
    name: 'Zen Mode', 
    description: 'No game over, infinite retries', 
    type: 'mode', 
    conditionText: 'Unlock 10 Medium Achievements', 
    checkUnlock: (achs) => achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'medium').length >= 10,
    getProgress: (achs) => ({ 
      current: achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'medium').length, 
      total: 10 
    })
  },
  { 
    id: 'time_attack', 
    name: 'Time Attack', 
    description: '3-minute speedrun mode', 
    type: 'mode', 
    conditionText: 'Unlock 5 Hard Achievements', 
    checkUnlock: (achs) => achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'hard').length >= 5,
    getProgress: (achs) => ({ 
      current: achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'hard').length, 
      total: 5 
    })
  },
  { 
    id: 'god_mode', 
    name: 'God Mode', 
    description: 'Free hints and infinite retries', 
    type: 'mode', 
    conditionText: 'Unlock ALL Hard Achievements', 
    checkUnlock: (achs) => achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'hard').length >= 17,
    getProgress: (achs) => ({ 
      current: achs.filter(a => ACHIEVEMENTS.find(x => x.id === a)?.difficulty === 'hard').length, 
      total: 17 
    })
  },
  { 
    id: 'combo_rush', 
    name: 'Combo Rush', 
    description: '10s timer for combo meter + 2.5x Combo Points!', 
    type: 'mode', 
    conditionText: 'Unlocked by Default', 
    checkUnlock: () => true,
    getProgress: () => ({ current: 1, total: 1 })
  },
  { 
    id: 'explosive_clears', 
    name: 'Explosive Clears', 
    description: 'Massive screen shake on clears', 
    type: 'effect', 
    conditionText: 'Unlock "Bulldozer" (Clear 100 lines)', 
    checkUnlock: (achs) => achs.includes('clear_100'),
    getProgress: (_, stats) => ({ 
      current: stats.linesCleared, 
      total: 100 
    })
  },
  { 
    id: 'disco_grid', 
    name: 'Disco Theme', 
    description: 'Grid pulses with rainbow colors', 
    type: 'theme', 
    conditionText: 'Unlock "Unstoppable" (10x Combo)', 
    checkUnlock: (achs) => achs.includes('combo_10'),
    getProgress: (_, stats) => ({ 
      current: stats.highestCombo || 0, 
      total: 10 
    })
  },
  { 
    id: 'rainbow_rings', 
    name: 'Rainbow Theme', 
    description: 'The whole world is a rainbow!', 
    type: 'theme', 
    conditionText: 'Unlock "Godlike" (15x Combo)', 
    checkUnlock: (achs) => achs.includes('combo_15'),
    getProgress: (_, stats) => ({ 
      current: stats.highestCombo || 0, 
      total: 15 
    })
  },
  { 
    id: 'cyberpunk', 
    name: 'Cyberpunk Theme', 
    description: 'Dark neon city vibes', 
    type: 'theme', 
    conditionText: 'Unlock "Millionaire" (1M Points)', 
    checkUnlock: (achs) => achs.includes('score_1m'),
    getProgress: (_, __, ___, highScore) => ({ 
      current: highScore || 0, 
      total: 1000000 
    })
  },
  { 
    id: 'minimalist', 
    name: 'Minimalist Theme', 
    description: 'Clean white and gray aesthetic', 
    type: 'theme', 
    conditionText: 'Unlock "Clean Slate" (Perfect Clear)', 
    checkUnlock: (achs) => achs.includes('perfect_clear'),
    getProgress: (_, stats) => ({ 
      current: stats.perfectClears, 
      total: 1 
    })
  },
  { 
    id: 'oceanic', 
    name: 'Oceanic Theme', 
    description: 'Deep blue and teal colors', 
    type: 'theme', 
    conditionText: 'Unlock "Lord of the Rings" (1000 Rings)', 
    checkUnlock: (achs) => achs.includes('place_1000'),
    getProgress: (_, stats) => ({ 
      current: stats.ringsPlaced, 
      total: 1000 
    })
  },
  { 
    id: 'volcano', 
    name: 'Volcano Theme', 
    description: 'Red and orange lava vibes', 
    type: 'theme', 
    conditionText: 'Unlock "Annihilator" (500 Lines)', 
    checkUnlock: (achs) => achs.includes('clear_500'),
    getProgress: (_, stats) => ({ 
      current: stats.linesCleared, 
      total: 500 
    })
  },
  { 
    id: 'nebula', 
    name: 'Nebula Theme', 
    description: 'Cosmic purple and blue background', 
    type: 'theme', 
    conditionText: 'Unlock "Transcendent" (20x Combo)', 
    checkUnlock: (achs) => achs.includes('combo_20'),
    getProgress: (_, stats) => ({ 
      current: stats.highestCombo || 0, 
      total: 20 
    })
  },
  {
    id: 'light_theme',
    name: 'Light Mode',
    description: 'Clean light interface',
    type: 'style',
    conditionText: 'Unlocked by Default',
    checkUnlock: () => true,
    getProgress: () => ({
      current: 1,
      total: 1
    })
  },
  {
    id: 'skin_chrome',
    name: 'Chrome Skin',
    description: 'Metallic reflective rings',
    type: 'style',
    conditionText: 'Reach a 5x Combo',
    checkUnlock: (achs) => achs.includes('combo_5'),
    getProgress: (_, stats) => ({ current: stats.highestCombo || 0, total: 5 })
  },
  {
    id: 'skin_glass',
    name: 'Glass Skin',
    description: 'Translucent frosted rings',
    type: 'style',
    conditionText: 'Score 10,000 Points',
    checkUnlock: (achs) => achs.includes('score_10k'),
    getProgress: (_, __, ___, highScore) => ({ current: highScore || 0, total: 10000 })
  },
  {
    id: 'skin_carbon',
    name: 'Carbon Fiber',
    description: 'High-tech weave texture',
    type: 'style',
    conditionText: 'Place 500 Rings',
    checkUnlock: (achs) => achs.includes('place_500'),
    getProgress: (_, stats) => ({ current: stats.ringsPlaced, total: 500 })
  },
  {
    id: 'skin_glow',
    name: 'Glow-in-the-dark',
    description: 'Rings emit a powerful aura',
    type: 'style',
    conditionText: 'Reach a 15x Combo',
    checkUnlock: (achs) => achs.includes('combo_15'),
    getProgress: (_, stats) => ({ current: stats.highestCombo || 0, total: 15 })
  },
  {
    id: 'bg_supernova',
    name: 'Supernova',
    description: 'Cosmic explosion effect on high combos',
    type: 'effect',
    conditionText: 'Reach a 25x Combo',
    checkUnlock: (achs) => achs.includes('combo_25'),
    getProgress: (_, stats) => ({ current: stats.highestCombo || 0, total: 25 })
  },
];

function canPlace(piece: QueuePiece, cell: Cell): boolean {
  if (piece.small && cell.small) return false;
  if (piece.medium && cell.medium) return false;
  if (piece.large && cell.large) return false;
  return true;
}

function generateHelpfulQueue(grid: Cell[][]): QueuePiece[] {
  const queue: QueuePiece[] = [];
  const missing: { size: Size, color: Color, weight: number }[] = [];

  // Calculate board fullness
  let filledCount = 0;
  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      if (grid[r][c].small) filledCount++;
      if (grid[r][c].medium) filledCount++;
      if (grid[r][c].large) filledCount++;
    }
  }
  const fullness = filledCount / (GRID_SIZE * GRID_SIZE * 3);

  // 1. Cell near-matches (2/3 same color in one cell)
  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      const cell = grid[r][c];
      const rings = [
        { size: 'small' as Size, ring: cell.small },
        { size: 'medium' as Size, ring: cell.medium },
        { size: 'large' as Size, ring: cell.large }
      ];
      const filled = rings.filter(r => r.ring !== null);
      const empty = rings.filter(r => r.ring === null);
      if (filled.length === 2 && filled[0].ring!.color === filled[1].ring!.color && empty.length === 1) {
        missing.push({ size: empty[0].size, color: filled[0].ring!.color, weight: 3 });
      }
    }
  }

  // 2. Line near-matches (2/3 same color and size in a line)
  const lines = [
    [[0,0], [0,1], [0,2]], [[1,0], [1,1], [1,2]], [[2,0], [2,1], [2,2]], // Rows
    [[0,0], [1,0], [2,0]], [[0,1], [1,1], [2,1]], [[0,2], [1,2], [2,2]], // Cols
    [[0,0], [1,1], [2,2]], [[0,2], [1,1], [2,0]] // Diags
  ];

  for (const size of SIZES) {
    for (const line of lines) {
      const cells = line.map(([r, c]) => grid[r][c][size]);
      const filled = cells.filter(c => c !== null);
      const emptyIdx = cells.findIndex(c => c === null);
      if (filled.length === 2 && filled[0]!.color === filled[1]!.color && emptyIdx !== -1) {
        missing.push({ size, color: filled[0]!.color, weight: 2 });
      }
    }
  }

  // Sort by weight (higher weight = more helpful)
  missing.sort((a, b) => b.weight - a.weight);
  
  // Determine how many helpful pieces to give
  // If board is full, give more help.
  let numHelpful = 1;
  if (fullness > 0.6) numHelpful = 2;
  if (fullness > 0.8) numHelpful = 3;
  
  numHelpful = Math.min(numHelpful, missing.length);

  for (let i = 0; i < numHelpful; i++) {
    const match = missing[i];
    const piece: QueuePiece = { id: Math.random().toString(), small: null, medium: null, large: null };
    piece[match.size] = match.color;
    
    // Occasionally add a second ring to the helpful piece
    if (Math.random() > 0.7 && fullness < 0.7) {
      const otherSizes = SIZES.filter(s => s !== match.size);
      const extraSize = otherSizes[Math.floor(Math.random() * otherSizes.length)];
      piece[extraSize] = COLORS[Math.floor(Math.random() * COLORS.length)];
      
      // Ensure it's still placeable somewhere
      let placeable = false;
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (canPlace(piece, grid[r][c])) { placeable = true; break; }
        }
        if (placeable) break;
      }
      if (!placeable) piece[extraSize] = null;
    }
    queue.push(piece);
  }

  // Fill remaining slots with random but placeable pieces
  while (queue.length < 3) {
    const piece: QueuePiece = { id: Math.random().toString(), small: null, medium: null, large: null };
    const numRings = Math.random() > 0.9 ? 2 : 1;
    
    let placeable = false;
    let attempts = 0;
    
    while (!placeable && attempts < 20) {
      attempts++;
      piece.small = null; piece.medium = null; piece.large = null;
      const availableSizes = [...SIZES];
      for (let j = 0; j < numRings; j++) {
        const sizeIndex = Math.floor(Math.random() * availableSizes.length);
        const size = availableSizes.splice(sizeIndex, 1)[0];
        piece[size] = COLORS[Math.floor(Math.random() * COLORS.length)];
      }
      
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (canPlace(piece, grid[r][c])) { placeable = true; break; }
        }
        if (placeable) break;
      }
    }
    queue.push(piece);
  }

  // Shuffle the queue so the helpful piece isn't always in the same spot
  return queue.sort(() => Math.random() - 0.5);
}

function checkGameOver(grid: Cell[][], queue: (QueuePiece | null)[]): boolean {
  const activePieces = queue.filter(p => p !== null) as QueuePiece[];
  if (activePieces.length === 0) return false;
  for (const piece of activePieces) {
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        if (canPlace(piece, grid[r][c])) return false;
      }
    }
  }
  return true;
}

function checkMatches(grid: Cell[][]): { grid: Cell[][], matchCount: number, matchColors: Color[], clearedRings: { r: number, c: number, color: Color }[] } {
  let newGrid = JSON.parse(JSON.stringify(grid));
  let matchCount = 0;
  let matchColors: Color[] = [];
  let ringsToRemove: { r: number, c: number, size: Size, color: Color }[] = [];

  // 1. Same-cell full stack match
  for (let r = 0; r < GRID_SIZE; r++) {
    for (let c = 0; c < GRID_SIZE; c++) {
      const cell = newGrid[r][c];
      if (cell.small && cell.medium && cell.large) {
        if (cell.small.color === cell.medium.color && cell.medium.color === cell.large.color) {
          ringsToRemove.push(
            { r, c, size: 'small', color: cell.small.color },
            { r, c, size: 'medium', color: cell.medium.color },
            { r, c, size: 'large', color: cell.large.color }
          );
          matchCount++;
          matchColors.push(cell.small.color);
        }
      }
    }
  }

  // 2. Line matches (Same size, same color)
  const checkLine = (r1: number, c1: number, r2: number, c2: number, r3: number, c3: number, size: Size) => {
    const cell1 = newGrid[r1][c1][size];
    const cell2 = newGrid[r2][c2][size];
    const cell3 = newGrid[r3][c3][size];
    if (cell1 && cell2 && cell3 && cell1.color === cell2.color && cell2.color === cell3.color) {
      ringsToRemove.push(
        { r: r1, c: c1, size, color: cell1.color },
        { r: r2, c: c2, size, color: cell2.color },
        { r: r3, c: c3, size, color: cell3.color }
      );
      matchCount++;
      matchColors.push(cell1.color);
    }
  };

  for (const size of SIZES) {
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c <= GRID_SIZE - 3; c++) checkLine(r, c, r, c+1, r, c+2, size);
    }
    for (let c = 0; c < GRID_SIZE; c++) {
      for (let r = 0; r <= GRID_SIZE - 3; r++) checkLine(r, c, r+1, c, r+2, c, size);
    }
    for (let r = 0; r <= GRID_SIZE - 3; r++) {
      for (let c = 0; c <= GRID_SIZE - 3; c++) checkLine(r, c, r+1, c+1, r+2, c+2, size);
    }
    for (let r = 0; r <= GRID_SIZE - 3; r++) {
      for (let c = 2; c < GRID_SIZE; c++) checkLine(r, c, r+1, c-1, r+2, c-2, size);
    }
  }

  if (ringsToRemove.length > 0) {
    // Use a Set to avoid removing the same ring twice if it's part of multiple matches
    const seen = new Set<string>();
    const uniqueRingsToRemove: { r: number, c: number, size: Size, color: Color }[] = [];
    
    ringsToRemove.forEach(ring => {
      const key = `${ring.r}-${ring.c}-${ring.size}`;
      if (!seen.has(key)) {
        seen.add(key);
        uniqueRingsToRemove.push(ring);
        newGrid[ring.r][ring.c][ring.size] = null;
      }
    });

    return { 
      grid: newGrid, 
      matchCount, 
      matchColors: Array.from(new Set(matchColors)), 
      clearedRings: uniqueRingsToRemove.map(({ r, c, color }) => ({ r, c, color }))
    };
  }

  return { grid: newGrid, matchCount: 0, matchColors: [], clearedRings: [] };
}

const RingSvg = ({ size, color, className = '', activeUnlockables = {}, isDragging = false, opacity = 1 }: { size: Size, color: Color, className?: string, activeUnlockables?: Record<string, boolean>, isDragging?: boolean, opacity?: number }) => {
  const isRainbow = activeUnlockables.rainbow_rings;
  const isVolcano = activeUnlockables.volcano;
  const isOceanic = activeUnlockables.oceanic;
  const isSynthwave = activeUnlockables.synthwave;
  const isNebula = activeUnlockables.nebula;
  const isCyberpunk = activeUnlockables.cyberpunk;
  const isMinimalist = activeUnlockables.minimalist;
  const isDisco = activeUnlockables.disco_grid;
  
  // New Skins
  const isChrome = activeUnlockables.skin_chrome;
  const isGlass = activeUnlockables.skin_glass;
  const isCarbon = activeUnlockables.skin_carbon;
  const isGlow = activeUnlockables.skin_glow;
  
  const strokeColor = getThemeColor(color, activeUnlockables);
  
  // Theme-specific filters removed to eliminate glow and square outline artifacts
  let filter = 'none';

  return (
    <motion.svg 
      className={`w-full h-full p-2 ${className}`} 
      viewBox="0 0 100 100"
      animate={isRainbow ? {
        stroke: ['#FF0000', '#FF7F00', '#FFFF00', '#00FF00', '#0000FF', '#4B0082', '#9400D3'],
      } : {}}
      transition={{ duration: isRainbow ? 5 : 2, repeat: Infinity, ease: "linear" }}
      style={{ opacity, overflow: 'visible' }}
    >
      <defs>
        {isChrome && (
          <linearGradient id={`chrome-${color}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fff" />
            <stop offset="20%" stopColor={strokeColor} />
            <stop offset="50%" stopColor="#fff" />
            <stop offset="80%" stopColor={strokeColor} />
            <stop offset="100%" stopColor="#fff" />
          </linearGradient>
        )}
        {isCarbon && (
          <pattern id="carbon-pattern" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
            <rect width="10" height="10" fill="#111" />
            <path d="M0 0L10 10M10 0L0 10" stroke="#333" strokeWidth="1" />
          </pattern>
        )}
      </defs>

      {/* Glow effects removed */}

      <motion.circle 
        cx="50" 
        cy="50" 
        r={SIZE_MAP[size]} 
        fill={isGlass ? "rgba(255, 255, 255, 0.1)" : "transparent"} 
        stroke={isChrome ? `url(#chrome-${color})` : isCarbon ? "url(#carbon-pattern)" : strokeColor} 
        strokeWidth={isMinimalist ? "4" : "8"} 
        strokeLinecap="round" 
        strokeDasharray={isCyberpunk ? "10, 5" : isSynthwave ? "80, 20" : "none"}
        animate={{
          scale: isDragging ? 1.1 : 1,
          strokeWidth: isMinimalist ? 4 : (isVolcano ? [8, 11, 8] : 8),
          rotate: isSynthwave ? [0, 360] : 0
        }}
        transition={{
          scale: { duration: 0.2 },
          strokeWidth: { duration: 1.5, repeat: Infinity, ease: "easeInOut" },
          rotate: { duration: 15, repeat: Infinity, ease: "linear" }
        }}
        style={{
          color: strokeColor,
          transformOrigin: 'center',
          filter: 'none',
          backdropFilter: isGlass ? 'blur(4px)' : 'none'
        }}
      />
      
      {isCarbon && (
        <circle 
          cx="50" 
          cy="50" 
          r={SIZE_MAP[size]} 
          fill="transparent" 
          stroke={strokeColor} 
          strokeWidth="2" 
          style={{ opacity: 0.5 }}
        />
      )}

      {/* Glow effects removed */}


      {/* Oceanic "bubble" effect */}
      {isOceanic && !isMinimalist && (
        <motion.circle 
          cx="50" 
          cy="50" 
          r={SIZE_MAP[size] - 4} 
          fill="transparent" 
          stroke="rgba(255, 255, 255, 0.3)" 
          strokeWidth="1" 
          animate={{ opacity: [0.1, 0.5, 0.1], scale: [0.9, 1.1, 0.9] }}
          transition={{ duration: 4, repeat: Infinity }}
        />
      )}

      {/* Cyberpunk "glitch" lines and HUD readout */}
      {isCyberpunk && (
        <>
          <motion.line 
            x1="20" y1="50" x2="80" y2="50"
            stroke={strokeColor}
            strokeWidth="1"
            animate={{ opacity: [0, 0.8, 0], x: [-10, 10, -10] }}
            transition={{ duration: 0.15, repeat: Infinity, repeatDelay: Math.random() * 2 }}
          />
          <motion.text
            x="50"
            y="50"
            textAnchor="middle"
            dominantBaseline="middle"
            fontSize="8"
            fill={strokeColor}
            style={{ fontFamily: 'monospace', opacity: 0.4, pointerEvents: 'none', fontWeight: 'bold' }}
            animate={{ opacity: [0.1, 0.4, 0.1] }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            {size === 'small' ? 'S' : size === 'medium' ? 'M' : 'L'}
          </motion.text>
          <motion.circle 
            cx="50" 
            cy="50" 
            r={SIZE_MAP[size]} 
            fill="transparent" 
            stroke={strokeColor} 
            strokeWidth="1" 
            style={{ opacity: 0.3 }}
            animate={{
              clipPath: [
                'inset(0 0 95% 0)',
                'inset(45% 0 45% 0)',
                'inset(95% 0 0 0)',
              ]
            }}
            transition={{ duration: 0.5, repeat: Infinity, ease: "linear" }}
          />
        </>
      )}

      {/* Volcano "lava" pulse */}
      {isVolcano && !isMinimalist && (
        <motion.circle 
          cx="50" 
          cy="50" 
          r={SIZE_MAP[size] - 6} 
          fill="transparent" 
          stroke={strokeColor} 
          strokeWidth="2" 
          style={{ opacity: 0.2 }}
          animate={{ scale: [0.8, 1, 0.8], opacity: [0.1, 0.4, 0.1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        />
      )}

      {/* Synthwave "retro sun" stripes */}
      {isSynthwave && !isMinimalist && (
        <g style={{ opacity: 0.3 }}>
          {[...Array(3)].map((_, i) => (
            <motion.rect
              key={i}
              x={50 - SIZE_MAP[size]}
              y={50 - SIZE_MAP[size] + (i * (SIZE_MAP[size] * 2 / 3))}
              width={SIZE_MAP[size] * 2}
              height="2"
              fill={strokeColor}
              animate={{ opacity: [0.2, 0.5, 0.2] }}
              transition={{ duration: 2, delay: i * 0.5, repeat: Infinity }}
            />
          ))}
        </g>
      )}

      {/* Nebula "starfield" */}
      {isNebula && !isMinimalist && (
        <g style={{ opacity: 0.4 }}>
          {[...Array(4)].map((_, i) => (
            <motion.circle
              key={i}
              cx={50 + (Math.random() - 0.5) * SIZE_MAP[size]}
              cy={50 + (Math.random() - 0.5) * SIZE_MAP[size]}
              r="1"
              fill="white"
              animate={{ opacity: [0, 1, 0], scale: [0.5, 1.5, 0.5] }}
              transition={{ duration: 2 + Math.random() * 2, repeat: Infinity, delay: Math.random() * 2 }}
            />
          ))}
        </g>
      )}

      {isRainbow && (
        <circle 
          cx="50" 
          cy="50" 
          r={SIZE_MAP[size]} 
          fill="transparent" 
          stroke={getThemeColor(color, activeUnlockables)} 
          strokeWidth="2" 
          style={{ opacity: 0.8 }}
        />
      )}
    </motion.svg>
  );
};

const CellView = ({ r, c, cell, hints = [], activeUnlockables = {}, onClick }: any) => {
  const currentHint = hints.find((h: any) => h.r === r && h.c === c);
  const isHinted = !!currentHint;
  
  const isVolcano = activeUnlockables.volcano;
  const isOceanic = activeUnlockables.oceanic;
  const isSynthwave = activeUnlockables.synthwave;
  const isNebula = activeUnlockables.nebula;
  const isCyberpunk = activeUnlockables.cyberpunk;
  const isMinimalist = activeUnlockables.minimalist;
  const isDisco = activeUnlockables.disco_grid;

  let cellBorder = 'border-white/10';
  let cellBg = 'rgba(255, 255, 255, 0.05)';
  
  if (isVolcano) {
    cellBorder = 'border-orange-900/30';
    cellBg = 'rgba(124, 45, 18, 0.1)';
  } else if (isOceanic) {
    cellBorder = 'border-cyan-900/30';
    cellBg = 'rgba(8, 51, 68, 0.1)';
  } else if (isSynthwave) {
    cellBorder = 'border-pink-500/20';
    cellBg = 'rgba(131, 24, 67, 0.1)';
  } else if (isNebula) {
    cellBorder = 'border-purple-500/20';
    cellBg = 'rgba(88, 28, 135, 0.1)';
  } else if (isCyberpunk) {
    cellBorder = 'border-lime-500/40';
    cellBg = 'rgba(54, 83, 20, 0.15)';
  } else if (isMinimalist) {
    cellBorder = 'border-slate-200';
    cellBg = 'transparent';
  }

  return (
    <motion.div 
      data-cell-r={r}
      data-cell-c={c}
      onClick={onClick}
      className={`aspect-square border ${isHinted ? 'border-[#00f2ff] shadow-[0_0_15px_#00f2ff] animate-pulse' : cellBorder} rounded-lg relative cursor-pointer hover:bg-white/10 transition-colors flex items-center justify-center overflow-hidden`}
      animate={isDisco ? {
        backgroundColor: [
          'rgba(255, 0, 0, 0.1)', 
          'rgba(0, 255, 0, 0.1)', 
          'rgba(0, 0, 255, 0.1)', 
          'rgba(255, 255, 0, 0.1)', 
          'rgba(255, 0, 255, 0.1)', 
          'rgba(0, 255, 255, 0.1)', 
          'rgba(255, 0, 0, 0.1)'
        ],
        boxShadow: [
          'inset 0 0 10px rgba(255, 0, 0, 0.2)',
          'inset 0 0 10px rgba(0, 255, 0, 0.2)',
          'inset 0 0 10px rgba(0, 0, 255, 0.2)',
          'inset 0 0 10px rgba(255, 255, 0, 0.2)',
          'inset 0 0 10px rgba(255, 0, 255, 0.2)',
          'inset 0 0 10px rgba(0, 255, 255, 0.2)',
          'inset 0 0 10px rgba(255, 0, 0, 0.2)'
        ],
      } : (isCyberpunk ? {
        boxShadow: [
          'inset 0 0 5px rgba(57, 255, 20, 0.1)',
          'inset 0 0 15px rgba(57, 255, 20, 0.2)',
          'inset 0 0 5px rgba(57, 255, 20, 0.1)',
        ],
        backgroundColor: [
          'rgba(54, 83, 20, 0.15)',
          'rgba(54, 83, 20, 0.2)',
          'rgba(54, 83, 20, 0.15)',
        ]
      } : { backgroundColor: cellBg, boxShadow: 'inset 0 0 0px rgba(0,0,0,0)' })}
      transition={isDisco ? {
        duration: 4,
        repeat: Infinity,
        delay: (r + c) * 0.2,
        ease: "linear"
      } : (isCyberpunk ? {
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut",
        delay: (r + c) * 0.1
      } : {})}
    >
      {isHinted && hints.length > 1 && (
        <div className="absolute top-1 left-1 bg-[#00f2ff] text-black text-[8px] font-black w-3 h-3 rounded-full flex items-center justify-center z-20 shadow-sm animate-bounce">
          {currentHint.order}
        </div>
      )}
      <AnimatePresence>
      {cell.large && (
        <motion.div 
          key={cell.large.id} 
          initial={{ scale: 0, opacity: 0, rotate: -45 }} 
          animate={{ scale: 1, opacity: 1, rotate: 0 }} 
          exit={{ scale: 1.5, opacity: 0, rotate: 45 }} 
          transition={{ type: 'spring', damping: 15, stiffness: 300 }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <RingSvg size="large" color={cell.large.color} activeUnlockables={activeUnlockables} />
        </motion.div>
      )}
      {cell.medium && (
        <motion.div 
          key={cell.medium.id} 
          initial={{ scale: 0, opacity: 0, rotate: 45 }} 
          animate={{ scale: 1, opacity: 1, rotate: 0 }} 
          exit={{ scale: 1.5, opacity: 0, rotate: -45 }} 
          transition={{ type: 'spring', damping: 15, stiffness: 300, delay: 0.05 }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <RingSvg size="medium" color={cell.medium.color} activeUnlockables={activeUnlockables} />
        </motion.div>
      )}
      {cell.small && (
        <motion.div 
          key={cell.small.id} 
          initial={{ scale: 0, opacity: 0, rotate: -20 }} 
          animate={{ scale: 1, opacity: 1, rotate: 0 }} 
          exit={{ scale: 1.5, opacity: 0, rotate: 20 }} 
          transition={{ type: 'spring', damping: 15, stiffness: 300, delay: 0.1 }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <RingSvg size="small" color={cell.small.color} activeUnlockables={activeUnlockables} />
        </motion.div>
      )}
    </AnimatePresence>
    
    {/* Theme-specific Grid Decorations */}
    {isCyberpunk && (
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-[#39FF14]/60" />
        <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-[#39FF14]/60" />
        <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-[#39FF14]/60" />
        <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-[#39FF14]/60" />
        <motion.div 
          className="absolute top-0 left-0 w-full h-[1px] bg-[#39FF14]/20"
          animate={{ top: ['0%', '100%', '0%'] }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        />
        <div className="absolute bottom-1 right-1 text-[8px] font-mono text-[#39FF14]/40">
          {r},{c}
        </div>
      </div>
    )}

    {isVolcano && (
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-1.5 h-1.5 bg-orange-600/40 rounded-full blur-[2px] animate-pulse" />
        <div className="absolute bottom-0 right-0 w-1.5 h-1.5 bg-red-600/40 rounded-full blur-[2px] animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute inset-0 border border-orange-900/10 rounded-lg" />
      </div>
    )}

    {isOceanic && (
      <div className="absolute inset-0 pointer-events-none">
        <motion.div 
          className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent"
          animate={{ opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 4, repeat: Infinity }}
        />
        <div className="absolute top-1 right-1 w-1 h-1 bg-white/20 rounded-full" />
        <div className="absolute top-2 right-2 w-0.5 h-0.5 bg-white/10 rounded-full" />
      </div>
    )}

    {isSynthwave && (
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-[1px] bg-pink-500/30" />
        <div className="absolute bottom-0 left-0 w-full h-[1px] bg-cyan-500/30" />
        <div className="absolute top-0 left-0 w-1 h-1 bg-pink-500 shadow-[0_0_5px_#ec4899]" />
        <div className="absolute bottom-0 right-0 w-1 h-1 bg-cyan-500 shadow-[0_0_5px_#06b6d4]" />
      </div>
    )}

    {isNebula && (
      <div className="absolute inset-0 pointer-events-none">
        <motion.div 
          className="absolute top-1/4 left-1/4 w-1/2 h-1/2 bg-purple-500/10 rounded-full blur-xl"
          animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 5, repeat: Infinity }}
        />
        <div className="absolute top-1 left-1 w-0.5 h-0.5 bg-white/40 rounded-full animate-ping" />
        <div className="absolute bottom-2 right-2 w-0.5 h-0.5 bg-white/40 rounded-full animate-ping" style={{ animationDelay: '2s' }} />
      </div>
    )}

    {isMinimalist && (
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-1 h-1 border-t border-l border-slate-400" />
        <div className="absolute top-0 right-0 w-1 h-1 border-t border-r border-slate-400" />
        <div className="absolute bottom-0 left-0 w-1 h-1 border-b border-l border-slate-400" />
        <div className="absolute bottom-0 right-0 w-1 h-1 border-b border-r border-slate-400" />
      </div>
    )}
  </motion.div>
  );
};

const QueuePieceView = ({ piece, index, hints = [], onDrop, activeUnlockables = {}, haptics }: any) => {
  const currentHint = hints.find((h: any) => h.pieceIndex === index);
  const isHinted = !!currentHint;
  const [isDragging, setIsDragging] = useState(false);
  const [trail, setTrail] = useState<{x: number, y: number}[]>([]);
  
  if (!piece) return <div className={`w-14 h-14 rounded-xl border ${activeUnlockables.minimalist ? 'bg-transparent border-slate-200' : 'bg-white/5 border-white/10'}`} />;
  
  const dominantColor = piece.large || piece.medium || piece.small;
  const glowColor = dominantColor ? getThemeColor(dominantColor, activeUnlockables) : '#00f2ff';

  const isVolcano = activeUnlockables.volcano;
  const isOceanic = activeUnlockables.oceanic;
  const isSynthwave = activeUnlockables.synthwave;
  const isNebula = activeUnlockables.nebula;
  const isCyberpunk = activeUnlockables.cyberpunk;
  const isMinimalist = activeUnlockables.minimalist;
  const isDisco = activeUnlockables.disco_grid;

  let pieceBg = 'bg-white/5';
  let pieceBorder = 'border-white/10';

  if (isVolcano) {
    pieceBg = 'bg-orange-900/20';
    pieceBorder = 'border-orange-500/30';
  } else if (isOceanic) {
    pieceBg = 'bg-cyan-900/20';
    pieceBorder = 'border-cyan-500/30';
  } else if (isSynthwave) {
    pieceBg = 'bg-pink-900/20';
    pieceBorder = 'border-pink-500/30';
  } else if (isNebula) {
    pieceBg = 'bg-purple-900/20';
    pieceBorder = 'border-purple-500/30';
  } else if (isCyberpunk) {
    pieceBg = 'bg-lime-900/20';
    pieceBorder = 'border-lime-500/30';
  } else if (isMinimalist) {
    pieceBg = 'bg-transparent';
    pieceBorder = 'border-slate-200';
  }

  const handleDragStart = () => {
    setIsDragging(true);
    setTrail([]);
    triggerHaptic(haptics, 5);
  };

  const handleDrag = (event: any, info: any) => {
    if (activeUnlockables.neon_trails) {
      setTrail(prev => {
        const current = { 
          x: info.offset.x, 
          y: info.offset.y,
          vx: info.velocity.x,
          vy: info.velocity.y
        };
        
        if (prev.length > 0) {
          const last = prev[0];
          const dist = Math.sqrt(Math.pow(current.x - last.x, 2) + Math.pow(current.y - last.y, 2));
          if (dist < 10) return prev; 
        }

        const newTrail = [current, ...prev];
        return newTrail.slice(0, 10); 
      });
    }
  };

  const handleDragEnd = (event: any, info: any) => {
    const x = info?.point?.x ?? (event.changedTouches ? event.changedTouches[0].clientX : event.clientX);
    const y = info?.point?.y ?? (event.changedTouches ? event.changedTouches[0].clientY : event.clientY);
    
    const elements = document.elementsFromPoint(x, y);
    const cellElement = elements.find(el => el.closest('[data-cell-r]'))?.closest('[data-cell-r]');
    
    if (cellElement) {
      const r = parseInt(cellElement.getAttribute('data-cell-r') || '0');
      const c = parseInt(cellElement.getAttribute('data-cell-c') || '0');
      onDrop(index, r, c);
    }

    setIsDragging(false);
    setTrail([]);
  };

  return (
    <div className="relative z-50">
      {/* Discrete Particle Trail Effect */}
      {isDragging && activeUnlockables.neon_trails && trail.map((pos, i) => {
        const speed = Math.sqrt(pos.vx * pos.vx + pos.vy * pos.vy);
        const angle = Math.atan2(pos.vy, pos.vx) * (180 / Math.PI);
        const stretch = Math.min(1 + speed / 500, 2);
        
        return (
          <div 
            key={i}
            className="absolute pointer-events-none z-30"
            style={{ 
              left: pos.x + 28, 
              top: pos.y + 28,
              width: (piece.large ? 32 : piece.medium ? 22 : 12) * (1 - i / trail.length) * stretch,
              height: (piece.large ? 32 : piece.medium ? 22 : 12) * (1 - i / trail.length) / (stretch * 0.8),
              backgroundColor: glowColor,
              borderRadius: '50%',
              transform: `translate(-50%, -50%) rotate(${angle}deg)`,
              opacity: (1 - i / trail.length) * 0.6,
              filter: 'blur(4px)',
              boxShadow: `0 0 20px ${glowColor}, 0 0 10px #fff`
            }}
          />
        );
      })}

      <motion.div 
        drag
        dragSnapToOrigin
        dragElastic={0.12}
        dragMomentum={false}
        onDragStart={handleDragStart}
        onDrag={handleDrag}
        onDragEnd={handleDragEnd}
        className={`w-14 h-14 rounded-xl flex items-center justify-center relative cursor-grab active:cursor-grabbing transition-colors ${pieceBg} border ${pieceBorder} ${isHinted ? 'border-[#00f2ff] !border shadow-[0_0_15px_#00f2ff] animate-pulse' : ''} z-50 touch-none`}
        animate={isDragging ? {
          scale: 1.2,
          scaleX: 1.1,
          scaleY: 0.9,
          zIndex: 100,
        } : {
          scale: 1,
          scaleX: 1,
          scaleY: 1,
          y: [0, -4, 0],
          rotate: [0, 1, -1, 0],
          zIndex: 50,
        }}
        whileHover={{ 
          scale: 1.05, 
          boxShadow: activeUnlockables.neon_trails ? `0 0 20px ${glowColor}` : '0 0 10px rgba(255,255,255,0.2)' 
        }} 
        whileDrag={{ 
          boxShadow: activeUnlockables.neon_trails ? `0 0 40px ${glowColor}` : '0 0 20px rgba(255,255,255,0.3)',
          pointerEvents: 'none',
        }}
        transition={isDragging ? {
          type: 'spring',
          damping: 10,
          stiffness: 200
        } : {
          y: { duration: 4, repeat: Infinity, ease: "easeInOut", delay: index * 0.2 },
          rotate: { duration: 4, repeat: Infinity, ease: "easeInOut", delay: index * 0.2 },
          scale: { type: 'spring', damping: 15, stiffness: 300 }
        }}
      >
        {isHinted && hints.length > 1 && (
          <div className="absolute -top-2 -right-2 bg-[#00f2ff] text-black text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center z-50 shadow-lg border-2 border-black animate-bounce">
            {currentHint.order}
          </div>
        )}
        {piece.large && <div className="absolute inset-0 flex items-center justify-center"><RingSvg size="large" color={piece.large} activeUnlockables={activeUnlockables} isDragging={isDragging} /></div>}
        {piece.medium && <div className="absolute inset-0 flex items-center justify-center"><RingSvg size="medium" color={piece.medium} activeUnlockables={activeUnlockables} isDragging={isDragging} /></div>}
        {piece.small && <div className="absolute inset-0 flex items-center justify-center"><RingSvg size="small" color={piece.small} activeUnlockables={activeUnlockables} isDragging={isDragging} /></div>}
      </motion.div>
    </div>
  );
};

const Toggle = ({ checked, onChange, haptics }: { checked: boolean, onChange: () => void, haptics?: boolean }) => (
  <button onClick={() => {
    onChange();
    if (haptics !== undefined) triggerHaptic(haptics, 10);
    else triggerHaptic(true, 10); // Default to true if we don't know, usually it's for the haptics toggle itself
  }} className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${checked ? 'bg-[#ec5b13]' : 'bg-slate-700'}`}>
    <div className={`h-[27px] w-[27px] rounded-full bg-white shadow-md transform transition-transform duration-200 ${checked ? 'translate-x-[20px]' : 'translate-x-0'}`} />
  </button>
);

const RewardedAdSimulation = ({ onComplete, onCancel, activeUnlockables = {}, rewardText = "Claim Reward" }: any) => {
  const [timeLeft, setTimeLeft] = useState(15);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!isLoaded) return;
    if (timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
      return () => clearInterval(timer);
    }
  }, [timeLeft, isLoaded]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-md p-4">
      {!isLoaded ? (
        <div className="text-center space-y-4">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
            className="w-12 h-12 border-4 border-[#00f2ff] border-t-transparent rounded-full mx-auto"
          />
          <p className="text-[#00f2ff] font-black tracking-[0.3em] text-[10px] animate-pulse uppercase">Requesting Ad...</p>
        </div>
      ) : (
        <div className="relative w-full max-w-lg aspect-video bg-[#0f172a] rounded-3xl overflow-hidden border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] flex flex-col">
          {/* Mock Video Content */}
          <div className="flex-1 flex items-center justify-center relative overflow-hidden">
             <div className="absolute inset-0 bg-gradient-to-br from-[#00f2ff]/10 via-[#ff007f]/10 to-[#39FF14]/10 opacity-50" />
             <div className="relative z-10 text-center space-y-4 p-8">
                <div className="w-20 h-20 bg-white/5 rounded-[2.5rem] mx-auto flex items-center justify-center border border-white/10 backdrop-blur-xl shadow-inner">
                   <Play size={40} className="text-white fill-white ml-1" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-2xl font-black text-white tracking-tight uppercase italic">Hue Rings Pro</h3>
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest max-w-[200px] mx-auto leading-relaxed">Unlock all themes and remove ads forever</p>
                </div>
                <button className="bg-white text-black font-black px-8 py-3 rounded-2xl text-xs hover:scale-105 active:scale-95 transition-transform uppercase tracking-widest shadow-[0_10px_20px_rgba(255,255,255,0.1)]">Install Now</button>
             </div>
             
             {/* Progress Bar */}
             <div className="absolute bottom-0 left-0 h-1.5 bg-gradient-to-r from-[#00f2ff] to-[#ff007f] transition-all duration-1000 ease-linear" style={{ width: `${(15 - timeLeft) / 15 * 100}%` }} />
          </div>

          {/* Ad Header */}
          <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-20">
            <div className="bg-black/60 backdrop-blur-xl px-4 py-2 rounded-2xl border border-white/10 flex items-center gap-3 shadow-lg">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse shadow-[0_0_8px_#ef4444]" />
              <span className="text-[10px] font-black text-white uppercase tracking-[0.2em]">{timeLeft > 0 ? `Ad • ${timeLeft}s` : 'Reward Ready'}</span>
            </div>
            
            {timeLeft === 0 ? (
              <button 
                onClick={onComplete}
                className="bg-white text-black p-2.5 rounded-full hover:scale-110 active:scale-90 transition-transform shadow-[0_0_20px_rgba(255,255,255,0.3)] flex items-center justify-center"
              >
                <Check size={20} />
              </button>
            ) : (
              <button 
                onClick={onCancel}
                className="bg-black/60 backdrop-blur-xl p-2.5 rounded-full border border-white/10 text-white/40 hover:text-white transition-colors flex items-center justify-center"
              >
                <X size={20} />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const Confetti = () => {
  const colors = ['#FFD700', '#FF2D55', '#5856D6', '#AF52DE', '#34C759', '#5AC8FA', '#00f2ff', '#39FF14'];
  const pieces = Array.from({ length: 60 }).map((_, i) => ({
    id: i, 
    color: colors[Math.floor(Math.random() * colors.length)], 
    left: `${Math.random() * 100}%`,
    size: Math.random() * 10 + 6, 
    duration: Math.random() * 3 + 2, 
    delay: Math.random() * 4,
    xOffset: (Math.random() - 0.5) * 200,
    rotateStart: Math.random() * 360,
    rotateEnd: Math.random() * 1000 + 720,
    type: Math.random() > 0.5 ? 'square' : 'circle'
  }));
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-[100]">
      {pieces.map(p => (
        <motion.div 
          key={p.id} 
          className={`absolute ${p.type === 'circle' ? 'rounded-full' : 'rounded-sm'}`}
          style={{ 
            backgroundColor: p.color, 
            left: p.left, 
            width: p.size, 
            height: p.size, 
            top: '-10%',
            boxShadow: `0 0 10px ${p.color}44`
          }}
          animate={{ 
            y: ['0vh', '110vh'], 
            x: [0, p.xOffset],
            rotate: [p.rotateStart, p.rotateEnd], 
            opacity: [0, 1, 1, 0] 
          }}
          transition={{ 
            duration: p.duration, 
            delay: p.delay, 
            repeat: Infinity, 
            ease: [0.23, 1, 0.32, 1] 
          }}
        />
      ))}
    </div>
  );
};

const LeaderboardView = ({ onBack, highScores, activeUnlockables, haptics }: any) => {
  const modes = [{ id: 'default', name: 'Default' }, ...UNLOCKABLES.filter(u => u.type === 'mode')];
  
  return (
    <div className={`absolute inset-0 flex flex-col z-50 ${activeUnlockables.light_theme ? 'bg-slate-50' : 'bg-black'}`} onClick={(e) => e.stopPropagation()}>
      <header className="flex items-center px-6 py-4 justify-between z-10">
        <h2 className={`text-2xl font-bold leading-tight tracking-tight flex-1 ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>Leaderboard</h2>
        <button onClick={() => { onBack(); triggerHaptic(haptics, 5); }} className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-colors ${activeUnlockables.light_theme ? 'bg-slate-900/10 text-slate-900 hover:bg-slate-900/20' : 'bg-white/10 text-white hover:bg-white/20'}`}><X size={24} /></button>
      </header>
      <div className="flex-1 px-6 py-2 space-y-4 overflow-y-auto custom-scrollbar">
        {modes.map(mode => (
          <div key={mode.id} className={`flex justify-between items-center p-4 rounded-xl border ${activeUnlockables.light_theme ? 'bg-white border-slate-200' : 'bg-white/5 border-white/10'}`}>
            <span className={`font-bold ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>{mode.name}</span>
            <span className={`font-mono font-black ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-[#00f2ff]'}`}>{highScores[mode.id] || 0}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const PowerUpButton = ({ icon, count, active, onClick, label, color, timer, activeUnlockables, compact, loading }: any) => {
  return (
    <button 
      onClick={onClick}
      disabled={loading}
      className={`relative flex flex-col items-center gap-1 group transition-all ${active ? 'scale-110' : 'hover:scale-105 active:scale-95'} ${loading ? 'opacity-50 cursor-wait' : ''}`}
    >
      <motion.div 
        className={`${compact ? 'w-11 h-11 rounded-xl' : 'w-14 h-14 rounded-2xl'} border-2 flex items-center justify-center backdrop-blur-md transition-all relative overflow-hidden ${
          active 
            ? 'bg-white/30' 
            : (activeUnlockables?.light_theme ? 'bg-slate-900/10 border-slate-900/10 shadow-sm' : 'bg-white/10 border-white/20 shadow-md')
        }`}
        style={active ? { borderColor: color, boxShadow: `0 0 20px ${color}` } : {}}
        animate={active ? {
          boxShadow: [`0 0 10px ${color}`, `0 0 25px ${color}`, `0 0 10px ${color}`],
          borderColor: [color, '#ffffff', color]
        } : {}}
        transition={active ? { duration: 1.5, repeat: Infinity, ease: "easeInOut" } : {}}
      >
        {loading ? (
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
          >
            <RefreshCw size={compact ? 14 : 18} />
          </motion.div>
        ) : (
          <>
            {active && <motion.div 
              layoutId="active-powerup"
              className="absolute inset-0 opacity-20"
              style={{ backgroundColor: color }}
              animate={{ opacity: [0.1, 0.3, 0.1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />}
            <div style={{ color: activeUnlockables?.light_theme ? '#0f172a' : color, filter: activeUnlockables?.light_theme ? 'none' : `drop-shadow(0 0 5px ${color})` }}>
              {icon}
            </div>
          </>
        )}
        {timer !== null && timer > 0 && (
          <div className={`absolute inset-0 flex items-center justify-center bg-black/40 ${compact ? 'text-[8px]' : 'text-[10px]'} font-black text-white`}>
            {timer}s
          </div>
        )}
      </motion.div>
      {!compact ? (
        <div className="flex items-center gap-1">
          <span className={`text-[10px] font-black uppercase tracking-widest ${activeUnlockables?.light_theme ? 'text-slate-700' : 'text-white/70'}`}>{label}</span>
          <span className={`text-[11px] font-black px-1.5 py-0.5 rounded-full flex items-center gap-1 ${activeUnlockables?.light_theme ? 'bg-slate-900/20 text-slate-900 shadow-sm' : 'bg-white/20 text-white shadow-md'}`}>
            {count === 0 ? <PlayCircle size={10} className="text-[#ff007f]" /> : count}
          </span>
        </div>
      ) : (
        <span className={`absolute -top-2 -right-2 text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white/20 shadow-lg z-10 ${activeUnlockables?.light_theme ? 'bg-slate-900 text-white' : 'bg-[#ff007f] text-white'}`}>
          {count === 0 ? <PlayCircle size={12} /> : count}
        </span>
      )}
    </button>
  );
};

const pageVariants = {
  initial: { opacity: 0, scale: 0.98, y: 10 },
  animate: { 
    opacity: 1, 
    scale: 1, 
    y: 0,
    transition: { 
      type: 'spring', 
      damping: 25, 
      stiffness: 200,
      staggerChildren: 0.1,
      delayChildren: 0.2
    } 
  },
  exit: { 
    opacity: 0, 
    scale: 1.02, 
    y: -10,
    transition: { duration: 0.2, ease: "easeInOut" } 
  }
};

const itemVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { 
    opacity: 1, 
    y: 0,
    transition: { type: 'spring', damping: 20, stiffness: 150 }
  }
};

const slideUpVariants = {
  initial: { y: '100%' },
  animate: { 
    y: 0,
    transition: { type: 'spring', damping: 30, stiffness: 250 }
  },
  exit: { 
    y: '100%',
    transition: { duration: 0.3, ease: "easeInOut" }
  }
};

const slideRightVariants = {
  initial: { x: '100%' },
  animate: { 
    x: 0,
    transition: { type: 'spring', damping: 30, stiffness: 250 }
  },
  exit: { 
    x: '100%',
    transition: { duration: 0.3, ease: "easeInOut" }
  }
};

const SplashScreen = () => {
  return (
    <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-[5000]">
      <div className="relative w-48 h-48 flex items-center justify-center mb-8">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="absolute w-48 h-48 border-8 border-[#00f2ff] rounded-full glow-cyan opacity-90" 
          style={{ borderRightColor: 'transparent' }} 
        />
        <motion.div 
          animate={{ rotate: -360 }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="absolute w-32 h-32 border-8 border-[#ff00ff] rounded-full glow-pink opacity-90" 
          style={{ borderLeftColor: 'transparent' }} 
        />
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
          className="absolute w-16 h-16 border-8 border-[#39FF14] rounded-full glow-lime opacity-90" 
          style={{ borderBottomColor: 'transparent' }} 
        />
      </div>
      <h1 className="text-4xl font-black text-white uppercase tracking-[0.3em] mb-2 drop-shadow-[0_0_15px_rgba(0,242,255,0.5)]">HUE RINGS</h1>
      <div className="w-48 h-1 bg-white/10 rounded-full overflow-hidden relative">
        <motion.div 
          initial={{ x: '-100%' }}
          animate={{ x: '100%' }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="absolute inset-0 bg-gradient-to-r from-transparent via-[#00f2ff] to-transparent"
        />
      </div>
      <p className="mt-4 text-[10px] font-black text-[#00f2ff] uppercase tracking-[0.5em] animate-pulse">Initializing Neural Link</p>
    </div>
  );
};

const MenuView = ({ onPlay, onTutorial, onSettings, onAchievements, onLeaderboard, highScore, activeUnlockables = {}, haptics, music, setMusic, toggleUnlockable, user, onLogin, onAppleLogin, onLogout }: any) => {
  return (
    <motion.div 
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      className={`h-full flex flex-col items-center p-6 pt-safe pb-safe relative overflow-hidden ${activeUnlockables.light_theme ? 'bg-slate-100 text-slate-900' : 'bg-black text-white'}`}
    >
      <div className="fixed inset-0 pointer-events-none opacity-20 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-[#00f2ff] blur-[120px] rounded-full"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#ff00ff] blur-[120px] rounded-full"></div>
      </div>
      
      {/* Top Bar */}
      <motion.div variants={itemVariants} className="w-full z-50 flex justify-between items-center mb-4">
        <UserMenu user={user} onLogin={onLogin} onAppleLogin={onAppleLogin} onLogout={onLogout} activeUnlockables={activeUnlockables} />
        
        <button 
          onClick={() => { toggleUnlockable('light_theme'); triggerHaptic(haptics, 5); }}
          className={`h-11 w-11 flex items-center justify-center rounded-xl backdrop-blur-md border transition-all ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10 text-slate-900' : 'bg-white/5 border-white/10 text-white'} hover:scale-110 active:scale-95`}
        >
          {activeUnlockables.light_theme ? <Moon size={22} /> : <Sun size={22} className="text-[#ffbf00]" />}
        </button>
      </motion.div>

      <div className="flex-1 flex flex-col items-center justify-center w-full">
        <motion.header variants={itemVariants} className="flex flex-col items-center mb-12 z-10">
          <div className="relative w-32 h-32 sm:w-40 sm:h-40 flex items-center justify-center mb-6">
            <div className="absolute w-full h-full border-8 border-[#00f2ff] rounded-full glow-cyan animate-[spin_12s_linear_infinite] opacity-90" style={{ borderRightColor: 'transparent' }}></div>
            <div className="absolute w-[70%] h-[70%] border-8 border-[#ff00ff] rounded-full glow-pink animate-[spin_15s_linear_infinite_reverse] opacity-90" style={{ borderLeftColor: 'transparent' }}></div>
            <div className="absolute w-[35%] h-[35%] border-8 border-[#39FF14] rounded-full glow-lime animate-[spin_10s_linear_infinite] opacity-90" style={{ borderBottomColor: 'transparent' }}></div>
          </div>
          <h1 className={`text-4xl sm:text-5xl font-black tracking-tight uppercase text-center ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`} style={{ letterSpacing: '0.25em' }}>Hue Rings</h1>
          <p className={`mt-2 text-xs sm:text-sm uppercase tracking-[0.5em] font-black ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-400'}`}>Circle Puzzle</p>
          
          {highScore > 0 && (
            <div className={`mt-6 flex items-center gap-2 backdrop-blur-md px-6 py-2 rounded-full border shadow-[0_0_15px_rgba(255,191,0,0.2)] ${activeUnlockables.light_theme ? 'bg-slate-900/10 border-slate-900/10' : 'bg-white/10 border-white/10'}`}>
              <Trophy size={16} className="text-[#ffbf00]" />
              <span className={`font-bold tracking-widest uppercase text-sm ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>Best: {highScore}</span>
            </div>
          )}
        </motion.header>

        <motion.main variants={itemVariants} className="w-full flex flex-col items-center gap-4 z-10">
          <button onClick={() => { onPlay(); triggerHaptic(haptics, 15); }} className={`w-full max-w-[280px] h-14 text-xl font-black rounded-full shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2 ${activeUnlockables.light_theme ? 'bg-slate-900 text-white shadow-slate-900/20' : 'bg-white text-black shadow-white/10'}`}>
            <Play fill="currentColor" size={24} /> PLAY
          </button>
          <button onClick={() => { onTutorial(); triggerHaptic(haptics, 10); }} className={`w-full max-w-[280px] h-12 text-lg font-black rounded-full active:scale-95 transition-transform flex items-center justify-center gap-2 border ${activeUnlockables.light_theme ? 'bg-slate-900/10 text-slate-900 border-slate-900/20' : 'bg-white/10 text-white border-white/20'}`}>
            <HelpCircle size={20} /> HOW TO PLAY
          </button>
        </motion.main>
      </div>

      <motion.footer variants={itemVariants} className="w-full flex justify-between items-center mt-8 px-2 z-10">
        <button onClick={() => { onSettings(); triggerHaptic(haptics, 10); }} className={`h-14 w-14 flex items-center justify-center rounded-2xl backdrop-blur-md border transition-colors ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10 active:bg-slate-900/10 text-slate-900' : 'bg-white/5 border-white/10 active:bg-white/20 text-white'}`}><Settings size={32} color="currentColor" /></button>

        <button onClick={() => { onAchievements(); triggerHaptic(haptics, 10); }} className={`h-14 px-4 rounded-2xl backdrop-blur-md border transition-colors flex items-center gap-2 ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10 active:bg-slate-900/10 text-slate-900' : 'bg-white/5 border-white/10 active:bg-white/20 text-white'}`}>
          <Trophy size={32} color="currentColor" />
          <div className={`w-[1px] h-8 ${activeUnlockables.light_theme ? 'bg-slate-900/10' : 'bg-white/10'}`} />
          <Star size={32} color="currentColor" />
        </button>
        <button onClick={() => { onLeaderboard(); triggerHaptic(haptics, 10); }} className={`h-14 w-14 flex items-center justify-center rounded-2xl backdrop-blur-md border transition-colors ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10 active:bg-slate-900/10 text-slate-900' : 'bg-white/5 border-white/10 active:bg-white/20 text-white'}`}><Award size={32} color="currentColor" /></button>
      </motion.footer>
    </motion.div>
  );
};

const TutorialView = ({ onBack, onPlay, activeUnlockables = {}, haptics }: any) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { x: -20, opacity: 0 },
    show: { x: 0, opacity: 1 }
  };

  return (
    <div className={`relative flex h-full w-full flex-col max-w-md mx-auto pt-safe pb-safe ${activeUnlockables.light_theme ? 'bg-slate-100 text-slate-900' : 'bg-[#0F172A] text-white'}`} onClick={(e) => e.stopPropagation()}>
      <header className="flex items-center px-6 py-4 justify-between z-10">
        <h2 className="text-2xl font-bold leading-tight tracking-tight flex-1">Briefing</h2>
        <button onClick={() => { onBack(); triggerHaptic(haptics, 5); }} className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-colors ${activeUnlockables.light_theme ? 'bg-slate-900/10 text-slate-900 hover:bg-slate-900/20' : 'bg-white/10 text-white hover:bg-white/20'}`}><X size={24} /></button>
      </header>
      
      <div className="flex-1 flex flex-col items-center px-6 z-10 overflow-y-auto pb-10 custom-scrollbar">
        <motion.h2 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-4xl font-black leading-tight text-center pb-2 pt-4 text-transparent bg-clip-text bg-gradient-to-r from-[#00f2ff] via-white to-[#ff007f] drop-shadow-[0_0_15px_rgba(0,242,255,0.3)]"
        >
          MASTER THE SPECTRUM
        </motion.h2>
        <p className="text-[10px] font-black tracking-[0.5em] text-[#00f2ff] mb-8 uppercase opacity-50">Mission Objective: Clear the Grid</p>
        
        <div className={`relative w-full aspect-square max-w-[260px] rounded-[40px] flex items-center justify-center border-2 shadow-[0_0_50px_rgba(0,0,0,0.3)] mb-10 group overflow-hidden ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10' : 'bg-white/5 border-white/10'}`}>
          <div className="absolute inset-0 bg-gradient-to-br from-[#00f2ff]/5 to-[#ff007f]/5"></div>
          
          {/* Scanning Line Effect */}
          <motion.div 
            animate={{ top: ['0%', '100%', '0%'] }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            className="absolute left-0 w-full h-[1px] bg-[#00f2ff]/20 z-20 shadow-[0_0_10px_#00f2ff]"
          />
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="relative flex items-center justify-center"
          >
            <div className="absolute w-44 h-44 border-[8px] border-[#00f2ff] rounded-full shadow-[0_0_20px_#00f2ff] opacity-80"></div>
            <div className="absolute w-28 h-28 border-[8px] border-[#ff007f] rounded-full shadow-[0_0_20px_#ff007f] opacity-80"></div>
            <div className="absolute w-14 h-14 border-[8px] border-[#39FF14] rounded-full shadow-[0_0_20px_#39FF14] opacity-80"></div>
            
            {/* Connection Lines */}
            <div className="absolute w-full h-[2px] bg-white/10 rotate-45"></div>
            <div className="absolute w-full h-[2px] bg-white/10 -rotate-45"></div>
          </motion.div>

          <div className="absolute bottom-4 left-0 w-full text-center">
            <span className="text-[10px] font-black tracking-[0.4em] text-white/30 uppercase">Neural Interface Active</span>
          </div>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="space-y-10 w-full"
        >
          <motion.div variants={itemVariants} className="flex items-start gap-5">
            <div className="flex-shrink-0 size-12 rounded-2xl bg-gradient-to-br from-[#00f2ff] to-[#00f2ff]/20 border border-[#00f2ff]/50 flex items-center justify-center shadow-[0_0_20px_rgba(0,242,255,0.4)]">
              <span className="text-white font-black text-xl">01</span>
            </div>
            <div>
              <h3 className={`text-xl font-black mb-1 tracking-tight ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>DEPLOY RINGS</h3>
              <p className={`leading-relaxed text-sm font-medium ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-400'}`}>
                Drag rings from your queue to the <span className="text-[#00f2ff] font-bold">3x3 Grid</span>. 
                Stack <span className="italic">Small, Medium, and Large</span> rings in a single cell to maximize space.
              </p>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="flex items-start gap-5">
            <div className="flex-shrink-0 size-12 rounded-2xl bg-gradient-to-br from-[#ff007f] to-[#ff007f]/20 border border-[#ff007f]/50 flex items-center justify-center shadow-[0_0_20px_rgba(255,0,127,0.4)]">
              <span className="text-white font-black text-xl">02</span>
            </div>
            <div>
              <h3 className={`text-xl font-black mb-1 tracking-tight ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>SYNC COLORS</h3>
              <p className={`leading-relaxed text-sm font-medium ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-400'}`}>
                Align 3 rings of the same color <span className="text-[#ff007f] font-bold underline decoration-2 underline-offset-4">Horizontally, Vertically, or Diagonally</span> to trigger a clear.
              </p>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="flex items-start gap-5">
            <div className="flex-shrink-0 size-12 rounded-2xl bg-gradient-to-br from-[#39FF14] to-[#39FF14]/20 border border-[#39FF14]/50 flex items-center justify-center shadow-[0_0_20px_rgba(57,255,20,0.4)]">
              <span className="text-white font-black text-xl">03</span>
            </div>
            <div>
              <h3 className={`text-xl font-black mb-1 tracking-tight ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>COMBO CHAIN</h3>
              <p className={`leading-relaxed text-sm font-medium ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-400'}`}>
                Each clear starts a chain. You have <span className="text-[#39FF14] font-bold">3 moves</span> to trigger another clear and grow your multiplier. Don't let the energy drop!
              </p>
            </div>
          </motion.div>

          {/* Pro Tips Section */}
          <motion.div 
            variants={itemVariants}
            className={`p-5 rounded-3xl border-2 border-dashed ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/20' : 'bg-white/5 border-white/10'}`}
          >
            <h4 className="text-xs font-black mb-3 uppercase tracking-[0.3em] text-[#00f2ff] flex items-center gap-2">
              <Zap size={14} fill="currentColor" /> Pro Tips
            </h4>
            <ul className="space-y-2 text-[11px] font-bold leading-tight text-gray-400">
              <li className="flex gap-2"><span className="text-[#ff007f]">•</span> Full-stacking a cell (S+M+L) clears it instantly!</li>
              <li className="flex gap-2"><span className="text-[#ff007f]">•</span> Use Hints when the grid gets crowded to find hidden matches.</li>
              <li className="flex gap-2"><span className="text-[#ff007f]">•</span> High combos unlock powerful rewards and themes.</li>
            </ul>
          </motion.div>
        </motion.div>
      </div>
      
      <div className={`p-6 pb-12 flex flex-col gap-3 z-10 mt-auto bg-gradient-to-t ${activeUnlockables.light_theme ? 'from-slate-100 to-transparent' : 'from-[#0F172A] to-transparent'}`}>
        <button 
          onClick={() => {
            localStorage.removeItem('hueRingsTutorialCompleted');
            onPlay();
          }} 
          className={`group relative w-full h-12 font-black rounded-2xl transition-all active:scale-[0.95] text-xs uppercase tracking-[0.2em] overflow-hidden border-2 ${activeUnlockables.light_theme ? 'border-slate-900 text-slate-900 bg-white' : 'border-white/20 text-white bg-white/5'}`}
        >
          REPLAY INTERACTIVE TUTORIAL
        </button>
        <button 
          onClick={onPlay} 
          className={`group relative w-full h-14 font-black rounded-2xl transition-all active:scale-[0.95] text-xl uppercase tracking-[0.2em] overflow-hidden ${activeUnlockables.light_theme ? 'bg-slate-900 text-white' : 'bg-white text-black'}`}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-[#00f2ff] to-[#ff007f] opacity-0 group-hover:opacity-10 transition-opacity"></div>
          INITIALIZE GAME
        </button>
      </div>
      
      <div className="fixed top-20 -left-20 w-64 h-64 bg-[#ff007f]/10 blur-[120px] pointer-events-none"></div>
      <div className="fixed bottom-20 -right-20 w-64 h-64 bg-[#00f2ff]/10 blur-[120px] pointer-events-none"></div>
    </div>
  );
};

const AchievementsView = ({ 
  onBack, 
  unlockedIds, 
  activeUnlockables = {},
  stats,
  score,
  highScore,
  combo,
  toggleUnlockable,
  haptics
}: { 
  onBack: () => void, 
  unlockedIds: string[], 
  activeUnlockables?: Record<string, boolean>,
  stats: GameStats,
  score: number,
  highScore: number,
  combo: number,
  toggleUnlockable: (id: string) => void,
  haptics?: boolean
}) => {
  const [tab, setTab] = useState<'achievements' | 'rewards'>('achievements');
  const unlockedList = ACHIEVEMENTS.filter(a => unlockedIds.includes(a.id));
  const lockedList = ACHIEVEMENTS.filter(a => !unlockedIds.includes(a.id));

  const renderAchievementList = (title: string, achievements: Achievement[], colorClass: string, isUnlockedSection: boolean = false) => {
    if (achievements.length === 0) return null;
    return (
      <div className="mb-8">
        <h3 className={`text-sm font-black mb-4 uppercase tracking-[0.2em] flex items-center gap-2 ${colorClass}`}>
          {isUnlockedSection ? <Shield size={16} /> : <Lock size={16} />} {title}
        </h3>
        <div className="space-y-3">
          {achievements.map(ach => {
            const isUnlocked = unlockedIds.includes(ach.id);
            let currentProgress = 0;
            if (ach.statKey) {
              if (ach.statKey === 'score') currentProgress = Math.max(score, highScore);
              else if (ach.statKey === 'combo') currentProgress = combo;
              else currentProgress = stats[ach.statKey as keyof GameStats] || 0;
            }

            return (
              <div key={ach.id} className={`flex items-center gap-4 p-4 rounded-2xl border transition-all ${isUnlocked ? (activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10 shadow-sm' : 'bg-white/10 border-white/20 shadow-lg shadow-yellow-500/5') : (activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/5 opacity-50' : 'bg-black/20 border-white/5 opacity-50')}`}>
                <div className="text-3xl filter drop-shadow-md">{ach.icon}</div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h3 className={`font-bold text-sm ${isUnlocked ? (activeUnlockables.light_theme ? 'text-slate-900' : 'text-white') : (activeUnlockables.light_theme ? 'text-slate-500' : 'text-gray-400')}`}>{ach.title}</h3>
                    {!isUnlocked && ach.target && (
                      <span className="text-[10px] font-mono text-gray-500">{currentProgress} / {ach.target}</span>
                    )}
                  </div>
                  <p className={`text-xs leading-tight ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-500'}`}>{ach.description}</p>
                  {!isUnlocked && ach.target && (
                    <div className="mt-1.5 h-1 w-full bg-black/20 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-yellow-400/50" 
                        style={{ width: `${Math.min(100, (currentProgress / ach.target) * 100)}%` }}
                      />
                    </div>
                  )}
                </div>
                {isUnlocked && <div className="text-green-400"><Shield size={16} /></div>}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className={`relative flex h-full w-full flex-col max-w-md mx-auto pt-safe pb-safe ${activeUnlockables.light_theme ? 'bg-slate-100 text-slate-900' : 'bg-[#0F172A] text-white'}`} onClick={(e) => e.stopPropagation()}>
      <header className="flex items-center px-6 py-4 justify-between z-10">
        <h2 className="text-2xl font-bold leading-tight tracking-tight flex-1">
          {tab === 'achievements' ? 'Achievements' : 'Rewards'}
        </h2>
        <button onClick={() => { onBack(); triggerHaptic(haptics, 5); }} className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-colors ${activeUnlockables.light_theme ? 'bg-slate-900/10 text-slate-900 hover:bg-slate-900/20' : 'bg-white/10 text-white hover:bg-white/20'}`}><X size={24} /></button>
      </header>

      {/* Tab Switcher */}
      <div className="flex px-6 mb-4 z-10">
        <button 
          onClick={() => { setTab('achievements'); triggerHaptic(haptics, 10); }} 
          className={`flex-1 h-11 text-xs font-black uppercase tracking-widest transition-all border-b-2 ${tab === 'achievements' ? 'text-[#00f2ff] border-[#00f2ff]' : 'text-gray-500 border-transparent'}`}
        >
          Achievements
        </button>
        <button 
          onClick={() => { setTab('rewards'); triggerHaptic(haptics, 10); }} 
          className={`flex-1 h-11 text-xs font-black uppercase tracking-widest transition-all border-b-2 ${tab === 'rewards' ? 'text-[#ff007f] border-[#ff007f]' : 'text-gray-500 border-transparent'}`}
        >
          Rewards
        </button>
      </div>
      
      <div className="flex-1 relative overflow-hidden">
        <motion.div 
          className="flex h-full w-[200%]"
          animate={{ x: tab === 'achievements' ? '0%' : '-50%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={0.2}
          onDragEnd={(e, info) => {
            if (info.offset.x < -50 && tab === 'achievements') setTab('rewards');
            else if (info.offset.x > 50 && tab === 'rewards') setTab('achievements');
          }}
        >
          {/* Achievements Tab */}
          <div className="w-1/2 h-full flex flex-col px-6 overflow-y-auto pb-10 custom-scrollbar">
            <div className="flex flex-col items-center mb-8 mt-4">
              <div className={`w-24 h-24 rounded-full flex items-center justify-center border shadow-[0_0_20px_rgba(255,191,0,0.2)] mb-4 ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-[#ffbf00]/50' : 'bg-white/5 border-[#ffbf00]/30'}`}>
                <Trophy size={40} className="text-[#ffbf00]" />
              </div>
              <h2 className={`text-2xl font-extrabold ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>
                {unlockedIds.length} / {ACHIEVEMENTS.length}
              </h2>
              <p className={`text-sm uppercase tracking-widest font-bold ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-400'}`}>Unlocked</p>
            </div>

            {/* Unlocked Achievements at the top */}
            {renderAchievementList('Unlocked Achievements', unlockedList, 'text-green-400', true)}
            
            {/* Locked Achievements grouped by difficulty */}
            {renderAchievementList('Easy Challenges', lockedList.filter(a => a.difficulty === 'easy'), 'text-slate-400')}
            {renderAchievementList('Medium Challenges', lockedList.filter(a => a.difficulty === 'medium'), 'text-yellow-400/70')}
            {renderAchievementList('Hard Challenges', lockedList.filter(a => a.difficulty === 'hard'), 'text-red-400/70')}
          </div>

          {/* Rewards Tab */}
          <div className="w-1/2 h-full flex flex-col px-6 overflow-y-auto pb-10 custom-scrollbar">
            <div className="flex flex-col items-center mb-8 mt-4">
              <div className={`w-24 h-24 rounded-full flex items-center justify-center border shadow-[0_0_20px_rgba(0,242,255,0.2)] mb-4 ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-[#00f2ff]/50' : 'bg-white/5 border-[#00f2ff]/30'}`}>
                <Star size={40} className="text-[#00f2ff] animate-pulse" />
              </div>
              <h2 className={`text-2xl font-extrabold ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>
                {UNLOCKABLES.filter(u => u.checkUnlock(unlockedIds)).length} / {UNLOCKABLES.length}
              </h2>
              <p className={`text-sm uppercase tracking-widest font-bold ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-400'}`}>Rewards Unlocked</p>
            </div>

            <div className={`mb-8 p-5 rounded-2xl border-2 ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10' : 'bg-white/5 border-white/10 shadow-[0_0_30px_rgba(0,242,255,0.05)]'}`}>
              <h3 className={`text-xs font-black mb-5 uppercase tracking-[0.3em] flex items-center gap-2 ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>
                <Zap size={18} className="text-yellow-400 animate-pulse" /> Reward Progress
              </h3>
              <div className="space-y-6">
                {UNLOCKABLES.map(item => {
                  const isUnlocked = item.checkUnlock(unlockedIds);
                  const progress = item.getProgress(unlockedIds, stats, score, highScore, combo);
                  const percent = Math.min(100, (progress.current / progress.total) * 100);
                  
                  return (
                    <div key={item.id} className={`space-y-2 ${isUnlocked ? 'opacity-60' : ''}`}>
                      <div className="flex justify-between items-end">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className={`text-sm font-black ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>{item.name}</span>
                            {isUnlocked && (
                              <button 
                                onClick={() => { toggleUnlockable(item.id); triggerHaptic(haptics, 10); }}
                                className={`px-3 h-8 flex items-center justify-center rounded-md text-[8px] font-black uppercase tracking-widest transition-all ${activeUnlockables[item.id] ? 'bg-green-400 text-slate-900' : 'bg-white/10 text-white hover:bg-white/20'}`}
                              >
                                {activeUnlockables[item.id] ? 'Active' : 'Select'}
                              </button>
                            )}
                          </div>
                          <p className="text-[10px] text-gray-500 font-medium">{item.conditionText}</p>
                        </div>
                        <span className={`text-xs font-mono font-bold ${isUnlocked ? 'text-green-400' : 'text-[#00f2ff]'}`}>
                          {isUnlocked ? 'UNLOCKED' : `${progress.current} / ${progress.total}`}
                        </span>
                      </div>
                      <div className={`h-3 w-full rounded-full overflow-hidden p-0.5 ${activeUnlockables.light_theme ? 'bg-slate-900/10' : 'bg-black/40 border border-white/5'}`}>
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${percent}%` }}
                          className={`h-full rounded-full ${isUnlocked ? 'bg-green-400' : 'bg-gradient-to-r from-[#00f2ff] via-[#ff007f] to-[#00f2ff] bg-[length:200%_100%] animate-shimmer shadow-[0_0_10px_rgba(0,242,255,0.5)]'}`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

const SettingsView = ({ onBack, music, setMusic, sfx, setSfx, haptics, setHaptics, screenShake, setScreenShake, activeUnlockables = {}, onResetProgress, currentTrackIndex, playNextTrack }: any) => {
  const [showResetConfirm, setShowResetConfirm] = React.useState(false);
  return (
    <div className={`flex flex-col h-full w-full max-w-md mx-auto pt-safe pb-safe ${activeUnlockables.light_theme ? 'bg-slate-100 text-slate-900' : 'bg-[#221610] text-slate-100'}`} onClick={(e) => e.stopPropagation()}>
      <header className="flex items-center px-6 py-4 justify-between">
        <h2 className="text-2xl font-bold leading-tight tracking-tight flex-1">Settings</h2>
        <button onClick={() => { onBack(); triggerHaptic(haptics, 5); }} className={`flex items-center justify-center rounded-full h-11 w-11 transition-colors ${activeUnlockables.light_theme ? 'bg-slate-900/10 text-slate-900 hover:bg-slate-900/20' : 'bg-[#ec5b13]/10 text-[#ec5b13] hover:bg-[#ec5b13]/20'}`}><X size={24} /></button>
      </header>
      <main className="flex-1 px-6 py-2 space-y-6 overflow-y-auto custom-scrollbar">
        <section>
          <h3 className={`text-sm font-bold uppercase tracking-wider pb-3 pt-2 ${activeUnlockables.light_theme ? 'text-slate-500' : 'text-[#ec5b13]'}`}>Audio</h3>
          <div className="space-y-2">
            <div className={`flex items-center gap-4 px-4 py-3 rounded-xl justify-between border ${activeUnlockables.light_theme ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#ec5b13]/10 border-[#ec5b13]/10'}`}>
              <div className="flex items-center gap-3"><span className={activeUnlockables.light_theme ? 'text-slate-900' : 'text-[#ec5b13]'}>🔊</span><p className={`text-base font-medium ${activeUnlockables.light_theme ? 'text-slate-900' : ''}`}>Sound Effects</p></div>
              <Toggle checked={sfx} onChange={() => setSfx(!sfx)} haptics={haptics} />
            </div>
            <div className={`flex flex-col gap-2 px-4 py-3 rounded-xl border ${activeUnlockables.light_theme ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#ec5b13]/10 border-[#ec5b13]/10'}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3"><span className={activeUnlockables.light_theme ? 'text-slate-900' : 'text-[#ec5b13]'}>🎵</span><p className={`text-base font-medium ${activeUnlockables.light_theme ? 'text-slate-900' : ''}`}>Music</p></div>
                <Toggle checked={music} onChange={() => setMusic(!music)} haptics={haptics} />
              </div>
              {music && (
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
                  <div className="flex-1 overflow-hidden">
                    <p className="text-[10px] font-black text-[#00f2ff] uppercase tracking-widest leading-none mb-1">Now Playing</p>
                    <p className="text-xs font-bold truncate pr-2">{TRACKS[currentTrackIndex].name}</p>
                  </div>
                  <button 
                    onClick={() => { playNextTrack(); triggerHaptic(haptics, 10); }}
                    className={`flex items-center gap-2 px-4 h-11 rounded-xl text-xs font-bold uppercase tracking-widest transition-colors ${activeUnlockables.light_theme ? 'bg-slate-900 text-white hover:bg-slate-800' : 'bg-[#ec5b13] text-white hover:bg-[#ec5b13]/80'}`}
                  >
                    <RefreshCw size={14} /> Skip
                  </button>
                </div>
              )}
            </div>
          </div>
        </section>

        <section>
          <h3 className={`text-sm font-bold uppercase tracking-wider pb-3 pt-2 ${activeUnlockables.light_theme ? 'text-slate-500' : 'text-[#ec5b13]'}`}>Accessibility</h3>
          <div className="space-y-2">
            <div className={`flex items-center gap-4 px-4 py-3 rounded-xl justify-between border ${activeUnlockables.light_theme ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#ec5b13]/10 border-[#ec5b13]/10'}`}>
              <div className="flex items-center gap-3"><span className={activeUnlockables.light_theme ? 'text-slate-900' : 'text-[#ec5b13]'}>📳</span><p className={`text-base font-medium ${activeUnlockables.light_theme ? 'text-slate-900' : ''}`}>Haptic Feedback</p></div>
              <Toggle checked={haptics} onChange={() => setHaptics(!haptics)} haptics={haptics} />
            </div>
            <div className={`flex items-center gap-4 px-4 py-3 rounded-xl justify-between border ${activeUnlockables.light_theme ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#ec5b13]/10 border-[#ec5b13]/10'}`}>
              <div className="flex items-center gap-3"><span className={activeUnlockables.light_theme ? 'text-slate-900' : 'text-[#ec5b13]'}>🫨</span><p className={`text-base font-medium ${activeUnlockables.light_theme ? 'text-slate-900' : ''}`}>Screen Shake</p></div>
              <Toggle checked={screenShake} onChange={() => setScreenShake(!screenShake)} haptics={haptics} />
            </div>
          </div>
        </section>
        <section>
          <h3 className={`text-sm font-bold uppercase tracking-wider pb-3 ${activeUnlockables.light_theme ? 'text-slate-500' : 'text-[#ec5b13]'}`}>Account</h3>
          <div className="space-y-3">
            <button 
              onClick={() => { setShowResetConfirm(true); triggerHaptic(haptics, 20); }}
              className={`w-full h-12 flex items-center justify-center gap-2 font-bold rounded-xl border transition-colors ${activeUnlockables.light_theme ? 'bg-red-50 text-red-600 border-red-200 hover:bg-red-100' : 'bg-red-500/10 text-red-500 border-red-500/20 hover:bg-red-500/20'}`}
            >
              <RotateCcw size={20} /> Reset Progress
            </button>
          </div>
        </section>
        <section>
          <h3 className={`text-sm font-bold uppercase tracking-wider pb-3 ${activeUnlockables.light_theme ? 'text-slate-500' : 'text-[#ec5b13]'}`}>About</h3>
          <div className="space-y-3">
            <button className={`w-full h-12 flex items-center justify-between gap-2 font-medium px-4 rounded-xl border transition-colors ${activeUnlockables.light_theme ? 'bg-white text-slate-900 border-slate-200 shadow-sm hover:bg-slate-50' : 'bg-[#ec5b13]/10 text-white border-[#ec5b13]/10 hover:bg-[#ec5b13]/20'}`}>
              <div className="flex items-center gap-3"><FileText size={20} className={activeUnlockables.light_theme ? 'text-slate-500' : 'text-[#ec5b13]'} /> Terms of Service</div>
            </button>
            <button className={`w-full h-12 flex items-center justify-between gap-2 font-medium px-4 rounded-xl border transition-colors ${activeUnlockables.light_theme ? 'bg-white text-slate-900 border-slate-200 shadow-sm hover:bg-slate-50' : 'bg-[#ec5b13]/10 text-white border-[#ec5b13]/10 hover:bg-[#ec5b13]/20'}`}>
              <div className="flex items-center gap-3"><Shield size={20} className={activeUnlockables.light_theme ? 'text-slate-500' : 'text-[#ec5b13]'} /> Privacy Policy</div>
            </button>
          </div>
        </section>
        <section className="pb-8">
          <h3 className={`text-sm font-bold uppercase tracking-wider pb-3 ${activeUnlockables.light_theme ? 'text-slate-500' : 'text-[#ec5b13]'}`}>Share</h3>
          <div className="flex items-center justify-center gap-4">
            <button className={`flex items-center justify-center h-12 w-12 rounded-xl border transition-colors ${activeUnlockables.light_theme ? 'bg-white text-slate-600 border-slate-200 shadow-sm hover:bg-slate-50' : 'bg-[#ec5b13]/10 text-[#ec5b13] border-[#ec5b13]/10 hover:bg-[#ec5b13]/20'}`}>
              <Facebook size={24} />
            </button>
            <button className={`flex items-center justify-center h-12 w-12 rounded-xl border transition-colors ${activeUnlockables.light_theme ? 'bg-white text-slate-600 border-slate-200 shadow-sm hover:bg-slate-50' : 'bg-[#ec5b13]/10 text-[#ec5b13] border-[#ec5b13]/10 hover:bg-[#ec5b13]/20'}`}>
              <Instagram size={24} />
            </button>
            <button className={`flex items-center justify-center h-12 w-12 rounded-xl border transition-colors ${activeUnlockables.light_theme ? 'bg-white text-slate-600 border-slate-200 shadow-sm hover:bg-slate-50' : 'bg-[#ec5b13]/10 text-[#ec5b13] border-[#ec5b13]/10 hover:bg-[#ec5b13]/20'}`}>
              <Twitter size={24} />
            </button>
            <button className={`flex items-center justify-center h-12 w-12 rounded-xl border transition-colors ${activeUnlockables.light_theme ? 'bg-white text-slate-600 border-slate-200 shadow-sm hover:bg-slate-50' : 'bg-[#ec5b13]/10 text-[#ec5b13] border-[#ec5b13]/10 hover:bg-[#ec5b13]/20'}`}>
              <Share2 size={24} />
            </button>
          </div>
        </section>
        <section className="pb-8">
          <h3 className={`text-sm font-bold uppercase tracking-wider pb-3 ${activeUnlockables.light_theme ? 'text-slate-500' : 'text-[#ec5b13]'}`}>Connect With Us</h3>
          <div className="flex items-center justify-center gap-4">
            <button className={`flex items-center justify-center h-12 w-12 rounded-xl border transition-colors ${activeUnlockables.light_theme ? 'bg-white text-slate-600 border-slate-200 shadow-sm hover:bg-slate-50' : 'bg-[#ec5b13]/10 text-[#ec5b13] border-[#ec5b13]/10 hover:bg-[#ec5b13]/20'}`}>
              <Mail size={24} />
            </button>
          </div>
        </section>
      </main>

      <AnimatePresence>
        {showResetConfirm && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md"
            onClick={() => setShowResetConfirm(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className={`w-full max-w-xs p-6 rounded-3xl shadow-2xl border ${activeUnlockables.light_theme ? 'bg-white border-slate-200' : 'bg-[#221610] border-[#ec5b13]/30'}`}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex flex-col items-center text-center gap-4">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center ${activeUnlockables.light_theme ? 'bg-red-50 text-red-500' : 'bg-red-500/20 text-red-500'}`}>
                  <AlertCircle size={32} />
                </div>
                <div>
                  <h3 className={`text-xl font-bold mb-2 ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>Reset Progress?</h3>
                  <p className={`text-sm leading-relaxed ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-slate-400'}`}>
                    This will permanently delete your high scores, achievements, and all unlocked themes. This cannot be undone.
                  </p>
                </div>
                <div className="w-full flex flex-col gap-2 mt-2">
                  <button 
                    onClick={() => { onResetProgress(); triggerHaptic(haptics, 50); }}
                    className="w-full py-3 bg-red-600 text-white font-bold rounded-xl active:scale-95 transition-transform"
                  >
                    YES, RESET EVERYTHING
                  </button>
                  <button 
                    onClick={() => { setShowResetConfirm(false); triggerHaptic(haptics, 5); }}
                    className={`w-full py-3 font-bold rounded-xl active:scale-95 transition-transform ${activeUnlockables.light_theme ? 'bg-slate-100 text-slate-900' : 'bg-white/10 text-white'}`}
                  >
                    CANCEL
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const ThemeParticles = ({ activeUnlockables, score }: { activeUnlockables: Record<string, boolean>, score: number }) => {
  const isVolcano = activeUnlockables.volcano;
  const isOceanic = activeUnlockables.oceanic;
  const isSynthwave = activeUnlockables.synthwave;
  const isCyberpunk = activeUnlockables.cyberpunk;
  const isNebula = activeUnlockables.nebula;
  const isMinimalist = activeUnlockables.minimalist;
  const isDisco = activeUnlockables.disco_grid;
  const isRainbow = activeUnlockables.rainbow_rings;

  // More particles for higher scores
  const count = Math.min(100, 20 + Math.floor(score / 500));

  if (isVolcano) {
    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(count)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-orange-500 blur-[1px]"
            style={{
              width: Math.random() * 4 + 2,
              height: Math.random() * 4 + 2,
              left: `${Math.random() * 100}%`,
              bottom: '-5%',
            }}
            animate={{
              y: [0, -1000],
              x: (Math.random() - 0.5) * 200,
              opacity: [0, 1, 0],
              scale: [1, 2, 0.5],
            }}
            transition={{
              duration: 2 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "easeOut"
            }}
          />
        ))}
      </div>
    );
  }

  if (isOceanic) {
    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(count)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full border border-white/30 bg-white/10 blur-[1px]"
            style={{
              width: Math.random() * 15 + 5,
              height: Math.random() * 15 + 5,
              left: `${Math.random() * 100}%`,
              bottom: '-10%',
            }}
            animate={{
              y: [0, -1200],
              x: Math.sin(i) * 50,
              opacity: [0, 0.6, 0],
            }}
            transition={{
              duration: 5 + Math.random() * 10,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "linear",
            }}
          />
        ))}
      </div>
    );
  }

  if (isSynthwave) {
    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(count)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bg-pink-500/40"
            style={{
              width: Math.random() * 20 + 10,
              height: 2,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              x: [-200, 1200],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 1 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "linear",
            }}
          />
        ))}
      </div>
    );
  }

  if (isNebula) {
    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(count)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-white"
            style={{
              width: Math.random() * 3 + 1,
              height: Math.random() * 3 + 1,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              scale: [1, 2, 1],
              opacity: [0.2, 1, 0.2],
            }}
            transition={{
              duration: 2 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>
    );
  }

  if (isCyberpunk) {
    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(count)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute border border-lime-400/40 bg-lime-400/10"
            style={{
              width: Math.random() * 12 + 4,
              height: Math.random() * 12 + 4,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0, 0.6, 0],
              scale: [0.5, 1.2, 0.5],
              rotate: [0, 90, 180],
              x: (Math.random() - 0.5) * 100,
              y: (Math.random() - 0.5) * 100,
            }}
            transition={{
              duration: 1 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          >
            {/* Inner "glitch" line */}
            <motion.div 
              className="absolute inset-0 bg-lime-400/20"
              animate={{
                clipPath: [
                  'inset(0 0 80% 0)',
                  'inset(40% 0 40% 0)',
                  'inset(80% 0 0 0)',
                ]
              }}
              transition={{ duration: 0.2, repeat: Infinity }}
            />
          </motion.div>
        ))}
        {/* Rapid data fragments */}
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={`frag-${i}`}
            className="absolute text-[8px] font-mono text-lime-400/30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0, 1, 0],
              x: [0, (Math.random() - 0.5) * 200],
            }}
            transition={{
              duration: 0.1 + Math.random() * 0.2,
              repeat: Infinity,
              repeatDelay: Math.random() * 2,
            }}
          >
            {Math.random().toString(16).substring(2, 6).toUpperCase()}
          </motion.div>
        ))}
      </div>
    );
  }

  if (isDisco) {
    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(count)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: Math.random() * 30 + 10,
              height: Math.random() * 30 + 10,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              backgroundColor: `hsl(${Math.random() * 360}, 70%, 60%)`,
            }}
            animate={{
              opacity: [0, 0.4, 0],
              scale: [0.5, 1.2, 0.5],
            }}
            transition={{
              duration: 1 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>
    );
  }

  if (isRainbow) {
    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(count)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full border-2"
            style={{
              width: Math.random() * 40 + 20,
              height: Math.random() * 40 + 20,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              borderColor: `hsl(${Math.random() * 360}, 80%, 50%)`,
            }}
            animate={{
              opacity: [0, 0.6, 0],
              scale: [0.2, 1.5, 0.2],
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>
    );
  }

  if (isMinimalist) {
    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(count / 2)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute border border-slate-300"
            style={{
              width: 20,
              height: 20,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              rotate: [0, 180],
              opacity: [0, 0.3, 0],
            }}
            transition={{
              duration: 5 + Math.random() * 5,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>
    );
  }

  return <Confetti />;
};

const GameOverView = ({ score, highScore, onPlayAgain, onHome, activeUnlockables = {}, haptics }: any) => {
  const isNewHighScore = score >= highScore && score > 0;
  
  const themeColor = activeUnlockables.volcano ? 'text-orange-500' : 
                    activeUnlockables.oceanic ? 'text-cyan-400' :
                    activeUnlockables.synthwave ? 'text-pink-500' :
                    activeUnlockables.cyberpunk ? 'text-lime-400' :
                    activeUnlockables.nebula ? 'text-purple-400' :
                    activeUnlockables.disco_grid ? 'text-yellow-400' :
                    activeUnlockables.rainbow_rings ? 'text-red-400' :
                    activeUnlockables.light_theme ? 'text-slate-900' : 'text-white';

  const themeGlow = activeUnlockables.volcano ? 'from-orange-500/20 to-red-600/20' : 
                    activeUnlockables.oceanic ? 'from-cyan-400/20 to-blue-600/20' :
                    activeUnlockables.synthwave ? 'from-pink-500/20 to-purple-600/20' :
                    activeUnlockables.cyberpunk ? 'from-lime-400/20 to-emerald-600/20' :
                    activeUnlockables.nebula ? 'from-purple-400/20 to-indigo-600/20' :
                    activeUnlockables.disco_grid ? 'from-yellow-400/20 to-orange-600/20' :
                    activeUnlockables.rainbow_rings ? 'from-red-400/20 to-pink-600/20' :
                    activeUnlockables.light_theme ? 'from-slate-200 to-slate-300' : 'from-white/5 to-white/0';

  return (
    <div className={`flex items-center justify-center h-full w-full relative overflow-hidden pt-safe pb-safe ${activeUnlockables.light_theme ? 'bg-slate-100' : 'bg-black'}`}>
      {/* Dynamic Background Glow */}
      <motion.div 
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.6, 0.3] 
        }}
        transition={{ 
          duration: 4, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
        className={`absolute inset-0 bg-gradient-to-br ${themeGlow} blur-[100px] z-0`}
      />

      <div className={`absolute top-0 left-0 w-full h-full blur-[20px] z-[0] ${activeUnlockables.light_theme ? 'bg-[radial-gradient(circle_at_center,#f1f5f9_0%,#e2e8f0_100%)]' : 'bg-[radial-gradient(circle_at_center,#2c2c2e_0%,#000_100%)]'}`}>
        <div className={`absolute rounded-full border-8 w-48 h-48 top-1/4 left-1/4 opacity-10 ${activeUnlockables.volcano ? 'border-orange-500' : 'border-pink-500'}`}></div>
        <div className={`absolute rounded-full border-8 w-32 h-32 top-1/2 right-1/4 opacity-10 ${activeUnlockables.oceanic ? 'border-cyan-400' : 'border-blue-400'}`}></div>
        <div className={`absolute rounded-full border-8 w-40 h-40 bottom-1/4 left-1/3 opacity-10 ${activeUnlockables.synthwave ? 'border-pink-500' : 'border-yellow-400'}`}></div>
      </div>
      
      <ThemeParticles activeUnlockables={activeUnlockables} score={score} />
      
      <main className="relative z-10 w-full max-w-sm px-6 text-center">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", damping: 12, stiffness: 200 }}
        >
          <h1 className={`text-6xl font-black tracking-tighter mb-2 drop-shadow-2xl ${themeColor}`}>
            GAME OVER
          </h1>
        </motion.div>

        <AnimatePresence>
          {isNewHighScore && (
            <motion.div 
              initial={{ y: 20, opacity: 0, scale: 0.8, rotate: -5 }}
              animate={{ y: 0, opacity: 1, scale: 1, rotate: 0 }}
              className="mb-8 flex justify-center"
            >
              <div className="relative group">
                <motion.div 
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="absolute -inset-1 bg-gradient-to-r from-yellow-400 via-orange-500 to-yellow-400 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"
                ></motion.div>
                <div className="relative bg-black text-white px-8 py-3 rounded-full font-black flex items-center gap-2 border-2 border-yellow-400/50">
                  <Trophy size={24} className="text-yellow-400" />
                  <span className="bg-gradient-to-r from-yellow-200 to-yellow-500 bg-clip-text text-transparent">
                    NEW HIGH SCORE!
                  </span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.div 
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className={`backdrop-blur-xl border rounded-[2.5rem] p-10 mb-10 shadow-[0_20px_50px_rgba(0,0,0,0.3)] ${activeUnlockables.light_theme ? 'bg-white/60 border-slate-200' : 'bg-white/5 border-white/10'}`}
        >
          <p className={`text-xs font-black uppercase tracking-[0.3em] mb-2 ${activeUnlockables.light_theme ? 'text-slate-500' : 'text-gray-400'}`}>Final Score</p>
          
          <motion.p 
            className={`text-8xl font-black tracking-tighter ${themeColor}`}
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", damping: 10, stiffness: 100, delay: 0.4 }}
          >
            {score.toLocaleString()}
          </motion.p>
          
          <div className={`mt-8 pt-6 border-t flex justify-center gap-12 ${activeUnlockables.light_theme ? 'border-slate-200' : 'border-white/10'}`}>
            <div className="text-center">
              <p className={`text-[10px] font-black uppercase tracking-widest mb-1 ${activeUnlockables.light_theme ? 'text-slate-400' : 'text-gray-500'}`}>Best</p>
              <p className={`text-2xl font-black ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>
                {Math.max(score, highScore).toLocaleString()}
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div 
          className="flex flex-col gap-4"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <button 
            onClick={() => { onPlayAgain(); triggerHaptic(haptics, 15); }} 
            className={`group relative overflow-hidden w-full font-black h-14 rounded-2xl text-2xl active:scale-95 transition-all shadow-xl ${activeUnlockables.light_theme ? 'bg-slate-900 text-white' : 'bg-white text-black'}`}
          >
            <span className="relative z-10 flex items-center justify-center gap-3">
              <RotateCcw size={24} className="group-hover:rotate-180 transition-transform duration-500" />
              PLAY AGAIN
            </span>
          </button>
          
          <button 
            onClick={() => { onHome(); triggerHaptic(haptics, 10); }} 
            className={`w-full backdrop-blur-md border font-black h-12 rounded-2xl text-lg active:scale-95 transition-all ${activeUnlockables.light_theme ? 'bg-white/50 border-slate-200 text-slate-600 hover:bg-white/80' : 'bg-white/5 border-white/10 text-white hover:bg-white/10'}`}
          >
            <span className="flex items-center justify-center gap-2">
              <Home size={20} />
              HOME
            </span>
          </button>
        </motion.div>
      </main>
    </div>
  );
};

const ContinueModal = ({ onContinue, onSkip, retriesLeft, activeUnlockables = {}, startingCombo = 0, haptics }: any) => (
  <div 
    className={`fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-sm ${activeUnlockables.light_theme ? 'bg-slate-900/40' : 'bg-black/80'}`}
    onClick={() => { onSkip(); triggerHaptic(haptics, 5); }}
  >
    <div 
      className={`border rounded-3xl p-6 w-full max-w-sm text-center shadow-2xl ${activeUnlockables.light_theme ? 'bg-white border-slate-200' : 'bg-[#1e293b] border-white/10'}`}
      onClick={(e) => e.stopPropagation()}
    >
      <h2 className={`text-2xl font-black mb-2 ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>OUT OF MOVES!</h2>
      <p className={`mb-6 text-sm ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-400'}`}>
        Watch a quick ad to clear some space and keep your score going.
        {startingCombo > 0 && (
          <span className="block mt-2 font-black text-transparent bg-clip-text bg-gradient-to-r from-[#00f2ff] to-[#ff007f] text-lg animate-pulse">
            BONUS: START AT x{startingCombo} COMBO!
          </span>
        )}
      </p>
      <div className="flex flex-col gap-3">
        <button 
          onClick={() => { onContinue(); triggerHaptic(haptics, 15); }}
          className="w-full bg-gradient-to-r from-[#00f2ff] to-[#ff007f] text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-md"
        >
          <Video size={20} />
          CONTINUE ({retriesLeft} LEFT)
        </button>
        <button 
          onClick={() => { onSkip(); triggerHaptic(haptics, 5); }}
          className={`w-full font-bold py-3 rounded-xl active:scale-95 transition-all ${activeUnlockables.light_theme ? 'bg-slate-100 text-slate-500 hover:bg-slate-200' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
        >
          NO THANKS
        </button>
      </div>
    </div>
  </div>
);

const AchievementsModal = ({ 
  onClose, 
  unlockedAchievements, 
  activeUnlockables, 
  toggleUnlockable,
  stats,
  score,
  highScore,
  combo,
  haptics
}: { 
  onClose: () => void, 
  unlockedAchievements: string[], 
  activeUnlockables: Record<string, boolean>, 
  toggleUnlockable: (id: string) => void,
  stats: GameStats,
  score: number,
  highScore: number,
  combo: number,
  haptics?: boolean
}) => {
  const [activeTab, setActiveTab] = useState<'achievements' | 'rewards'>('achievements');

  const unlockedList = ACHIEVEMENTS.filter(a => unlockedAchievements.includes(a.id));
  const lockedList = ACHIEVEMENTS.filter(a => !unlockedAchievements.includes(a.id));

  const renderAchievementList = (title: string, achievements: Achievement[], colorClass: string, isUnlockedSection: boolean = false) => {
    if (achievements.length === 0) return null;
    return (
      <div className="mb-8">
        <h3 className={`text-sm font-black mb-4 uppercase tracking-[0.2em] flex items-center gap-2 ${colorClass}`}>
          {isUnlockedSection ? <Shield size={16} /> : <Lock size={16} />} {title}
        </h3>
        <div className="space-y-3">
          {achievements.map(ach => {
            const isUnlocked = unlockedAchievements.includes(ach.id);
            let currentProgress = 0;
            if (ach.statKey) {
              if (ach.statKey === 'score') currentProgress = Math.max(score, highScore);
              else if (ach.statKey === 'combo') currentProgress = combo;
              else currentProgress = stats[ach.statKey as keyof GameStats] || 0;
            }

            return (
              <div key={ach.id} className={`flex items-center gap-4 p-3 rounded-xl border transition-all ${isUnlocked ? (activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10 shadow-sm' : 'bg-white/10 border-white/20 shadow-lg shadow-yellow-500/5') : (activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/5 opacity-50' : 'bg-black/20 border-white/5 opacity-50')}`}>
                <div className="text-3xl filter drop-shadow-md">{ach.icon}</div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h3 className={`font-bold text-sm ${isUnlocked ? (activeUnlockables.light_theme ? 'text-slate-900' : 'text-white') : (activeUnlockables.light_theme ? 'text-slate-500' : 'text-gray-400')}`}>{ach.title}</h3>
                    {!isUnlocked && ach.target && (
                      <span className="text-[10px] font-mono text-gray-500">{currentProgress} / {ach.target}</span>
                    )}
                  </div>
                  <p className={`text-[10px] leading-tight ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-500'}`}>{ach.description}</p>
                  {!isUnlocked && ach.target && (
                    <div className="mt-1.5 h-1 w-full bg-black/20 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-yellow-400/50" 
                        style={{ width: `${Math.min(100, (currentProgress / ach.target) * 100)}%` }}
                      />
                    </div>
                  )}
                </div>
                {isUnlocked && <div className="text-green-400"><Shield size={16} /></div>}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div 
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-sm ${activeUnlockables.light_theme ? 'bg-slate-900/40' : 'bg-black/80'}`}
      onClick={() => { onClose(); triggerHaptic(haptics, 5); }}
    >
      <div 
        className={`border rounded-3xl p-6 w-full max-w-md shadow-2xl relative max-h-[85vh] flex flex-col ${activeUnlockables.light_theme ? 'bg-white border-slate-200' : 'bg-[#1e293b] border-white/10'}`}
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={() => { onClose(); triggerHaptic(haptics, 5); }} className={`absolute top-4 right-4 transition-colors z-10 ${activeUnlockables.light_theme ? 'text-slate-400 hover:text-slate-900' : 'text-white/50 hover:text-white'}`}>
          <X size={24} />
        </button>
        
        <div className={`flex justify-center gap-4 mb-6 border-b pb-2 ${activeUnlockables.light_theme ? 'border-slate-200' : 'border-white/10'}`}>
          <button 
            onClick={() => { setActiveTab('achievements'); triggerHaptic(haptics, 10); }}
            className={`text-xl font-black flex items-center gap-2 transition-colors ${activeTab === 'achievements' ? 'text-yellow-400' : (activeUnlockables.light_theme ? 'text-slate-400 hover:text-slate-600' : 'text-gray-500 hover:text-gray-300')}`}
          >
            <Trophy size={20} /> ACHIEVEMENTS
          </button>
          <button 
            onClick={() => { setActiveTab('rewards'); triggerHaptic(haptics, 10); }}
            className={`text-xl font-black flex items-center gap-2 transition-colors ${activeTab === 'rewards' ? 'text-[#00f2ff]' : (activeUnlockables.light_theme ? 'text-slate-400 hover:text-slate-600' : 'text-gray-500 hover:text-gray-300')}`}
          >
            <Star size={20} /> REWARDS
          </button>
        </div>

        <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
          {activeTab === 'achievements' ? (
            <>
              {/* Reward Progress Section - Showing all unlockables */}
              <div className={`mb-8 p-5 rounded-2xl border-2 ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10' : 'bg-white/5 border-white/10 shadow-[0_0_30px_rgba(0,242,255,0.05)]'}`}>
                <h3 className={`text-xs font-black mb-5 uppercase tracking-[0.3em] flex items-center gap-2 ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>
                  <Star size={18} className="text-yellow-400 animate-pulse" /> Reward Progress
                </h3>
                <div className="space-y-6">
                  {UNLOCKABLES.map(item => {
                    const isUnlocked = item.checkUnlock(unlockedAchievements);
                    const progress = item.getProgress(unlockedAchievements, stats, score, highScore, combo);
                    const percent = Math.min(100, (progress.current / progress.total) * 100);
                    
                    return (
                      <div key={item.id} className={`space-y-2 ${isUnlocked ? 'opacity-60' : ''}`}>
                        <div className="flex justify-between items-end">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className={`text-sm font-black ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>{item.name}</span>
                              {isUnlocked && <Shield size={12} className="text-green-400" />}
                            </div>
                            <p className="text-[10px] text-gray-500 font-medium">{item.conditionText}</p>
                          </div>
                          <span className={`text-xs font-mono font-bold ${isUnlocked ? 'text-green-400' : 'text-[#00f2ff]'}`}>
                            {isUnlocked ? 'UNLOCKED' : `${progress.current} / ${progress.total}`}
                          </span>
                        </div>
                        <div className={`h-3 w-full rounded-full overflow-hidden p-0.5 ${activeUnlockables.light_theme ? 'bg-slate-900/10' : 'bg-black/40 border border-white/5'}`}>
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${percent}%` }}
                            className={`h-full rounded-full ${isUnlocked ? 'bg-green-400' : 'bg-gradient-to-r from-[#00f2ff] via-[#ff007f] to-[#00f2ff] bg-[length:200%_100%] animate-shimmer shadow-[0_0_10px_rgba(0,242,255,0.5)]'}`}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Unlocked Achievements at the top */}
              {renderAchievementList('Unlocked Achievements', unlockedList, 'text-green-400', true)}
              
              {/* Locked Achievements grouped by difficulty */}
              {renderAchievementList('Easy Challenges', lockedList.filter(a => a.difficulty === 'easy'), 'text-slate-400')}
              {renderAchievementList('Medium Challenges', lockedList.filter(a => a.difficulty === 'medium'), 'text-yellow-400/70')}
              {renderAchievementList('Hard Challenges', lockedList.filter(a => a.difficulty === 'hard'), 'text-red-400/70')}
            </>
          ) : (
            <div className="space-y-4">
              {/* Reward Progress Section for Rewards Tab */}
              <div className={`p-4 rounded-2xl border ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10' : 'bg-white/5 border-white/10'}`}>
                <h3 className={`text-sm font-black mb-4 uppercase tracking-[0.2em] flex items-center gap-2 ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>
                  <Star size={16} className="text-yellow-400" /> Next Rewards
                </h3>
                <div className="space-y-4">
                  {UNLOCKABLES.filter(item => !item.checkUnlock(unlockedAchievements)).slice(0, 2).map(item => {
                    const progress = item.getProgress(unlockedAchievements, stats, score, highScore, combo);
                    const percent = Math.min(100, (progress.current / progress.total) * 100);
                    
                    return (
                      <div key={item.id} className="space-y-1.5">
                        <div className="flex justify-between items-end">
                          <div>
                            <span className={`text-xs font-bold ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>{item.name}</span>
                            <p className="text-[10px] text-gray-500 leading-tight">{item.conditionText}</p>
                          </div>
                          <span className="text-[10px] font-mono text-gray-400">{progress.current}/{progress.total}</span>
                        </div>
                        <div className={`h-1.5 w-full rounded-full overflow-hidden ${activeUnlockables.light_theme ? 'bg-slate-900/10' : 'bg-white/10'}`}>
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${percent}%` }}
                            className="h-full bg-gradient-to-r from-[#00f2ff] to-[#ff007f]"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <p className={`text-sm mb-4 text-center ${activeUnlockables.light_theme ? 'text-slate-500' : 'text-gray-400'}`}>Unlock special themes, styles, and modes by completing achievements!</p>
              {UNLOCKABLES.map(item => {
                const isUnlocked = item.checkUnlock(unlockedAchievements);
                const isActive = activeUnlockables[item.id];
                
                return (
                  <div key={item.id} className={`p-4 rounded-xl border ${isUnlocked ? (activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10' : 'bg-white/5 border-white/20') : (activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/5 opacity-60' : 'bg-black/40 border-white/5 opacity-60')}`}>
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className={`font-bold text-lg flex items-center gap-2 ${isUnlocked ? (activeUnlockables.light_theme ? 'text-slate-900' : 'text-white') : (activeUnlockables.light_theme ? 'text-slate-400' : 'text-gray-500')}`}>
                          {!isUnlocked ? <Lock size={16} /> : <Shield size={16} className="text-green-400" />}
                          {item.name}
                          <span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full ml-2 ${activeUnlockables.light_theme ? 'bg-slate-900/10 text-slate-600' : 'bg-white/10 text-gray-300'}`}>
                            {item.type}
                          </span>
                        </h3>
                        <p className={`text-sm ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-gray-400'}`}>{item.description}</p>
                      </div>
                      {isUnlocked && (
                        <button 
                          onClick={() => { toggleUnlockable(item.id); triggerHaptic(haptics, 10); }}
                          className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${isActive ? 'bg-green-400 text-slate-900' : 'bg-white/10 text-white hover:bg-white/20'}`}
                        >
                          {isActive ? 'Active' : 'Select'}
                        </button>
                      )}
                    </div>
                    {!isUnlocked && (
                      <div className={`mt-3 pt-3 border-t text-xs font-semibold flex items-center gap-1 ${activeUnlockables.light_theme ? 'border-slate-900/5 text-[#ff007f]' : 'border-white/5 text-[#ff007f]'}`}>
                        <AlertCircle size={12} /> {item.conditionText}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const AchievementToast = ({ achievement, activeUnlockables = {} }: { achievement: Achievement, activeUnlockables?: Record<string, boolean> }) => (
  <motion.div
    initial={{ y: -100, opacity: 0 }}
    animate={{ y: 0, opacity: 1 }}
    exit={{ y: -100, opacity: 0 }}
    className={`fixed top-20 left-1/2 -translate-x-1/2 z-[100] backdrop-blur-md border rounded-2xl p-3 shadow-2xl flex items-center gap-4 min-w-[280px] ${
      activeUnlockables.synthwave 
        ? 'bg-black/80 border-[#ff007f] shadow-[0_0_20px_rgba(255,0,127,0.3)]' 
        : 'bg-gradient-to-r from-yellow-500/90 to-orange-500/90 border-yellow-300/50'
    }`}
  >
    <div className={`text-4xl animate-bounce ${activeUnlockables.synthwave ? 'drop-shadow-[0_0_10px_#ff007f]' : ''}`}>{achievement.icon}</div>
    <div>
      <p className={`text-[10px] uppercase tracking-widest font-bold mb-0.5 ${activeUnlockables.synthwave ? 'retro-text text-cyan-400' : 'text-yellow-100'}`}>Achievement Unlocked!</p>
      <h4 className={`font-black text-lg leading-tight ${activeUnlockables.synthwave ? 'retro-text text-white' : 'text-white'}`}>{achievement.title}</h4>
    </div>
  </motion.div>
);



const PointsTicker = ({ points, color, activeUnlockables = {} }: { points: number, color: Color, activeUnlockables?: Record<string, boolean> }) => {
  return (
    <motion.div
      initial={{ x: "100%", opacity: 0 }}
      animate={{ x: "-100%", opacity: 1 }}
      transition={{ duration: 2, ease: "linear" }}
      className="absolute top-0 left-0 w-full h-8 z-[70] pointer-events-none flex items-center whitespace-nowrap"
    >
      <div className="flex items-center gap-4 px-4 py-1">
        {Array(10).fill(0).map((_, i) => (
          <span key={i} className={`text-sm font-black italic ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`} style={{ textShadow: `0 0 10px ${getThemeColor(color, activeUnlockables)}` }}>
            +{points} POINTS!
          </span>
        ))}
      </div>
    </motion.div>
  );
};

interface GameStats {
  gamesPlayed: number;
  ringsPlaced: number;
  linesCleared: number;
  hintsUsed: number;
  critsLanded: number;
  megaCritsLanded: number;
  totalMatches: number;
  perfectClears: number;
  highestCombo: number;
  retriesUsed: number;
}

const defaultStats: GameStats = {
  gamesPlayed: 0,
  ringsPlaced: 0,
  linesCleared: 0,
  hintsUsed: 0,
  critsLanded: 0,
  megaCritsLanded: 0,
  totalMatches: 0,
  perfectClears: 0,
  highestCombo: 0,
  retriesUsed: 0,
};

const SynthwaveBackground = ({ combo, activeUnlockables }: { combo: number, activeUnlockables: Record<string, boolean> }) => {
  if (!activeUnlockables.synthwave) return null;

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      {/* Retro CRT Overlays */}
      <div className="absolute inset-0 z-[100] retro-crt-screen opacity-40" />
      <div className="absolute inset-0 z-[101] retro-vignette" />
      <div className="absolute inset-0 z-[102] retro-flicker pointer-events-none bg-white/5" />
      
      {/* Stars */}
      <div className="absolute top-0 left-0 w-full h-1/2 overflow-hidden">
        {[...Array(40)].map((_, i) => (
          <motion.div
            key={`star-${i}`}
            className="absolute bg-white rounded-full"
            style={{
              width: Math.random() * 3 + 'px',
              height: Math.random() * 3 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              opacity: Math.random() * 0.8 + 0.2,
              boxShadow: '0 0 4px #fff'
            }}
            animate={{ opacity: [0.2, 1, 0.2] }}
            transition={{ duration: 2 + Math.random() * 3, repeat: Infinity, delay: Math.random() * 2 }}
          />
        ))}
      </div>

      {/* Sun */}
      <motion.div 
        className="absolute top-[15%] left-1/2 -translate-x-1/2 w-56 h-56 rounded-full overflow-hidden"
        style={{
          background: 'linear-gradient(to bottom, #ff00ff 0%, #ff8c00 100%)',
          boxShadow: '0 0 40px #ff00ff, 0 0 80px #ff8c00',
        }}
        animate={{
          scale: [1, 1.05 + (Math.min(combo, 20) * 0.01), 1],
          opacity: [0.6, 0.8 + (Math.min(combo, 20) * 0.02), 0.6],
          x: combo > 5 ? ['-50%', '-49%', '-51%', '-50%'] : '-50%',
        }}
        transition={{ 
          scale: { duration: 3, repeat: Infinity, ease: "easeInOut" },
          opacity: { duration: 3, repeat: Infinity, ease: "easeInOut" },
          x: { duration: 0.1, repeat: combo > 5 ? Infinity : 0 }
        }}
      >
        {/* Sun stripes */}
        <div className="absolute inset-0 flex flex-col justify-end pb-2">
          {[...Array(7)].map((_, i) => (
            <div 
              key={`stripe-${i}`} 
              className="w-full bg-[#0F172A]" 
              style={{ 
                height: `${(i + 1) * 3}px`, 
                marginBottom: `${(i + 1) * 4}px`,
                opacity: 0.8
              }}
            />
          ))}
        </div>
      </motion.div>
      
      {/* Mountains */}
      <div className="absolute top-[50%] left-0 w-full h-32 -translate-y-full overflow-hidden flex items-end justify-center opacity-80">
        <svg viewBox="0 0 1000 200" className="w-[200%] h-full min-w-[1000px] fill-transparent stroke-[#ff00ff] stroke-2" preserveAspectRatio="none">
          <defs>
            <linearGradient id="mountain-grad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#00ffff" />
              <stop offset="100%" stopColor="#ff00ff" />
            </linearGradient>
            <linearGradient id="mountain-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#0F172A" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#1a0b2e" stopOpacity="1" />
            </linearGradient>
          </defs>
          <path d="M0 200 L100 100 L200 150 L350 50 L500 180 L650 80 L800 160 L900 90 L1000 200 Z" fill="url(#mountain-fill)" />
          <path d="M0 200 L100 100 L200 150 L350 50 L500 180 L650 80 L800 160 L900 90 L1000 200 Z" stroke="url(#mountain-grad)" strokeWidth="3" />
        </svg>
      </div>

      {/* Horizon line */}
      <div className="absolute top-[50%] w-full h-[3px] bg-[#00ffff] shadow-[0_0_15px_#00ffff,0_0_30px_#ff00ff] opacity-80" />

      {/* Grid */}
      <div 
        className="absolute bottom-0 w-full h-1/2"
        style={{ perspective: '400px' }}
      >
        <motion.div 
          className="absolute inset-0 w-[200%] h-[200%] -left-1/2"
          style={{
            backgroundImage: `
              linear-gradient(to right, rgba(0, 255, 255, ${0.2 + (Math.min(combo, 20) * 0.02)}) 2px, transparent 2px),
              linear-gradient(to bottom, rgba(255, 0, 255, ${0.3 + (Math.min(combo, 20) * 0.02)}) 2px, transparent 2px)
            `,
            backgroundSize: '50px 50px',
            transform: 'rotateX(60deg) translateY(-25%)',
            transformOrigin: 'top center',
          }}
          animate={{
            backgroundPositionY: ['0px', '50px'],
          }}
          transition={{ 
            duration: Math.max(0.3, 1.5 - (Math.min(combo, 20) * 0.05)), 
            repeat: Infinity, 
            ease: "linear" 
          }}
        />
      </div>

      {/* VHS Glitch Effect on Combo */}
      {combo > 10 && (
        <motion.div 
          className="absolute inset-0 bg-cyan-500/10 mix-blend-screen z-50 pointer-events-none"
          animate={{
            x: [-2, 2, -1, 3, 0],
            opacity: [0, 0.2, 0.1, 0.3, 0]
          }}
          transition={{ duration: 0.2, repeat: Infinity }}
        />
      )}
    </div>
  );
};

const CyberpunkBackground = ({ combo, activeUnlockables }: { combo: number, activeUnlockables: Record<string, boolean> }) => {
  const dataStreams = React.useMemo(() => [...Array(10)].map(() => ({
    left: `${Math.random() * 100}%`,
    top: `${-20 - Math.random() * 50}%`,
    fontSize: `${8 + Math.random() * 12}px`,
    duration: 3 + Math.random() * 5,
    delay: Math.random() * 10,
    text: Array.from({length: 10 + Math.floor(Math.random() * 15)}, () => Math.random() > 0.5 ? '1' : '0').join('\n')
  })), []);

  const floatingCubes = React.useMemo(() => [...Array(15)].map(() => ({
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    size: 10 + Math.random() * 30,
    duration: 10 + Math.random() * 20,
    delay: Math.random() * 10,
    rotateX: Math.random() * 360,
    rotateY: Math.random() * 360,
  })), []);

  const hudElements = React.useMemo(() => [...Array(4)].map(() => ({
    left: Math.random() * 100,
    top: Math.random() * 100,
    size: 40 + Math.random() * 60,
    duration: 15 + Math.random() * 15,
    delay: Math.random() * 5,
  })), []);

  const localizedGlitches = React.useMemo(() => [...Array(6)].map(() => ({
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    size: 20 + Math.random() * 40,
    delay: Math.random() * 5,
  })), []);

  if (!activeUnlockables.cyberpunk) return null;

  return (
    <motion.div 
      className="absolute inset-0 overflow-hidden pointer-events-none z-0 bg-[#020205]"
      animate={{
        backgroundColor: combo > 10 ? ['#020205', '#100010', '#001010', '#020205'] : ['#020205', '#050010', '#000810', '#020205']
      }}
      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
    >
      {/* Deep Space Stars */}
      <div className="absolute inset-0 opacity-30 bg-[radial-gradient(white_1px,transparent_1px)] [background-size:50px_50px]" />
      
      {/* Atmospheric Fog */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#00f2ff]/5 to-[#ff007f]/10" />

      {/* Sweeping Neon Beams */}
      {[...Array(3)].map((_, i) => (
        <motion.div
          key={`beam-${i}`}
          className="absolute top-0 bottom-0 w-[1px] bg-gradient-to-b from-transparent via-[#00f2ff]/40 to-transparent"
          animate={{
            left: ['-10%', '110%'],
            opacity: [0, 1, 0]
          }}
          transition={{
            duration: 8 + i * 4,
            repeat: Infinity,
            ease: "linear",
            delay: i * 5
          }}
          style={{ boxShadow: '0 0 20px #00f2ff' }}
        />
      ))}

      {/* 3D Perspective Grid Floor */}
      <div className="absolute bottom-0 w-full h-1/2 perspective-[1000px]">
        <motion.div 
          className="absolute inset-0 w-[300%] h-[300%] -left-[100%] -top-[50%]"
          style={{
            backgroundImage: `
              linear-gradient(to right, rgba(0, 242, 255, 0.2) 1px, transparent 1px),
              linear-gradient(to bottom, rgba(0, 242, 255, 0.2) 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px',
            transform: 'rotateX(60deg)',
            transformOrigin: 'center center',
            boxShadow: '0 0 50px rgba(0, 242, 255, 0.1) inset',
          }}
          animate={{
            backgroundPositionY: ['0px', '60px'],
          }}
          transition={{ 
            duration: combo > 15 ? 0.5 : 2, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        />
        {/* Grid Horizon Glow */}
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-[#020205] via-[#00f2ff]/20 to-transparent z-10" />
      </div>

      {/* 3D Perspective Grid Ceiling */}
      <div className="absolute top-0 w-full h-1/3 perspective-[1000px] opacity-20">
        <motion.div 
          className="absolute inset-0 w-[300%] h-[300%] -left-[100%] -bottom-[50%]"
          style={{
            backgroundImage: `
              linear-gradient(to right, rgba(255, 0, 127, 0.2) 1px, transparent 1px),
              linear-gradient(to bottom, rgba(255, 0, 127, 0.2) 1px, transparent 1px)
            `,
            backgroundSize: '80px 80px',
            transform: 'rotateX(-60deg)',
            transformOrigin: 'center center',
          }}
          animate={{
            backgroundPositionY: ['0px', '-80px'],
          }}
          transition={{ 
            duration: 4, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        />
      </div>

      {/* Wireframe Horizon Mountains */}
      <div className="absolute bottom-1/2 left-0 w-full h-32 flex items-end opacity-20">
        {[...Array(10)].map((_, i) => (
          <div 
            key={i}
            className="flex-1 border-l border-r border-t border-[#00f2ff]/40"
            style={{
              height: `${20 + Math.sin(i * 1.5) * 40 + Math.random() * 20}%`,
              clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
              background: 'linear-gradient(to top, rgba(0, 242, 255, 0.1), transparent)',
            }}
          />
        ))}
      </div>

      {/* HUD Brackets */}
      <div className="absolute inset-4 border border-[#00f2ff]/10 pointer-events-none">
        {/* Top Left */}
        <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-[#00f2ff]/60" />
        {/* Top Right */}
        <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-[#00f2ff]/60" />
        {/* Bottom Left */}
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-[#00f2ff]/60" />
        {/* Bottom Right */}
        <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-[#00f2ff]/60" />
      </div>

      {/* Rotating HUD Circles */}
      {hudElements.map((hud, i) => (
        <motion.div
          key={`hud-${i}`}
          className="absolute border border-[#00f2ff]/10 rounded-full flex items-center justify-center"
          style={{
            left: `${hud.left}%`,
            top: `${hud.top}%`,
            width: hud.size,
            height: hud.size,
          }}
          animate={{
            rotate: [0, 360],
            opacity: [0.05, 0.15, 0.05],
          }}
          transition={{
            duration: hud.duration,
            repeat: Infinity,
            ease: "linear",
            delay: hud.delay,
          }}
        >
          <div className="w-[80%] h-[80%] border border-dashed border-[#ff007f]/20 rounded-full" />
        </motion.div>
      ))}

      {/* Localized Glitch Squares */}
      {localizedGlitches.map((glitch, i) => (
        <motion.div
          key={`l-glitch-${i}`}
          className="absolute bg-[#00f2ff]/10"
          style={{
            left: glitch.left,
            top: glitch.top,
            width: glitch.size,
            height: glitch.size,
          }}
          animate={{
            opacity: [0, 0.2, 0, 0.1, 0, 0.3, 0],
            scaleX: [1, 1.5, 1, 0.8, 1],
          }}
          transition={{
            duration: 0.5,
            repeat: Infinity,
            repeatDelay: 2 + glitch.delay,
          }}
        />
      ))}

      {/* Floating Digital Assets (Cubes) */}
      {floatingCubes.map((cube, i) => (
        <motion.div
          key={`cube-${i}`}
          className="absolute border border-[#00f2ff]/30 bg-[#00f2ff]/5"
          style={{
            left: cube.left,
            top: cube.top,
            width: cube.size,
            height: cube.size,
            boxShadow: '0 0 15px rgba(0, 242, 255, 0.1)',
          }}
          animate={{
            y: [-20, 20, -20],
            rotateX: [cube.rotateX, cube.rotateX + 360],
            rotateY: [cube.rotateY, cube.rotateY + 360],
            opacity: [0.1, 0.4, 0.1],
          }}
          transition={{
            duration: cube.duration,
            repeat: Infinity,
            ease: "easeInOut",
            delay: cube.delay,
          }}
        />
      ))}

      {/* Matrix-style Data Streams */}
      {dataStreams.map((stream, i) => (
        <motion.div
          key={`stream-${i}`}
          className="absolute text-[#39FF14] font-mono whitespace-pre text-center opacity-20"
          style={{
            left: stream.left,
            top: stream.top,
            fontSize: stream.fontSize,
            textShadow: '0 0 8px #39FF14',
            lineHeight: 1,
          }}
          animate={{
            y: ['-20vh', '120vh'],
            opacity: [0, 0.6, 0],
          }}
          transition={{
            duration: stream.duration,
            repeat: Infinity,
            delay: stream.delay,
            ease: "linear"
          }}
        >
          {stream.text}
        </motion.div>
      ))}

      {/* Scanline Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-10 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]" />
      
      {/* Digital Flicker */}
      <motion.div 
        className="absolute inset-0 bg-[#00f2ff]/2 mix-blend-overlay"
        animate={{ opacity: [0, 0.05, 0, 0.08, 0] }}
        transition={{ duration: 0.2, repeat: Infinity, repeatDelay: 3 }}
      />

      {/* Combo Glitch Effect */}
      {combo > 5 && (
        <motion.div 
          className="absolute inset-0 bg-[#ff007f]/5 mix-blend-screen z-50 pointer-events-none"
          animate={{
            x: [-2, 2, -1, 3, 0],
            y: [1, -1, 1, -1, 0],
            opacity: [0, 0.1, 0.05, 0.15, 0]
          }}
          transition={{ duration: 0.1, repeat: Infinity }}
        />
      )}
    </motion.div>
  );
};



const MinimalistBackground = ({ activeUnlockables }: { activeUnlockables: Record<string, boolean> }) => {
  if (!activeUnlockables.minimalist) return null;
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0 bg-white">
      <div className="absolute inset-0 opacity-5 bg-[radial-gradient(#000_1px,transparent_1px)] [background-size:20px_20px]" />
      <motion.div 
        className="absolute top-1/4 left-1/4 w-64 h-64 border border-gray-100 rounded-full"
        animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 10, repeat: Infinity }}
      />
      <motion.div 
        className="absolute bottom-1/4 right-1/4 w-96 h-96 border border-gray-100 rounded-full"
        animate={{ scale: [1.2, 1, 1.2], opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 15, repeat: Infinity }}
      />
    </div>
  );
};

const OceanicBackground = ({ activeUnlockables }: { activeUnlockables: Record<string, boolean> }) => {
  const bubbles = React.useMemo(() => [...Array(30)].map((_, i) => ({
    size: 3 + Math.random() * 25,
    left: `${Math.random() * 100}%`,
    xOffset: Math.sin(i) * 60,
    duration: 10 + Math.random() * 20,
    delay: Math.random() * 15,
  })), []);

  const plankton = React.useMemo(() => [...Array(60)].map(() => ({
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    tx: Math.random() * 150 - 75,
    ty: Math.random() * 150 - 75,
    duration: 15 + Math.random() * 15,
  })), []);

  const fish = React.useMemo(() => [...Array(10)].map((_, i) => ({
    top: `${10 + Math.random() * 80}%`,
    size: 20 + Math.random() * 30,
    duration: 20 + Math.random() * 30,
    delay: Math.random() * 20,
    color: ['#4cc9f0', '#4895ef', '#4361ee', '#3f37c9', '#3a0ca3'][Math.floor(Math.random() * 5)],
    direction: Math.random() > 0.5 ? 1 : -1,
    yOffset: Math.random() * 50,
  })), []);

  if (!activeUnlockables.oceanic) return null;
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
      {/* Deep Ocean Gradient with Wave Animation */}
      <motion.div 
        className="absolute inset-0 bg-gradient-to-b from-[#001d3d] via-[#003566] to-[#000814]"
        animate={{
          background: [
            'linear-gradient(to bottom, #001d3d, #003566, #000814)',
            'linear-gradient(to bottom, #002855, #003566, #001d3d)',
            'linear-gradient(to bottom, #001d3d, #003566, #000814)',
          ]
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* God Rays */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={`ray-${i}`}
          className="absolute top-0 h-[150vh] w-48 bg-gradient-to-b from-cyan-400/15 to-transparent blur-[60px]"
          style={{
            left: `${-10 + i * 15}%`,
            transform: 'rotate(-15deg)',
            transformOrigin: 'top center',
          }}
          animate={{
            opacity: [0.1, 0.4, 0.1],
            x: [-30, 30, -30],
            skewX: [-5, 5, -5],
          }}
          transition={{
            duration: 10 + i * 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}

      {/* Caustics / Light Patterns */}
      {[...Array(3)].map((_, i) => (
        <motion.div
          key={`caustic-${i}`}
          className="absolute inset-0 opacity-20"
          style={{
            background: 'radial-gradient(circle at 50% 50%, rgba(0, 255, 255, 0.1) 0%, transparent 70%)',
            backgroundSize: '200% 200%',
          }}
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%', '0% 0%'],
            scale: [1, 1.2, 1],
            rotate: [0, 10, 0],
          }}
          transition={{
            duration: 15 + i * 5,
            repeat: Infinity,
            ease: "linear",
          }}
        />
      ))}

      {/* Water Texture Overlay */}
      <div className="absolute inset-0 opacity-25 bg-[url('https://www.transparenttextures.com/patterns/water.png')] mix-blend-overlay" />
      
      {/* Fish */}
      {fish.map((f, i) => (
        <motion.div
          key={`fish-${i}`}
          className="absolute flex items-center justify-center opacity-40"
          style={{
            top: f.top,
            width: f.size,
            height: f.size / 2,
            color: f.color,
            zIndex: 1,
          }}
          initial={{ x: f.direction === 1 ? '-20vw' : '120vw', scaleX: f.direction }}
          animate={{ 
            x: f.direction === 1 ? '120vw' : '-20vw',
            y: [f.yOffset, f.yOffset - 20, f.yOffset + 20, f.yOffset]
          }}
          transition={{
            x: { duration: f.duration, repeat: Infinity, delay: f.delay, ease: "linear" },
            y: { duration: 5 + Math.random() * 5, repeat: Infinity, ease: "easeInOut" }
          }}
        >
          <svg viewBox="0 0 100 50" fill="currentColor" className="drop-shadow-[0_0_8px_rgba(0,255,255,0.3)]">
            <path d="M0 25 C 20 0, 60 0, 80 25 C 60 50, 20 50, 0 25 M 80 25 L 100 5 L 100 45 Z" />
            <circle cx="25" cy="20" r="4" fill="white" opacity="0.6" />
          </svg>
        </motion.div>
      ))}

      {/* Bubbles */}
      {bubbles.map((b, i) => (
        <motion.div
          key={`bubble-${i}`}
          className="absolute rounded-full border border-white/40 bg-white/5 backdrop-blur-[0.5px]"
          style={{
            width: b.size,
            height: b.size,
            left: b.left,
            bottom: '-10%',
          }}
          animate={{
            y: ['0vh', '-120vh'],
            x: [0, b.xOffset, 0],
            opacity: [0, 0.7, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: b.duration,
            repeat: Infinity,
            delay: b.delay,
            ease: "linear",
          }}
        />
      ))}

      {/* Plankton / Marine Snow */}
      {plankton.map((p, i) => (
        <motion.div
          key={`plankton-${i}`}
          className="absolute w-1 h-1 bg-cyan-100/30 rounded-full blur-[0.5px]"
          style={{
            left: p.left,
            top: p.top,
          }}
          animate={{
            x: [0, p.tx],
            y: [0, p.ty],
            opacity: [0.05, 0.6, 0.05],
            scale: [0.5, 1.5, 0.5],
          }}
          transition={{
            duration: p.duration,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
};

const VolcanoBackground = ({ activeUnlockables }: { activeUnlockables: Record<string, boolean> }) => {
  const bursts = React.useMemo(() => [...Array(15)].map(() => ({
    width: `${2 + Math.random() * 6}px`,
    height: `${2 + Math.random() * 6}px`,
    left: `${Math.random() * 100}%`,
    y: -50 - Math.random() * 100,
    x: (Math.random() - 0.5) * 50,
    duration: 1 + Math.random() * 2,
    delay: Math.random() * 10,
  })), []);

  const embers = React.useMemo(() => [...Array(40)].map(() => ({
    left: `${Math.random() * 100}%`,
    x: (Math.random() - 0.5) * 150,
    duration: 3 + Math.random() * 4,
    delay: Math.random() * 8,
  })), []);

  const lightning = React.useMemo(() => [...Array(3)].map(() => ({
    repeatDelay: 8 + Math.random() * 20,
    delay: Math.random() * 10,
  })), []);

  const magma = React.useMemo(() => [...Array(5)].map(() => ({
    width: `${150 + Math.random() * 200}px`,
    height: `${150 + Math.random() * 200}px`,
    left: `${Math.random() * 100}%`,
    bottom: `${Math.random() * 40}%`,
    duration: 5 + Math.random() * 5,
  })), []);

  if (!activeUnlockables.volcano) return null;
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0 bg-[#1a0500]">
      {/* Lava Flow at bottom */}
      <motion.div 
        className="absolute bottom-0 w-full h-1/3 bg-gradient-to-t from-orange-600/60 via-orange-900/40 to-transparent"
        animate={{
          opacity: [0.4, 0.7, 0.4],
        }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Lava Bursts / Splashes */}
      {bursts.map((b, i) => (
        <motion.div
          key={`burst-${i}`}
          className="absolute rounded-full bg-orange-500 blur-[2px]"
          style={{
            width: b.width,
            height: b.height,
            left: b.left,
            bottom: '0%',
          }}
          animate={{
            y: [0, b.y],
            x: b.x,
            opacity: [0, 1, 0],
            scale: [1, 2, 0.5],
          }}
          transition={{
            duration: b.duration,
            repeat: Infinity,
            delay: b.delay,
            ease: "easeOut"
          }}
        />
      ))}
      
      {/* Heat Distortion / Lava Texture */}
      <div className="absolute inset-0 opacity-30 animate-lava bg-[url('https://www.transparenttextures.com/patterns/lava.png')] [background-size:400px_400px] mix-blend-screen" />
      
      {/* Rising Embers */}
      {embers.map((e, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-orange-400 rounded-full blur-[0.5px]"
          style={{
            left: e.left,
            bottom: '-5%',
          }}
          animate={{
            y: [0, -1000],
            x: [0, e.x],
            opacity: [0, 1, 0.8, 0],
            scale: [1, 1.5, 0.5],
            rotate: [0, 360],
          }}
          transition={{
            duration: e.duration,
            repeat: Infinity,
            delay: e.delay,
            ease: "easeOut"
          }}
        />
      ))}

      {/* Volcanic Lightning */}
      {lightning.map((l, i) => (
        <motion.div
          key={`lightning-${i}`}
          className="absolute inset-0 bg-blue-100/5 blur-3xl pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{
            opacity: [0, 0.3, 0, 0.1, 0],
          }}
          transition={{
            duration: 0.2,
            repeat: Infinity,
            repeatDelay: l.repeatDelay,
            delay: l.delay,
          }}
        />
      ))}

      {/* Large Glowing Orbs (Magma) */}
      {magma.map((m, i) => (
        <motion.div
          key={`magma-${i}`}
          className="absolute rounded-full blur-[60px]"
          style={{
            width: m.width,
            height: m.height,
            left: m.left,
            bottom: m.bottom,
            background: 'radial-gradient(circle, rgba(255,69,0,0.3) 0%, transparent 70%)',
          }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.2, 0.4, 0.2],
            y: [0, -30, 0],
          }}
          transition={{
            duration: m.duration,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
      
      <div className="absolute inset-0 bg-orange-500/10 mix-blend-overlay" />
    </div>
  );
};

const SupernovaBackground = ({ combo, activeUnlockables }: { combo: number, activeUnlockables: Record<string, boolean> }) => {
  if (!activeUnlockables.bg_supernova) return null;
  
  const intensity = Math.min(combo / 15, 1);
  if (intensity === 0) return null;

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0 mix-blend-screen flex items-center justify-center">
      <motion.div
        className="absolute rounded-full"
        style={{ 
          width: '100vw', 
          height: '100vw',
          background: `radial-gradient(circle, rgba(255,100,0,0.4) 0%, transparent 70%)` 
        }}
        animate={{ 
          scale: [1 + intensity, 1.5 + intensity * 2, 1 + intensity], 
          opacity: [0.2, 0.5 * intensity, 0.2] 
        }}
        transition={{ duration: 2 - intensity, repeat: Infinity, ease: "easeInOut" }}
      />
      {[...Array(10)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 rounded-full bg-white"
          initial={{ x: 0, y: 0, opacity: 0 }}
          animate={{
            x: (Math.random() - 0.5) * 1000 * intensity,
            y: (Math.random() - 0.5) * 1000 * intensity,
            opacity: [0, intensity, 0],
            scale: [0, 2, 0]
          }}
          transition={{
            duration: 1 + Math.random(),
            repeat: Infinity,
            delay: Math.random() * 2
          }}
        />
      ))}
    </div>
  );
};

const NebulaBackground = ({ activeUnlockables }: { activeUnlockables: Record<string, boolean> }) => {
  const stars1 = React.useMemo(() => [...Array(80)].map(() => ({
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    duration: 3 + Math.random() * 5,
    delay: Math.random() * 10,
  })), []);

  const stars2 = React.useMemo(() => {
    const colors = ['bg-white', 'bg-blue-200', 'bg-pink-200', 'bg-yellow-100'];
    return [...Array(40)].map(() => ({
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      color: colors[Math.floor(Math.random() * colors.length)],
      duration: 2 + Math.random() * 3,
      delay: Math.random() * 5,
    }));
  }, []);

  const stars3 = React.useMemo(() => [...Array(12)].map(() => ({
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    duration: 4 + Math.random() * 4,
    delay: Math.random() * 8,
  })), []);

  if (!activeUnlockables.nebula) return null;
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0 bg-[#020008]">
      {/* Deep Space Base */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#0a001a_0%,#020008_100%)]" />
      
      {/* Swirling Nebula Clouds - Layer 1 (Deep Purple) */}
      <motion.div 
        className="absolute -top-1/4 -left-1/4 w-[150%] h-[150%] opacity-30"
        style={{
          background: 'radial-gradient(circle at center, rgba(75, 0, 130, 0.4) 0%, rgba(0, 0, 255, 0.2) 30%, transparent 70%)',
          filter: 'blur(120px)',
        }}
        animate={{
          rotate: [0, 360],
          scale: [1, 1.2, 1],
        }}
        transition={{ duration: 120, repeat: Infinity, ease: "linear" }}
      />
      
      {/* Swirling Nebula Clouds - Layer 2 (Magenta/Pink) */}
      <motion.div 
        className="absolute -bottom-1/4 -right-1/4 w-[150%] h-[150%] opacity-20"
        style={{
          background: 'radial-gradient(circle at center, rgba(148, 0, 211, 0.4) 0%, rgba(255, 0, 255, 0.2) 30%, transparent 70%)',
          filter: 'blur(150px)',
        }}
        animate={{
          rotate: [360, 0],
          scale: [1.2, 1, 1.2],
        }}
        transition={{ duration: 90, repeat: Infinity, ease: "linear" }}
      />

      {/* Swirling Nebula Clouds - Layer 3 (Cyan/Teal) */}
      <motion.div 
        className="absolute top-1/4 left-1/4 w-[100%] h-[100%] opacity-15"
        style={{
          background: 'radial-gradient(circle at center, rgba(0, 255, 255, 0.3) 0%, rgba(0, 128, 128, 0.1) 40%, transparent 70%)',
          filter: 'blur(100px)',
        }}
        animate={{
          x: [-100, 100, -100],
          y: [-50, 50, -50],
          scale: [1, 1.3, 1],
        }}
        transition={{ duration: 40, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Stars - Layer 1 (Small, Distant) */}
      {stars1.map((star, i) => (
        <motion.div
          key={`star-s-${i}`}
          className="absolute w-[1px] h-[1px] bg-white rounded-full"
          style={{
            left: star.left,
            top: star.top,
          }}
          animate={{
            opacity: [0.1, 0.6, 0.1],
          }}
          transition={{
            duration: star.duration,
            repeat: Infinity,
            delay: star.delay,
          }}
        />
      ))}

      {/* Stars - Layer 2 (Medium, Brighter) */}
      {stars2.map((star, i) => (
        <motion.div
          key={`star-m-${i}`}
          className={`absolute w-[2px] h-[2px] ${star.color} rounded-full shadow-[0_0_6px_rgba(255,255,255,0.9)]`}
          style={{
            left: star.left,
            top: star.top,
          }}
          animate={{
            opacity: [0.3, 1, 0.3],
            scale: [1, 1.5, 1],
            boxShadow: [
              '0 0 4px rgba(255,255,255,0.5)',
              '0 0 10px rgba(255,255,255,1)',
              '0 0 4px rgba(255,255,255,0.5)'
            ]
          }}
          transition={{
            duration: star.duration,
            repeat: Infinity,
            delay: star.delay,
          }}
        />
      ))}

      {/* Stars - Layer 3 (Large, Pulsing with Glint) */}
      {stars3.map((star, i) => (
        <motion.div
          key={`star-l-${i}`}
          className="absolute w-[3px] h-[3px] bg-white rounded-full"
          style={{
            left: star.left,
            top: star.top,
          }}
          animate={{
            opacity: [0.4, 1, 0.4],
            scale: [1, 1.8, 1],
          }}
          transition={{
            duration: star.duration,
            repeat: Infinity,
            delay: star.delay,
          }}
        >
          {/* Star Glint / Shine Effect */}
          <motion.div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[15px] h-[1px] bg-white/40 blur-[1px]"
            animate={{ rotate: [0, 180], opacity: [0.2, 0.8, 0.2] }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          />
          <motion.div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1px] h-[15px] bg-white/40 blur-[1px]"
            animate={{ rotate: [0, 180], opacity: [0.2, 0.8, 0.2] }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-white rounded-full shadow-[0_0_12px_rgba(255,255,255,1)]" />
        </motion.div>
      ))}

      {/* Shooting Stars */}
      {[...Array(3)].map((_, i) => (
        <motion.div
          key={`shooting-${i}`}
          className="absolute h-[1px] bg-gradient-to-r from-transparent via-white to-transparent"
          style={{
            width: '100px',
            left: '-10%',
            top: `${20 + Math.random() * 60}%`,
            rotate: '-20deg',
          }}
          animate={{
            x: ['0vw', '120vw'],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 0.8 + Math.random() * 1.2,
            repeat: Infinity,
            delay: 5 + Math.random() * 20,
            ease: "easeIn",
          }}
        />
      ))}

      {/* Cosmic Dust */}
      {[...Array(30)].map((_, i) => (
        <motion.div
          key={`dust-${i}`}
          className="absolute w-1 h-1 bg-purple-300/20 rounded-full blur-[1px]"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            x: [0, Math.random() * 100 - 50],
            y: [0, Math.random() * 100 - 50],
            opacity: [0.05, 0.3, 0.05],
          }}
          transition={{
            duration: 15 + Math.random() * 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
};

const TutorialVisualizer = ({ step, lightTheme }: { step: number, lightTheme: boolean }) => {
  const borderColor = lightTheme ? 'border-slate-300' : 'border-white/20';
  const bgColor = lightTheme ? 'bg-slate-100' : 'bg-black/30';

  switch (step) {
    case 0: // Welcome
      return (
        <div className={`h-28 w-full flex items-center justify-center relative overflow-hidden rounded-xl mb-4 ${bgColor}`}>
           <motion.div animate={{ rotate: 360 }} transition={{ duration: 10, repeat: Infinity, ease: "linear" }} className="w-16 h-16 rounded-full border-4 border-t-transparent" style={{ borderColor: '#00f2ff', borderTopColor: 'transparent' }} />
           <motion.div animate={{ rotate: -360 }} transition={{ duration: 8, repeat: Infinity, ease: "linear" }} className="absolute w-10 h-10 rounded-full border-4 border-b-transparent" style={{ borderColor: '#ff007f', borderBottomColor: 'transparent' }} />
        </div>
      );
    case 1: // Queue
      return (
        <div className={`h-28 w-full flex flex-col items-center justify-center relative gap-3 overflow-hidden rounded-xl mb-4 ${bgColor}`}>
           <div className={`w-10 h-10 border-2 ${borderColor} rounded-lg flex items-center justify-center relative`}>
              <motion.div 
                animate={{ y: [35, 0, 0, 35], opacity: [0, 1, 1, 0], scale: [0.5, 1, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute w-6 h-6 rounded-full border-4"
                style={{ borderColor: '#00f2ff' }}
              />
           </div>
           <div className="flex gap-2">
              <div className={`w-8 h-8 border-2 ${borderColor} rounded-lg flex items-center justify-center`}>
                 <motion.div 
                   animate={{ opacity: [1, 0, 0, 1] }}
                   transition={{ duration: 2, repeat: Infinity }}
                   className="w-4 h-4 rounded-full border-[3px]"
                   style={{ borderColor: '#00f2ff' }}
                 />
              </div>
              <div className={`w-8 h-8 border-2 ${borderColor} rounded-lg flex items-center justify-center`}>
                 <div className="w-4 h-4 rounded-full border-[3px]" style={{ borderColor: '#ff007f' }} />
              </div>
           </div>
        </div>
      );
    case 2: // Grid Stacking
      return (
        <div className={`h-28 w-full flex items-center justify-center relative overflow-hidden rounded-xl mb-4 ${bgColor}`}>
          <div className={`w-16 h-16 border-2 ${borderColor} rounded-xl flex items-center justify-center relative`}>
            <motion.div 
              animate={{ opacity: [0, 1, 1, 1, 0], scale: [1.5, 1, 1, 1, 1.5] }}
              transition={{ duration: 3, repeat: Infinity, times: [0, 0.2, 0.8, 0.9, 1] }}
              className="absolute w-12 h-12 rounded-full border-4"
              style={{ borderColor: '#00f2ff' }}
            />
            <motion.div 
              animate={{ opacity: [0, 0, 1, 1, 0], scale: [1.5, 1.5, 1, 1, 1.5] }}
              transition={{ duration: 3, repeat: Infinity, times: [0, 0.3, 0.5, 0.9, 1] }}
              className="absolute w-8 h-8 rounded-full border-4"
              style={{ borderColor: '#ff007f' }}
            />
            <motion.div 
              animate={{ opacity: [0, 0, 0, 1, 0], scale: [1.5, 1.5, 1.5, 1, 1.5] }}
              transition={{ duration: 3, repeat: Infinity, times: [0, 0.6, 0.8, 0.9, 1] }}
              className="absolute w-4 h-4 rounded-full border-4"
              style={{ borderColor: '#39FF14' }}
            />
          </div>
        </div>
      );
    case 3: // Sync Colors
      return (
        <div className={`h-28 w-full flex items-center justify-center relative gap-2 overflow-hidden rounded-xl mb-4 ${bgColor}`}>
          {[0, 1, 2].map((i) => (
            <div key={i} className={`w-10 h-10 border-2 ${borderColor} rounded-lg flex items-center justify-center relative`}>
              <motion.div 
                animate={{ 
                  scale: [0, 1, 1, 1.2, 0],
                  opacity: [0, 1, 1, 0, 0]
                }}
                transition={{ duration: 2.5, repeat: Infinity, times: [0, 0.2, 0.6, 0.8, 1], delay: i * 0.1 }}
                className="absolute w-6 h-6 rounded-full border-[3px]"
                style={{ borderColor: '#ff007f' }}
              />
            </div>
          ))}
          <motion.div 
            animate={{ width: ['0%', '80%', '80%', '0%'], opacity: [0, 1, 1, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, times: [0, 0.5, 0.8, 1] }}
            className="absolute h-1.5 bg-white rounded-full shadow-[0_0_10px_white] z-10"
          />
        </div>
      );
    case 4: // Combo Power
      return (
        <div className={`h-28 w-full flex flex-col items-center justify-center relative gap-3 overflow-hidden rounded-xl mb-4 ${bgColor}`}>
          <div className="w-40 h-4 bg-black/50 rounded-full border border-white/20 overflow-hidden relative">
            <motion.div 
              animate={{ width: ['0%', '33%', '66%', '100%', '0%'] }}
              transition={{ duration: 4, repeat: Infinity, times: [0, 0.2, 0.4, 0.6, 1] }}
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#ffaa00] to-[#ff0000]"
            />
          </div>
          <motion.div 
            animate={{ scale: [1, 1.1, 1, 1.2, 1], color: ['#fff', '#ffaa00', '#fff', '#ff0000', '#fff'] }}
            transition={{ duration: 4, repeat: Infinity, times: [0, 0.2, 0.4, 0.6, 1] }}
            className="text-xl font-black italic"
          >
            COMBO x3!
          </motion.div>
        </div>
      );
    case 5: // Unlockables
      return (
        <div className={`h-28 w-full flex items-center justify-center relative overflow-hidden rounded-xl mb-4 ${bgColor}`}>
          <motion.div 
            animate={{ scale: [1, 1.1, 1], y: [0, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="flex items-center justify-center gap-4"
          >
            <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 ${borderColor} bg-yellow-400/20 text-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.5)]`}>
              <Trophy size={24} />
            </div>
            <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 ${borderColor} bg-[#00f2ff]/20 text-[#00f2ff] shadow-[0_0_15px_rgba(0,242,255,0.5)]`}>
              <Palette size={24} />
            </div>
            <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 ${borderColor} bg-green-400/20 text-green-400 shadow-[0_0_15px_rgba(74,222,128,0.5)]`}>
              <Shield size={24} />
            </div>
          </motion.div>
        </div>
      );
    case 6: // Good Luck
      return (
        <div className={`h-28 w-full flex items-center justify-center relative overflow-hidden rounded-xl mb-4 ${bgColor}`}>
          <motion.div 
            animate={{ y: [0, -10, 0], rotate: [-5, 5, -5] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="text-5xl"
          >
            🚀
          </motion.div>
        </div>
      );
    default:
      return null;
  }
};

const TutorialOverlay = ({ step, onNext, onSkip, activeUnlockables }: any) => {
  const steps = [
    {
      title: "Welcome, Pilot!",
      description: "Hue Rings is a game of color and space. Let's get you briefed on the mission.",
      target: "none",
      position: "center"
    },
    {
      title: "The Queue",
      description: "These are your incoming rings. Drag one to the grid to start.",
      target: "queue",
      position: "top"
    },
    {
      title: "The Grid",
      description: "Place rings here. You can stack Small, Medium, and Large rings in the same cell!",
      target: "grid",
      position: "bottom"
    },
    {
      title: "Sync Colors",
      description: "Match 3 rings of the same color in a row, column, or diagonal to clear them.",
      target: "grid",
      position: "bottom"
    },
    {
      title: "Combo Power",
      description: "Clearing rings starts a combo. You have 3 moves to keep the chain alive for massive points!",
      target: "heatmeter",
      position: "bottom"
    },
    {
      title: "Unlockables",
      description: "Keep playing to earn achievements and unlock new themes, ring styles, and backgrounds!",
      target: "none",
      position: "center"
    },
    {
      title: "Good Luck!",
      description: "You're ready. Clear the grid and reach for the high score!",
      target: "none",
      position: "center"
    }
  ];

  const currentStep = steps[step];
  if (!currentStep) return null;

  const alignmentClass = 
    currentStep.position === 'top' ? 'justify-start pt-24' : 
    currentStep.position === 'bottom' ? 'justify-end pb-12' : 
    'justify-center';

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className={`absolute inset-0 z-[100] flex flex-col items-center p-6 pt-safe pb-safe bg-black/40 pointer-events-auto ${alignmentClass}`}
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className={`w-full max-w-[280px] p-5 rounded-[24px] border-2 ${activeUnlockables.light_theme ? 'bg-white border-slate-200 text-slate-900' : 'bg-[#0F172A] border-white/10 text-white'} shadow-2xl relative z-10`}
      >
        <div className="absolute -top-8 left-1/2 -translate-x-1/2 w-16 h-16 rounded-full bg-gradient-to-br from-[#00f2ff] to-[#ff007f] p-1 shadow-[0_0_20px_rgba(0,242,255,0.5)]">
          <div className={`w-full h-full rounded-full flex items-center justify-center ${activeUnlockables.light_theme ? 'bg-white' : 'bg-[#0F172A]'}`}>
            <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-br from-[#00f2ff] to-[#ff007f]">{step + 1}</span>
          </div>
        </div>

        <h3 className="text-xl font-black tracking-tight mb-4 mt-6 text-center uppercase italic">{currentStep.title}</h3>
        
        <TutorialVisualizer step={step} lightTheme={activeUnlockables.light_theme} />

        <p className={`text-center text-xs font-medium leading-relaxed mb-5 ${activeUnlockables.light_theme ? 'text-slate-600' : 'text-white/70'}`}>
          {currentStep.description}
        </p>

        <div className="flex flex-col gap-2">
          <button 
            onClick={onNext}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#00f2ff] to-[#ff007f] text-white font-black uppercase tracking-widest text-xs shadow-lg shadow-[#00f2ff]/20 active:scale-95 transition-transform"
          >
            {step === steps.length - 1 ? "Start Mission" : "Next Step"}
          </button>
          <button 
            onClick={onSkip}
            className={`w-full py-2 text-[10px] font-bold uppercase tracking-[0.2em] opacity-50 hover:opacity-100 transition-opacity ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}
          >
            Skip Tutorial
          </button>
        </div>
      </motion.div>

      {/* Target Highlights */}
      {currentStep.target === 'queue' && (
        <>
          {/* Left Arrow */}
          <motion.div 
            initial={{ opacity: 0, x: -15, y: -15 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
            className="absolute bottom-[110px] left-[calc(50%-80px)] -translate-x-1/2 z-[60] text-[#00f2ff] drop-shadow-[0_0_15px_rgba(0,242,255,0.8)] pointer-events-none -rotate-12"
          >
            <ArrowDown size={48} />
          </motion.div>
          
          {/* Right Arrow */}
          <motion.div 
            initial={{ opacity: 0, x: 15, y: -15 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
            className="absolute bottom-[110px] left-[calc(50%+80px)] -translate-x-1/2 z-[60] text-[#00f2ff] drop-shadow-[0_0_15px_rgba(0,242,255,0.8)] pointer-events-none rotate-12"
          >
            <ArrowDown size={48} />
          </motion.div>
        </>
      )}
      {currentStep.target === 'grid' && (
        <>
          {step === 3 && ( // Sync Colors (Matching)
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ 
                opacity: [0, 1, 1, 0],
                width: ['0%', '100%', '100%', '0%']
              }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="absolute top-1/2 left-0 h-4 bg-[#ff007f] rounded-full z-[60] shadow-[0_0_20px_rgba(255,0,127,0.8)] pointer-events-none -translate-y-1/2"
            />
          )}
        </>
      )}
      {currentStep.target === 'heatmeter' && (
        <>
        </>
      )}
    </motion.div>
  );
};

const GameView = ({ onGameOver, onHome, sfx, haptics, unlockedAchievements, setUnlockedAchievements, activeUnlockables, toggleUnlockable, clearUnlockables, screenShake = true, highScores, activeMode, music, setMusic, showInterstitial, adMobReady }: any) => {
  const initialGrid = Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill({ small: null, medium: null, large: null }));
  const [grid, setGrid] = useState<Cell[][]>(initialGrid);
  const [queue, setQueue] = useState<(QueuePiece | null)[]>(() => generateHelpfulQueue(initialGrid));
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(highScores[activeMode] || 0);
  const [stats, setStats] = useState<GameStats>(() => {
    const saved = localStorage.getItem('hueRingsStats');
    return saved ? JSON.parse(saved) : defaultStats;
  });
  const [tutorialStep, setTutorialStep] = useState<number | null>(() => {
    const completed = localStorage.getItem('hueRingsTutorialCompleted');
    return completed ? null : 0;
  });

  const completeTutorial = () => {
    setTutorialStep(null);
    localStorage.setItem('hueRingsTutorialCompleted', 'true');
  };

  const nextTutorialStep = () => {
    if (tutorialStep === 5) {
      completeTutorial();
    } else if (tutorialStep !== null) {
      setTutorialStep(tutorialStep + 1);
    }
  };
  const [watchingAdFor, setWatchingAdFor] = useState<'continue' | 'hammer' | 'reroll' | 'freeze' | 'hint' | null>(null);
  const [adState, setAdState] = useState<'idle' | 'loading' | 'watching' | 'completed'>('idle');
  const [showContinueModal, setShowContinueModal] = useState(false);
  const [retriesLeft, setRetriesLeft] = useState(3);
  const [isGameOverHandling, setIsGameOverHandling] = useState(false);
  const [hints, setHints] = useState<{ r: number, c: number, pieceIndex: number }[]>([]);
  const [combo, setCombo] = useState(0);
  const [comboHistory, setComboHistory] = useState<number[]>([]);
  const [comboMovesLeft, setComboMovesLeft] = useState(3);
  const [nextContinueCombo, setNextContinueCombo] = useState(0);
  const [hintsThisRound, setHintsThisRound] = useState(0);
  const [pulseColor, setPulseColor] = useState<Color | null>(null);
  const [lastMatchColor, setLastMatchColor] = useState<Color | null>(null);
  const [shake, setShake] = useState(false);
  const [flash, setFlash] = useState(false);
  const [glitch, setGlitch] = useState(false);
  const [particles, setParticles] = useState<{ id: number, x: number, y: number, tx: number, ty: number, size: number, rotation: number, color: string }[]>([]);
  const [shockwaves, setShockwaves] = useState<{ id: number, x: number, y: number, color: string }[]>([]);

  const triggerSpecialParticles = (type: 'mega_crit' | 'perfect_clear', color: string) => {
    const newParticles: any[] = [];
    const count = type === 'perfect_clear' ? 150 : 80;
    const colors = ['#00f2ff', '#ff007f', '#39FF14', '#f59e0b', '#ffffff', '#ffff00'];
    
    // Add a massive shockwave for special events
    const newShockwaves: any[] = [];
    newShockwaves.push({
      id: Math.random(),
      x: 150,
      y: 150,
      color: type === 'perfect_clear' ? '#ffffff' : color
    });
    setShockwaves(prev => [...prev, ...newShockwaves]);

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const velocity = type === 'perfect_clear' ? 300 + Math.random() * 1200 : 200 + Math.random() * 800;
      const isSparkle = Math.random() > 0.7;
      
      newParticles.push({
        id: Math.random(),
        x: 150, // Center of grid
        y: 150,
        tx: Math.cos(angle) * velocity,
        ty: Math.sin(angle) * velocity,
        size: type === 'perfect_clear' ? 12 + Math.random() * 25 : 10 + Math.random() * 18,
        rotation: Math.random() * 1080,
        color: type === 'perfect_clear' ? colors[Math.floor(Math.random() * colors.length)] : (isSparkle ? '#ffffff' : color),
        isSparkle
      });
    }
    
    setParticles(prev => [...prev, ...newParticles]);
    setTimeout(() => {
      setParticles(prev => prev.filter(p => !newParticles.includes(p)));
      setShockwaves(prev => prev.filter(s => !newShockwaves.includes(s)));
    }, 2000);
  };
  const [showQuickSettings, setShowQuickSettings] = useState(false);
  const [comboTimeLeft, setComboTimeLeft] = useState(10);
  const [powerUps, setPowerUps] = useState<{ hammer: number, reroll: number, freeze: number }>(() => {
    const saved = localStorage.getItem('hueRingsPowerUps');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Migration: if old 'refresh' exists, move it to 'reroll'
      if ('refresh' in parsed) {
        parsed.reroll = parsed.refresh;
        delete parsed.refresh;
      }
      return parsed;
    }
    return { hammer: 3, reroll: 3, freeze: 3 };
  });
  const [activePowerUp, setActivePowerUp] = useState<'hammer' | null>(null);
  const [isFrozen, setIsFrozen] = useState(false);
  const [freezeTimeLeft, setFreezeTimeLeft] = useState(0);

  const showRewardAd = async (type: 'continue' | 'hammer' | 'reroll' | 'freeze' | 'hint') => {
    if (Capacitor.isNativePlatform() && adMobReady) {
      try {
        await AdMob.prepareRewardVideoAd({
          adId: AD_IDS.rewarded,
        });
        const reward = await AdMob.showRewardVideoAd();
        if (reward) {
          setWatchingAdFor(type);
          onAdComplete();
        }
      } catch (e) {
        console.error("Reward Ad Error", e);
        // Fallback to simulation if ad fails
        handleWatchAd(type);
      }
    } else {
      // Fallback for web
      handleWatchAd(type);
    }
  };

  const handleWatchAd = (type: 'continue' | 'hammer' | 'reroll' | 'freeze' | 'hint') => {
    setWatchingAdFor(type);
    triggerHaptic(haptics, 10);
  };

  const onAdComplete = () => {
    if (!watchingAdFor) return;

    if (watchingAdFor === 'hint') {
      grantHint();
    } else if (watchingAdFor === 'continue') {
      if (!activeUnlockables.god_mode && !activeUnlockables.zen_mode) {
        setRetriesLeft(prev => prev - 1);
      }
      updateStats({ retriesUsed: 1 });
      
      // Clear 3 random non-empty cells
      const newGrid = grid.map(row => [...row]);
      const nonEmptyCells: {r: number, c: number}[] = [];
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (newGrid[r][c].small || newGrid[r][c].medium || newGrid[r][c].large) {
            nonEmptyCells.push({r, c});
          }
        }
      }
      
      const cellsToClear = nonEmptyCells.sort(() => 0.5 - Math.random()).slice(0, 3);
      cellsToClear.forEach(({r, c}) => {
        newGrid[r][c] = { small: null, medium: null, large: null };
      });
      
      setGrid(newGrid);
      setIsGameOverHandling(false);
      setCombo(nextContinueCombo);
      setComboMovesLeft(3);
      setComboTimeLeft(10);
      triggerHaptic(haptics, [40, 20, 40]);
    } else {
      const reward = 2;
      setPowerUps(prev => ({
        ...prev,
        [watchingAdFor]: prev[watchingAdFor] + reward
      }));
      triggerHaptic(haptics, [20, 50, 20]);
    }
    
    setWatchingAdFor(null);
  };

  useEffect(() => {
    localStorage.setItem('hueRingsPowerUps', JSON.stringify(powerUps));
  }, [powerUps]);

  useEffect(() => {
    let timer: any;
    if (isFrozen && freezeTimeLeft > 0) {
      timer = setInterval(() => {
        setFreezeTimeLeft(prev => {
          if (prev <= 1) {
            setIsFrozen(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isFrozen, freezeTimeLeft]);

  useEffect(() => {
    let timer: any;
    if (activeUnlockables.combo_rush && combo > 0 && !isFrozen) {
      timer = setInterval(() => {
        setComboTimeLeft(prev => {
          if (prev <= 0) {
            setCombo(0);
            return 10;
          }
          return Math.max(0, prev - 0.1);
        });
      }, 100);
    } else if (!activeUnlockables.combo_rush) {
      setComboTimeLeft(10);
    }
    return () => clearInterval(timer);
  }, [activeUnlockables.combo_rush, combo, isFrozen]);
  
  const handleToggle = (id: string) => {
    const item = UNLOCKABLES.find(u => u.id === id);
    // Only reset game if turning a mode ON, or turning a theme ON
    // Turning them OFF should just return to default without resetting progress if possible
    if ((item?.type === 'mode' || item?.type === 'theme') && !activeUnlockables[id]) {
      const emptyGrid = Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill({ small: null, medium: null, large: null }));
      setScore(0);
      setGrid(emptyGrid);
      setQueue(generateHelpfulQueue(emptyGrid));
      setCombo(0);
      setComboHistory([]);
      setComboMovesLeft(3);
      setRetriesLeft(3);
      setHintsThisRound(0);
      setIsGameOverHandling(false);
      setHints([]);
      if (id === 'time_attack') {
        setTimeLeft(180);
      }
      if (id === 'combo_rush') {
        setComboTimeLeft(10);
      }
    }
    toggleUnlockable(id);
  };

  const [ghostText, setGhostText] = useState<string | null>(null);
  const [floatingPoints, setFloatingPoints] = useState<{ id: number, points: number, color: Color } | null>(null);
  const [showAchievements, setShowAchievements] = useState(false);
  const [newAchievement, setNewAchievement] = useState<Achievement | null>(null);

  const audioCtxRef = useRef<AudioContext | null>(null);

  const unlockAchievement = (id: string) => {
    if (!unlockedAchievements.includes(id)) {
      setUnlockedAchievements(prev => {
        if (prev.includes(id)) return prev;
        const next = [...prev, id];
        localStorage.setItem('hueRingsAchievements', JSON.stringify(next));
        return next;
      });
      const achievement = ACHIEVEMENTS.find(a => a.id === id);
      if (achievement) {
        setNewAchievement(achievement);
        setTimeout(() => setNewAchievement(null), 3000);
        triggerHaptic(haptics, [40, 30, 40]);
      }
    }
  };

  const updateStats = (updates: Partial<GameStats>) => {
    setStats(prev => {
      const next = { ...prev };
      for (const key in updates) {
        (next as any)[key] += (updates as any)[key];
      }
      localStorage.setItem('hueRingsStats', JSON.stringify(next));
      return next;
    });
  };

  // Achievement Monitoring Effects
  useEffect(() => {
    if (stats.gamesPlayed >= 1) unlockAchievement('play_1');
    if (stats.gamesPlayed >= 5) unlockAchievement('play_5');
    if (stats.gamesPlayed >= 10) unlockAchievement('play_10');
    if (stats.gamesPlayed >= 25) unlockAchievement('play_25');
    if (stats.gamesPlayed >= 50) unlockAchievement('play_50');
    if (stats.gamesPlayed >= 100) unlockAchievement('play_100');

    if (stats.ringsPlaced >= 10) unlockAchievement('place_10');
    if (stats.ringsPlaced >= 50) unlockAchievement('place_50');
    if (stats.ringsPlaced >= 100) unlockAchievement('place_100');
    if (stats.ringsPlaced >= 500) unlockAchievement('place_500');
    if (stats.ringsPlaced >= 1000) unlockAchievement('place_1000');
    if (stats.ringsPlaced >= 5000) unlockAchievement('place_5000');

    if (stats.linesCleared >= 1) unlockAchievement('clear_1');
    if (stats.linesCleared >= 10) unlockAchievement('clear_10');
    if (stats.linesCleared >= 50) unlockAchievement('clear_50');
    if (stats.linesCleared >= 100) unlockAchievement('clear_100');
    if (stats.linesCleared >= 500) unlockAchievement('clear_500');
    if (stats.linesCleared >= 1000) unlockAchievement('clear_1000');

    if (stats.hintsUsed >= 1) unlockAchievement('hint_1');
    if (stats.hintsUsed >= 5) unlockAchievement('hint_5');
    if (stats.hintsUsed >= 10) unlockAchievement('hint_10');

    if (stats.critsLanded >= 1) unlockAchievement('crit_1');
    if (stats.critsLanded >= 10) unlockAchievement('crit_10');
    if (stats.critsLanded >= 50) unlockAchievement('crit_50');
    if (stats.critsLanded >= 100) unlockAchievement('crit_100');

    if (stats.megaCritsLanded >= 1) unlockAchievement('megacrit_1');
    if (stats.megaCritsLanded >= 5) unlockAchievement('megacrit_5');
    if (stats.megaCritsLanded >= 10) unlockAchievement('megacrit_10');

    if (stats.perfectClears >= 1) unlockAchievement('perfect_clear');
    if (stats.perfectClears >= 5) unlockAchievement('perfect_clear_5');
  }, [stats]);

  useEffect(() => {
    const currentScore = Math.max(score, highScore);
    if (currentScore > 0) unlockAchievement('score_first');
    if (currentScore >= 1000) unlockAchievement('score_1k');
    if (currentScore >= 5000) unlockAchievement('score_5k');
    if (currentScore >= 10000) unlockAchievement('score_10k');
    if (currentScore >= 25000) unlockAchievement('score_25k');
    if (currentScore >= 50000) unlockAchievement('score_50k');
    if (currentScore >= 75000) unlockAchievement('score_75k');
    if (currentScore >= 100000) unlockAchievement('score_100k');
    if (currentScore >= 150000) unlockAchievement('score_150k');
    if (currentScore >= 200000) unlockAchievement('score_200k');
    if (currentScore >= 250000) unlockAchievement('score_250k');
    if (currentScore >= 500000) unlockAchievement('score_500k');
    if (currentScore >= 750000) unlockAchievement('score_750k');
    if (currentScore >= 1000000) unlockAchievement('score_1m');
    if (currentScore >= 2000000) unlockAchievement('score_2m');
  }, [score, highScore]);

  useEffect(() => {
    if (combo > stats.highestCombo) {
      setStats(prev => {
        const next = { ...prev, highestCombo: combo };
        localStorage.setItem('hueRingsStats', JSON.stringify(next));
        return next;
      });
    }
    if (combo >= 2) unlockAchievement('combo_2');
    if (combo >= 3) unlockAchievement('combo_3');
    if (combo >= 4) unlockAchievement('combo_4');
    if (combo >= 5) unlockAchievement('combo_5');
    if (combo >= 6) unlockAchievement('combo_6');
    if (combo >= 7) unlockAchievement('combo_7');
    if (combo >= 8) unlockAchievement('combo_8');
    if (combo >= 9) unlockAchievement('combo_9');
    if (combo >= 10) unlockAchievement('combo_10');
    if (combo >= 12) unlockAchievement('combo_12');
    if (combo >= 15) unlockAchievement('combo_15');
    if (combo >= 20) unlockAchievement('combo_20');
    if (combo >= 25) unlockAchievement('combo_25');
  }, [combo]);

  useEffect(() => {
    updateStats({ gamesPlayed: 1 });
  }, []);

  const playComboSound = (comboLevel: number) => {
    if (!sfx) return;
    
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      // Neon/arcade tone
      osc.type = 'square';
      
      // Increase pitch with combo level
      const baseFreq = 220; // A3
      const freq = baseFreq * Math.pow(1.12246, comboLevel * 2); // Go up by whole steps
      
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      // Add a quick slide up for higher combos
      if (comboLevel > 1) {
        osc.frequency.exponentialRampToValueAtTime(freq * 1.5, ctx.currentTime + 0.15);
      }

      gain.gain.setValueAtTime(0, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch (e) {
      console.log("Audio play failed:", e);
    }
  };

  const playExplosionSound = () => {
    if (!sfx) return;
    
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      // Explosion sound: noise-like
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(100, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(50, ctx.currentTime + 0.2);

      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    } catch (e) {
      console.log("Audio play failed:", e);
    }
  };

  const requestHint = () => {
    if (hintsThisRound >= 5) return;
    
    // 70% chance to show an ad, otherwise grant hint immediately
    if (Math.random() < 0.7) {
      showRewardAd('hint');
    } else {
      grantHint();
    }
  };

  const grantHint = () => {
    setHintsThisRound(prev => prev + 1);
    updateStats({ hintsUsed: 1 });

    const simulateMove = (piece: QueuePiece, r: number, c: number, currentGrid: Cell[][]) => {
      if (!canPlace(piece, currentGrid[r][c])) return -1;
      const tempGrid = JSON.parse(JSON.stringify(currentGrid));
      if (piece.small) tempGrid[r][c].small = { id: 'temp', size: 'small', color: piece.small };
      if (piece.medium) tempGrid[r][c].medium = { id: 'temp', size: 'medium', color: piece.medium };
      if (piece.large) tempGrid[r][c].large = { id: 'temp', size: 'large', color: piece.large };
      const { matchCount } = checkMatches(tempGrid);
      return matchCount;
    };

    let bestMoves: { r: number, c: number, pieceIndex: number, score: number }[] = [];
    
    // 1-move evaluation
    for (let i = 0; i < queue.length; i++) {
      const piece = queue[i];
      if (!piece) continue;
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          const score = simulateMove(piece, r, c, grid);
          if (score >= 0) {
            bestMoves.push({ r, c, pieceIndex: i, score });
          }
        }
      }
    }
    
    // Sort by score (matchCount)
    bestMoves.sort((a, b) => b.score - a.score);
    
    if (bestMoves.length > 0 && bestMoves[0].score > 0) {
      setHints([{ ...bestMoves[0], order: 1 }]);
      return;
    }
    
    // If no single move creates a match, look for 2-move sequence
    for (let i = 0; i < queue.length; i++) {
      const piece1 = queue[i];
      if (!piece1) continue;
      for (let r1 = 0; r1 < GRID_SIZE; r1++) {
        for (let c1 = 0; c1 < GRID_SIZE; c1++) {
          if (!canPlace(piece1, grid[r1][c1])) continue;
          
          // Simulate first move
          const tempGrid = JSON.parse(JSON.stringify(grid));
          if (piece1.small) tempGrid[r1][c1].small = { id: 'temp', size: 'small', color: piece1.small };
          if (piece1.medium) tempGrid[r1][c1].medium = { id: 'temp', size: 'medium', color: piece1.medium };
          if (piece1.large) tempGrid[r1][c1].large = { id: 'temp', size: 'large', color: piece1.large };
          
          // Check if it cleared anything
          const { grid: matchedGrid } = checkMatches(tempGrid);
          
          // Look for second move
          for (let j = 0; j < queue.length; j++) {
            if (i === j) continue;
            const piece2 = queue[j];
            if (!piece2) continue;
            
            for (let r2 = 0; r2 < GRID_SIZE; r2++) {
              for (let c2 = 0; c2 < GRID_SIZE; c2++) {
                const score2 = simulateMove(piece2, r2, c2, matchedGrid);
                if (score2 > 0) {
                  setHints([
                    { r: r1, c: c1, pieceIndex: i, score: 0, order: 1 },
                    { r: r2, c: c2, pieceIndex: j, score: score2, order: 2 }
                  ]);
                  return;
                }
              }
            }
          }
        }
      }
    }
    
    // Fallback to any valid move
    if (bestMoves.length > 0) {
      setHints([{ ...bestMoves[0], order: 1 }]);
    }
  };

  const skipContinue = () => {
    setShowContinueModal(false);
    if (score > highScore) {
      setHighScore(score);
    }
    onGameOver(score);
  };

  const actualRetriesLeft = (activeUnlockables.god_mode || activeUnlockables.zen_mode) ? 999 : retriesLeft;

  useEffect(() => {
    if (!isGameOverHandling && checkGameOver(grid, queue)) {
      setIsGameOverHandling(true);
      if (actualRetriesLeft > 0 && !activeUnlockables.zen_mode) {
        // Pre-calculate the combo bonus for the continue screen
        if (comboHistory.length > 0) {
          const randomCombo = comboHistory[Math.floor(Math.random() * comboHistory.length)];
          setNextContinueCombo(randomCombo);
        } else {
          setNextContinueCombo(0);
        }
        setShowContinueModal(true);
      } else if (!activeUnlockables.zen_mode) {
        if (score > highScore) {
          setHighScore(score);
        }
        setTimeout(() => onGameOver(score), 1000);
      }
    }
  }, [grid, queue, isGameOverHandling, actualRetriesLeft, score, highScore, onGameOver]);

  const [timeLeft, setTimeLeft] = useState(180);
  useEffect(() => {
    if (activeUnlockables.time_attack && timeLeft > 0 && !isGameOverHandling) {
      const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
      return () => clearInterval(timer);
    } else if (activeUnlockables.time_attack && timeLeft === 0 && !isGameOverHandling) {
      setIsGameOverHandling(true);
      if (score > highScore) {
        setHighScore(score);
      }
      setTimeout(() => onGameOver(score), 1000);
    }
  }, [activeUnlockables.time_attack, timeLeft, isGameOverHandling, score, highScore, onGameOver]);

  const handleDrop = (pieceIndex: number, r: number, c: number) => {
    const piece = queue[pieceIndex];
    if (!piece) return;

    if (canPlace(piece, grid[r][c])) {
      const newGrid = grid.map(row => [...row]);
      newGrid[r][c] = { ...newGrid[r][c] };
      
      if (piece.small) newGrid[r][c].small = { id: Math.random().toString(), size: 'small', color: piece.small };
      if (piece.medium) newGrid[r][c].medium = { id: Math.random().toString(), size: 'medium', color: piece.medium };
      if (piece.large) newGrid[r][c].large = { id: Math.random().toString(), size: 'large', color: piece.large };

      const newQueue = [...queue];
      newQueue[pieceIndex] = null;
      setHints([]);
      
      let currentGrid = newGrid;
      let totalScore = 2;
      let criticalCount = 0;
      
      const { grid: matchedGrid, matchCount, matchColors, clearedRings } = checkMatches(currentGrid);
      
      if (matchCount > 0) {
        currentGrid = matchedGrid;
        
        if (activeUnlockables.synthwave) {
          setGlitch(true);
          setTimeout(() => setGlitch(false), 200);
        }
        
        if (activeUnlockables.explosive_clears) {
          playExplosionSound();
          setFlash(true);
          setTimeout(() => setFlash(false), 100);
          const newParticles: any[] = [];
          const newShockwaves: any[] = [];
          clearedRings.forEach(ring => {
            // Add shockwave
            newShockwaves.push({
              id: Math.random(),
              x: ring.c * 100 + 50,
              y: ring.r * 100 + 50,
              color: getThemeColor(ring.color, activeUnlockables)
            });

            // Generate 15-20 particles per ring for a massive explosion
            const count = 15 + Math.floor(Math.random() * 6);
            for (let i = 0; i < count; i++) {
              const angle = Math.random() * Math.PI * 2;
              const velocity = 150 + Math.random() * 500;
              newParticles.push({
                id: Math.random(),
                x: ring.c * 100 + 50,
                y: ring.r * 100 + 50,
                tx: Math.cos(angle) * velocity,
                ty: Math.sin(angle) * velocity,
                size: 4 + Math.random() * 14,
                rotation: Math.random() * 1080,
                color: getThemeColor(ring.color, activeUnlockables)
              });
            }
          });
          setParticles(prev => [...prev, ...newParticles]);
          setShockwaves(prev => [...prev, ...newShockwaves]);
          setTimeout(() => {
            setParticles(prev => prev.filter(p => !newParticles.includes(p)));
            setShockwaves(prev => prev.filter(s => !newShockwaves.includes(s)));
          }, 1200);
        }
        
        let newCombo = combo + matchCount;
        setCombo(newCombo);
        setComboHistory(prev => [...prev, newCombo]);
        setComboMovesLeft(3);
        
        if (newCombo % 5 === 0 && newCombo > 0) {
          triggerSpecialParticles('mega_crit', '#00f2ff');
          setGhostText(`COMBO BURST! ${newCombo}`);
          setTimeout(() => setGhostText(null), 1000);
          setFlash(true);
          setTimeout(() => setFlash(false), 150);
        }
        
        let moveScore = 0;
        let tempCombo = combo;
        
        for (let i = 0; i < matchCount; i++) {
          tempCombo++;
          // Spicy base: 80-150 range
          const baseVal = 80 + Math.floor(Math.random() * 71);
          // Combo Rush gives a 2.5x multiplier to the combo factor
          const comboFactor = activeUnlockables.combo_rush ? tempCombo * 2.5 : tempCombo;
          let matchPoints = Math.floor(baseVal * comboFactor);
          
          // Multi-Clear Bonus: 1.2x for each additional match
          if (matchCount > 1) {
            matchPoints = Math.floor(matchPoints * 1.2);
          }

          // Critical Hit: 15% chance for 2x-4x multiplier
          if (Math.random() < 0.15) {
            const critMult = 2 + (Math.random() * 2);
            matchPoints = Math.floor(matchPoints * critMult);
            criticalCount++;
          }
          
          moveScore += matchPoints;
        }
        totalScore += moveScore;
        
        const color = matchColors[0];
        setPulseColor(color);
        setLastMatchColor(color);
        setTimeout(() => setPulseColor(null), 500);
        
        if (criticalCount > 1) {
          setGhostText(`MEGA CRIT! X${newCombo}`);
          unlockAchievement('mega_crit');
          triggerSpecialParticles('mega_crit', getThemeColor(color, activeUnlockables));
          setFlash(true);
          setTimeout(() => setFlash(false), 200);
        } else if (matchCount > 1) {
          setGhostText(`MULTI CLEAR! X${newCombo}`);
        } else if (criticalCount === 1) {
          setGhostText(`CRITICAL! X${newCombo}`);
        } else {
          setGhostText(`X${newCombo}`);
        }
        setTimeout(() => setGhostText(null), 1000);

        setFloatingPoints({ id: Date.now(), points: totalScore, color });
        setTimeout(() => setFloatingPoints(null), 1500);
        
        playComboSound(newCombo);
        
        if (newCombo >= 3 || activeUnlockables.explosive_clears) {
          setShake(true);
          setTimeout(() => setShake(false), activeUnlockables.explosive_clears ? 800 : 300);
          const baseVibration = activeUnlockables.explosive_clears ? 100 : 50;
          triggerHaptic(haptics, baseVibration * (screenShake ? 1 : 0.5));
        }
        
        if (activeUnlockables.combo_rush) {
          setComboTimeLeft(10);
        }

        const isPerfectClear = currentGrid.every(row => row.every(cell => !cell.small && !cell.medium && !cell.large));
        if (isPerfectClear) {
          unlockAchievement('perfect_clear');
          triggerSpecialParticles('perfect_clear', '#ffffff');
          setGhostText("PERFECT CLEAR!");
          setTimeout(() => setGhostText(null), 2000);
          setFlash(true);
          setTimeout(() => setFlash(false), 300);
        }
      } else {
        if (combo > 0 && !activeUnlockables.combo_rush) {
          const newMovesLeft = comboMovesLeft - 1;
          if (newMovesLeft <= 0) {
            setCombo(0);
            setComboMovesLeft(3);
          } else {
            setComboMovesLeft(newMovesLeft);
          }
        }
      }

      setGrid(currentGrid);
      setScore(s => {
        const next = s + totalScore;
        if (Math.floor(next / 10000) > Math.floor(s / 10000)) {
          const types: ('hammer' | 'reroll' | 'freeze')[] = ['hammer', 'reroll'];
          if (activeUnlockables.combo_rush) {
            types.push('freeze');
          }
          const randomType = types[Math.floor(Math.random() * types.length)];
          setPowerUps(prev => ({ ...prev, [randomType]: prev[randomType] + 1 }));
          setGhostText(`+1 ${randomType.toUpperCase()}!`);
          setTimeout(() => setGhostText(null), 2000);
        }
        return next;
      });

      const isGridEmpty = currentGrid.every(row => row.every(cell => !cell.small && !cell.medium && !cell.large));

      updateStats({
        ringsPlaced: 1,
        linesCleared: matchCount,
        critsLanded: criticalCount === 1 ? 1 : 0,
        megaCritsLanded: criticalCount > 1 ? 1 : 0,
        totalMatches: matchCount > 0 ? 1 : 0,
        perfectClears: isGridEmpty ? 1 : 0,
      });

      if (newQueue.every(p => p === null)) {
        setQueue(generateHelpfulQueue(currentGrid));
      } else {
        setQueue(newQueue);
      }
    }
  };

  const handleRerollQueue = () => {
    if (powerUps.reroll <= 0) {
      showRewardAd('reroll');
      return;
    }
    setPowerUps(prev => ({ ...prev, reroll: prev.reroll - 1 }));
    setQueue(generateHelpfulQueue(grid));
    triggerHaptic(haptics, 20);
  };

  const handleFreezeCombo = () => {
    if (isFrozen) return;
    if (powerUps.freeze <= 0) {
      showRewardAd('freeze');
      return;
    }
    setPowerUps(prev => ({ ...prev, freeze: prev.freeze - 1 }));
    setIsFrozen(true);
    setFreezeTimeLeft(10);
    triggerHaptic(haptics, [30, 20, 30]);
  };

  const handleCellClick = (r: number, c: number) => {
    if (activePowerUp === 'hammer' && powerUps.hammer > 0) {
      const newGrid = grid.map(row => [...row]);
      if (newGrid[r][c].small || newGrid[r][c].medium || newGrid[r][c].large) {
        newGrid[r][c] = { small: null, medium: null, large: null };
        setGrid(newGrid);
        setPowerUps(prev => ({ ...prev, hammer: prev.hammer - 1 }));
        setActivePowerUp(null);
        setShake(true);
        setTimeout(() => setShake(false), 300);
        triggerHaptic(haptics, 40);
      }
    }
  };

  const synthwaveStyle = activeUnlockables.synthwave ? {
    backgroundImage: 'linear-gradient(to bottom, #0d0221, #240b36, #4d033b)',
  } : {};

  return (
    <div className="flex flex-col items-center p-4 pt-safe pb-safe h-full font-sans relative transition-colors duration-500 overflow-hidden"
      onClick={(e) => e.stopPropagation()}
      style={{ 
        ...synthwaveStyle,
        backgroundColor: !activeUnlockables.synthwave ? (activeUnlockables.light_theme ? '#F1F5F9' : '#0F172A') : undefined 
      }}
    >
      {activeUnlockables.synthwave && (
        <div className="absolute inset-0 pointer-events-none z-[100] retro-crt-screen opacity-30" />
      )}
      <SynthwaveBackground combo={combo} activeUnlockables={activeUnlockables} />
      <CyberpunkBackground combo={combo} activeUnlockables={activeUnlockables} />
      <MinimalistBackground activeUnlockables={activeUnlockables} />
      <OceanicBackground activeUnlockables={activeUnlockables} />
      <VolcanoBackground activeUnlockables={activeUnlockables} />
      <NebulaBackground activeUnlockables={activeUnlockables} />
      <SupernovaBackground combo={combo} activeUnlockables={activeUnlockables} />
      {activeUnlockables.rainbow_rings && (
        <motion.div 
          className="absolute inset-0 z-0 opacity-20 pointer-events-none"
          animate={{
            background: [
              'linear-gradient(45deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #9400d3)',
              'linear-gradient(135deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #9400d3)',
              'linear-gradient(225deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #9400d3)',
              'linear-gradient(315deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #9400d3)',
              'linear-gradient(45deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #9400d3)',
            ]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        />
      )}
      <AnimatePresence>
        {floatingPoints && (
          <PointsTicker points={floatingPoints.points} color={floatingPoints.color} activeUnlockables={activeUnlockables} />
        )}
      </AnimatePresence>
      <div 
        className="absolute inset-0 pointer-events-none transition-all duration-500 z-0"
        style={{ 
          background: 'transparent',
          opacity: 0
        }}
      />
      <div 
        className="absolute inset-0 pointer-events-none transition-colors duration-300 z-0"
        style={{ backgroundColor: pulseColor ? `${getThemeColor(pulseColor, activeUnlockables)}40` : 'transparent' }}
      />
      {watchingAdFor && (
        <RewardedAdSimulation 
          onComplete={onAdComplete}
          onCancel={() => setWatchingAdFor(null)}
          rewardText={watchingAdFor === 'continue' ? "Continue Game" : `Get ${watchingAdFor}s`}
          activeUnlockables={activeUnlockables}
        />
      )}
      {showContinueModal && (
        <ContinueModal 
          retriesLeft={retriesLeft}
          startingCombo={nextContinueCombo}
          onContinue={() => {
            setShowContinueModal(false);
            showRewardAd('continue');
          }}
          onSkip={skipContinue}
          activeUnlockables={activeUnlockables}
          haptics={haptics}
        />
      )}
      {showAchievements && (
        <AchievementsModal 
          onClose={() => { setShowAchievements(false); triggerHaptic(haptics, 5); }} 
          unlockedAchievements={unlockedAchievements} 
          activeUnlockables={activeUnlockables}
          toggleUnlockable={toggleUnlockable}
          stats={stats}
          score={score}
          highScore={highScore}
          combo={combo}
          haptics={haptics}
        />
      )}
      <AnimatePresence>
        {newAchievement && <AchievementToast achievement={newAchievement} activeUnlockables={activeUnlockables} />}
      </AnimatePresence>

      {activePowerUp === 'hammer' && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[1000] pointer-events-none flex items-center justify-center bg-[#ff007f]/10"
        >
          <div className="bg-black/80 backdrop-blur-md px-6 py-3 rounded-full border border-[#ff007f] text-[#ff007f] font-black uppercase tracking-widest flex items-center gap-2">
            <Hammer size={24} className="animate-bounce" />
            Select a cell to clear
            <button 
              onClick={(e) => { e.stopPropagation(); setActivePowerUp(null); }}
              className="ml-4 p-1 bg-white/10 rounded-full pointer-events-auto"
            >
              <X size={16} />
            </button>
          </div>
        </motion.div>
      )}
      
      <motion.div 
        animate={shake && screenShake ? { 
          x: activeUnlockables.explosive_clears ? [-10, 10, -8, 8, -5, 5, 0] : [-2, 2, -2, 2, 0], 
          y: activeUnlockables.explosive_clears ? [-10, 10, -8, 8, -5, 5, 0] : [-2, 2, -2, 2, 0] 
        } : {}}
        transition={{ duration: activeUnlockables.explosive_clears ? 0.5 : 0.3 }}
        className="w-full max-w-md flex flex-col items-center flex-grow z-10"
      >
        <header className="w-full flex flex-col gap-3 mb-6 pt-safe pt-6 relative">
          <div className="w-full flex justify-between items-start relative px-2">

            <div className="flex flex-col gap-3 z-[200]">
              <div className="flex gap-2">
                <button onClick={onHome} className={`w-11 h-11 flex items-center justify-center border rounded-xl transition-all group backdrop-blur-sm relative overflow-hidden ${activeUnlockables.light_theme ? 'bg-slate-900/10 border-slate-900/10 hover:bg-slate-900/20 hover:border-[#00f2ff]' : 'bg-black/50 border-white/10 hover:bg-white/10 hover:border-[#00f2ff]'}`}>
                  <div className="absolute inset-0 bg-gradient-to-r from-[#00f2ff]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <Home size={22} className={`${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'} group-hover:text-[#00f2ff] transition-colors relative z-10`} />
                </button>

                <div className="relative">
                  <button 
                    onClick={() => setShowQuickSettings(!showQuickSettings)} 
                    className={`w-11 h-11 flex items-center justify-center border rounded-xl transition-all group backdrop-blur-sm relative overflow-hidden gap-1 ${activeUnlockables.light_theme ? 'bg-slate-900/10 border-slate-900/10 hover:bg-slate-900/20 hover:border-[#ff007f]' : 'bg-black/50 border-white/10 hover:bg-white/10 hover:border-[#ff007f]'}`}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-[#ff007f]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <Palette size={22} className={`${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'} group-hover:text-[#ff007f] transition-colors relative z-10`} />
                    <ChevronDown size={14} className={`${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'} transition-transform duration-300 ${showQuickSettings ? 'rotate-180' : ''}`} />
                  </button>

                  <AnimatePresence>
                    {showQuickSettings && (
                      <>
                        <motion.div 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          onClick={() => setShowQuickSettings(false)}
                          className="fixed inset-0 z-[190] cursor-default"
                        />
                        <motion.div
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className={`absolute top-full left-0 mt-2 w-48 max-h-[70vh] overflow-y-auto custom-scrollbar rounded-xl border shadow-2xl z-[200] backdrop-blur-xl ${activeUnlockables.light_theme ? 'bg-white/90 border-slate-200' : 'bg-[#1e293b]/90 border-white/10'}`}
                        >
                        <div className="p-3 space-y-4">
                          {/* Audio Section */}
                          <div>
                            <h4 className="text-[9px] font-black text-[#00f2ff] uppercase tracking-widest mb-2 px-1">Audio</h4>
                            <div className="space-y-1">
                              <button
                                onClick={() => {
                                  setMusic(!music);
                                  triggerHaptic(haptics, 5);
                                }}
                                className={`w-full text-left px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all flex items-center justify-between ${
                                  music 
                                    ? 'bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/30' 
                                    : (activeUnlockables.light_theme ? 'text-slate-600 hover:bg-slate-900/5' : 'text-white/60 hover:bg-white/5')
                                }`}
                              >
                                Music: {music ? 'ON' : 'OFF'}
                                {music ? <Video size={10} /> : <Lock size={10} />}
                              </button>
                            </div>
                          </div>
                          {/* Modes Section */}
                          <div>
                            <h4 className="text-[9px] font-black text-[#00f2ff] uppercase tracking-widest mb-2 px-1">Game Modes</h4>
                            <div className="space-y-1">
                              <button
                                onClick={() => {
                                  clearUnlockables();
                                  const emptyGrid = Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill({ small: null, medium: null, large: null }));
                                  setScore(0);
                                  setGrid(emptyGrid);
                                  setQueue(generateHelpfulQueue(emptyGrid));
                                  setCombo(0);
                                  setComboHistory([]);
                                  setComboMovesLeft(3);
                                  setRetriesLeft(3);
                                  setHintsThisRound(0);
                                  setIsGameOverHandling(false);
                                  setHints([]);
                                  setShowQuickSettings(false);
                                }}
                                className={`w-full text-left px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all flex items-center justify-between ${
                                  !UNLOCKABLES.some(u => (u.type === 'mode' || u.type === 'theme') && activeUnlockables[u.id])
                                    ? 'bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/30' 
                                    : (activeUnlockables.light_theme ? 'text-slate-600 hover:bg-slate-900/5' : 'text-white/60 hover:bg-white/5')
                                }`}
                              >
                                Default
                                {!UNLOCKABLES.some(u => (u.type === 'mode' || u.type === 'theme') && activeUnlockables[u.id]) && <Shield size={10} />}
                              </button>
                              {UNLOCKABLES.filter(u => u.type === 'mode').map(mode => (
                                <button
                                  key={mode.id}
                                  onClick={() => {
                                    handleToggle(mode.id);
                                    setShowQuickSettings(false);
                                  }}
                                  className={`w-full text-left px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all flex items-center justify-between ${
                                    activeUnlockables[mode.id] 
                                      ? 'bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/30' 
                                      : (activeUnlockables.light_theme ? 'text-slate-600 hover:bg-slate-900/5' : 'text-white/60 hover:bg-white/5')
                                  }`}
                                >
                                  {mode.name}
                                  {activeUnlockables[mode.id] && <Shield size={10} />}
                                </button>
                              ))}
                              {UNLOCKABLES.filter(u => u.type === 'mode').length === 0 && (
                                <p className="text-[8px] text-gray-500 italic px-1">Unlock modes in Achievements</p>
                              )}
                            </div>
                          </div>

                          {/* Themes Section */}
                          <div>
                            <h4 className="text-[9px] font-black text-[#ff007f] uppercase tracking-widest mb-2 px-1">Themes</h4>
                            <div className="space-y-1">
                              {UNLOCKABLES.filter(u => u.type === 'theme').map(theme => (
                                <button
                                  key={theme.id}
                                  onClick={() => {
                                    handleToggle(theme.id);
                                    setShowQuickSettings(false);
                                  }}
                                  className={`w-full text-left px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all flex items-center justify-between ${
                                    activeUnlockables[theme.id] 
                                      ? 'bg-[#ff007f]/20 text-[#ff007f] border border-[#ff007f]/30' 
                                      : (activeUnlockables.light_theme ? 'text-slate-600 hover:bg-slate-900/5' : 'text-white/60 hover:bg-white/5')
                                  }`}
                                >
                                  {theme.name}
                                  {activeUnlockables[theme.id] && <Shield size={10} />}
                                </button>
                              ))}
                              {UNLOCKABLES.filter(u => u.type === 'theme').length === 0 && (
                                <p className="text-[8px] text-gray-500 italic px-1">Unlock themes in Achievements</p>
                              )}
                            </div>
                          </div>

                          {/* Effects Section */}
                          <div>
                            <h4 className="text-[9px] font-black text-[#39FF14] uppercase tracking-widest mb-2 px-1">Effects</h4>
                            <div className="space-y-1">
                              {UNLOCKABLES.filter(u => u.type === 'effect').map(effect => (
                                <button
                                  key={effect.id}
                                  onClick={() => {
                                    toggleUnlockable(effect.id);
                                    setShowQuickSettings(false);
                                  }}
                                  className={`w-full text-left px-3 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all flex items-center justify-between ${
                                    activeUnlockables[effect.id] 
                                      ? 'bg-[#39FF14]/20 text-[#39FF14] border border-[#39FF14]/30' 
                                      : (activeUnlockables.light_theme ? 'text-slate-600 hover:bg-slate-900/5' : 'text-white/60 hover:bg-white/5')
                                  }`}
                                >
                                  {effect.name}
                                  {activeUnlockables[effect.id] && <Shield size={10} />}
                                </button>
                              ))}
                            </div>
                          </div>

                        </div>
                      </motion.div>
                    </>
                  )}
                  </AnimatePresence>
                </div>
              </div>

              <button 
                onClick={requestHint} 
                disabled={hintsThisRound >= 5}
                className={`h-11 px-4 border rounded-xl transition-all flex items-center gap-2 text-[10px] font-black tracking-widest shadow-[0_0_10px_rgba(0,242,255,0.2)] backdrop-blur-sm relative overflow-hidden group ${
                  hintsThisRound >= 5 
                    ? 'opacity-50 cursor-not-allowed grayscale' 
                    : activeUnlockables.light_theme 
                      ? 'bg-slate-900/10 border-[#00f2ff]/30 hover:bg-[#00f2ff]/20 text-[#00f2ff]' 
                      : 'bg-black/50 border-[#00f2ff]/30 hover:bg-[#00f2ff]/20 text-[#00f2ff]'
                }`}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#00f2ff]/20 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]"></div>
                <Video size={16} className="relative z-10" /> HINT ({5 - hintsThisRound})
              </button>
            </div>

            <div className="flex flex-col items-center relative z-10">
              <button 
                onClick={() => setShowAchievements(true)}
                className="relative w-28 h-28 flex items-center justify-center group hover:scale-105 transition-transform"
              >
                {/* Rotating rings for score */}
                <div className="absolute w-full h-full border-2 border-[#00f2ff]/20 rounded-full border-t-[#00f2ff] animate-[spin_4s_linear_infinite] group-hover:border-[#00f2ff]/40 transition-colors"></div>
                <div className="absolute w-[85%] h-[85%] border-2 border-[#ff007f]/20 rounded-full border-b-[#ff007f] animate-[spin_3s_linear_infinite_reverse] group-hover:border-[#ff007f]/40 transition-colors"></div>
                <div className={`absolute w-[70%] h-[70%] border rounded-full border-l-[#39FF14] animate-[spin_5s_linear_infinite] transition-colors ${activeUnlockables.light_theme ? 'border-slate-900/10 group-hover:border-slate-900/30' : 'border-white/10 group-hover:border-white/30'}`}></div>
                
        <div className={`flex flex-col items-center justify-center w-[65%] h-[65%] rounded-full backdrop-blur-xl border shadow-[0_0_20px_rgba(0,0,0,0.5),inset_0_0_15px_rgba(0,242,255,0.2)] transition-colors ${activeUnlockables.light_theme ? 'bg-white/80 border-slate-900/10 group-hover:bg-white' : 'bg-black/80 border-white/20 group-hover:bg-black/90'}`}>
          <span className={`text-[8px] uppercase tracking-[0.3em] font-bold mb-[-4px] opacity-80 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] ${activeUnlockables.synthwave ? 'retro-text text-[#ff007f]' : 'text-[#00f2ff]'}`}>Score</span>
          <span className={`text-2xl font-black tracking-tighter drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)] ${activeUnlockables.synthwave ? 'retro-text text-[#ff007f] drop-shadow-[0_0_10px_#ff007f]' : (activeUnlockables.light_theme ? 'text-slate-900' : 'text-white')} ${activeUnlockables.synthwave ? '' : 'font-mono'}`}>{score} {combo > 1 && <span className={`text-sm ${activeUnlockables.synthwave ? 'retro-text text-yellow-400' : 'text-yellow-400'}`}>x{combo}</span>}</span>
          <div className="flex items-center gap-1 mt-1 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
            <Trophy size={10} className="text-yellow-400" />
            <span className={`text-[10px] font-bold text-yellow-400 ${activeUnlockables.synthwave ? 'retro-text' : ''}`}>{unlockedAchievements.length}/{ACHIEVEMENTS.length}</span>
          </div>
        </div>



                {combo >= 2 && lastMatchColor && (
                  <motion.div 
                    className={`absolute left-[80%] top-[10%] text-xl font-black italic font-mono px-3 py-1.5 rounded-xl border backdrop-blur-xl shadow-[0_4px_20px_rgba(0,0,0,0.5)] ${activeUnlockables.light_theme ? 'bg-white/90 border-slate-900/20' : 'bg-black/90 border-white/20'}`}
                    style={{ 
                      color: getThemeColor(lastMatchColor, activeUnlockables),
                      opacity: comboMovesLeft / 3, 
                      scale: 1 + (comboMovesLeft / 3) * 0.3,
                      filter: `drop-shadow(0 0 ${10 * (comboMovesLeft/3)}px ${getThemeColor(lastMatchColor, activeUnlockables)})`,
                      borderColor: `${getThemeColor(lastMatchColor, activeUnlockables)}40`
                    }}
                  >
                    x{combo}
                  </motion.div>
                )}
              </button>
            </div>

            <div className="flex flex-col items-end gap-3 px-2">
              <div className={`flex flex-col items-end z-10 p-3 rounded-2xl border backdrop-blur-xl shadow-[0_4px_15px_rgba(0,0,0,0.3)] ${activeUnlockables.light_theme ? 'bg-white/80 border-slate-900/10' : 'bg-black/80 border-white/20'}`}>
                <span className={`text-[9px] uppercase tracking-[0.2em] font-bold mb-1 flex items-center gap-1 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] ${activeUnlockables.synthwave ? 'retro-text text-cyan-400' : 'text-[#ff007f]'}`}>
                  <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${activeUnlockables.synthwave ? 'bg-cyan-400 shadow-[0_0_5px_#22d3ee]' : 'bg-[#ff007f] shadow-[0_0_5px_#ff007f]'}`}></div>
                  Best
                </span>
                <span className={`text-xl font-black tracking-tight drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)] ${activeUnlockables.synthwave ? 'retro-text text-cyan-400 drop-shadow-[0_0_10px_#00ffff]' : (activeUnlockables.light_theme ? 'text-slate-900' : 'text-white')} ${activeUnlockables.synthwave ? '' : 'font-mono'}`}>{Math.max(score, highScore)}</span>
              </div>

              {/* Compact Power-Ups Bar */}
              <div className={`flex gap-2 p-2 rounded-2xl backdrop-blur-md border ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10' : 'bg-white/5 border-white/10'}`}>
                <PowerUpButton 
                  icon={<Hammer size={16} />} 
                  count={powerUps.hammer} 
                  active={activePowerUp === 'hammer'}
                  loading={watchingAdFor === 'hammer'}
                  onClick={() => {
                    if (powerUps.hammer > 0) {
                      setActivePowerUp(activePowerUp === 'hammer' ? null : 'hammer');
                      triggerHaptic(haptics, 5);
                    } else {
                      showRewardAd('hammer');
                    }
                  }}
                  label="Hammer"
                  color="#ff007f"
                  activeUnlockables={activeUnlockables}
                  compact
                />
                <PowerUpButton 
                  icon={<RefreshCw size={16} />} 
                  count={powerUps.reroll} 
                  loading={watchingAdFor === 'reroll'}
                  onClick={handleRerollQueue}
                  label="Reroll"
                  color="#00f2ff"
                  activeUnlockables={activeUnlockables}
                  compact
                />
                {activeUnlockables.combo_rush && (
                  <PowerUpButton 
                    icon={<Zap size={16} />} 
                    count={powerUps.freeze} 
                    active={isFrozen}
                    loading={watchingAdFor === 'freeze'}
                    onClick={handleFreezeCombo}
                    label="Freeze"
                    color="#39FF14"
                    timer={isFrozen ? freezeTimeLeft : null}
                    activeUnlockables={activeUnlockables}
                    compact
                  />
                )}
              </div>
            </div>
          </div>
        </header>

        <div className="w-full max-w-sm mb-2 px-4 relative z-10 flex flex-col gap-2">
          {activeUnlockables.time_attack && (
            <div>
              <div className={`flex justify-between text-[9px] uppercase tracking-[0.3em] mb-1 font-bold ${activeUnlockables.light_theme ? 'text-slate-900/50' : 'text-white/50'}`}>
                <span className="text-[#ff007f] animate-pulse">Time Attack</span>
                <span className={`font-mono ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>{Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}</span>
              </div>
              <div className={`h-1.5 rounded-full overflow-hidden border relative ${activeUnlockables.light_theme ? 'bg-slate-900/10 border-slate-900/10' : 'bg-black/50 border-white/10'}`}>
                <motion.div 
                  className="h-full bg-gradient-to-r from-[#ff007f] to-[#ff0000] relative"
                  initial={{ width: '100%' }}
                  animate={{ width: `${(timeLeft / 180) * 100}%` }}
                  transition={{ duration: 1, ease: 'linear' }}
                />
              </div>
            </div>
          )}
          <div>
            <div className={`flex justify-between text-[9px] uppercase tracking-[0.3em] mb-1 font-bold ${activeUnlockables.light_theme ? 'text-slate-900/50' : 'text-white/50'}`}>
              <span>{activeUnlockables.combo_rush ? (combo > 0 ? 'Combo Timer' : 'Energy') : (combo > 0 ? 'Combo Active' : 'Energy')}</span>
              {combo > 0 && <span className="text-[#00f2ff] animate-pulse drop-shadow-[0_0_5px_#00f2ff]">{activeUnlockables.combo_rush ? `${comboTimeLeft.toFixed(1)}s` : `x${combo} Multiplier`}</span>}
            </div>
            <HeatMeter 
              combo={combo} 
              progress={activeUnlockables.combo_rush ? (combo > 0 ? (comboTimeLeft / 10) : 0) : (combo > 0 ? (comboMovesLeft / 3) : 0)} 
              activeUnlockables={activeUnlockables} 
            />
          </div>
        </div>

        <main className="w-full flex-grow flex items-center justify-center mb-2 relative">
          <motion.div 
            className={`grid grid-cols-3 gap-3 w-full max-w-[min(100%,_50vh)] aspect-square p-4 relative z-10 rounded-2xl transition-colors duration-100 ${glitch ? 'skew-x-2 skew-y-1' : ''}`}
            style={{
              backgroundColor: flash ? 'rgba(255, 255, 255, 0.3)' : undefined,
              filter: glitch ? 'hue-rotate(90deg) contrast(200%)' : 'none'
            }}
            animate={activeUnlockables.disco_grid ? {
              boxShadow: [
                '0 0 20px rgba(255, 0, 0, 0.4)',
                '0 0 40px rgba(0, 255, 0, 0.4)',
                '0 0 20px rgba(0, 0, 255, 0.4)',
                '0 0 40px rgba(255, 255, 0, 0.4)',
                '0 0 20px rgba(255, 0, 255, 0.4)',
                '0 0 40px rgba(0, 255, 255, 0.4)',
                '0 0 20px rgba(255, 0, 0, 0.4)'
              ],
              backgroundColor: [
                'rgba(255, 0, 0, 0.05)',
                'rgba(0, 255, 0, 0.05)',
                'rgba(0, 0, 255, 0.05)',
                'rgba(255, 255, 0, 0.05)',
                'rgba(255, 0, 255, 0.05)',
                'rgba(0, 255, 255, 0.05)',
                'rgba(255, 0, 0, 0.05)'
              ]
            } : { boxShadow: '0 0 0px rgba(0,0,0,0)', backgroundColor: 'transparent' }}
            transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
          >
            {grid.map((row, r) => row.map((cell, c) => (
              <CellView key={`${r}-${c}`} r={r} c={c} cell={cell} hints={hints} activeUnlockables={activeUnlockables} onClick={() => handleCellClick(r, c)} />
            )))}
            {shockwaves.map(s => (
              <motion.div
                key={s.id}
                initial={{ 
                  left: s.x, 
                  top: s.y, 
                  width: 0, 
                  height: 0, 
                  opacity: 0.8,
                  border: `4px solid ${s.color}`,
                  borderRadius: '50%',
                  x: '-50%',
                  y: '-50%'
                }}
                animate={{ 
                  width: 400, 
                  height: 400, 
                  opacity: 0,
                  borderWidth: 0
                }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="absolute z-40 pointer-events-none"
              />
            ))}
            {particles.map(p => (
              <motion.div
                key={p.id}
                initial={{ 
                  left: p.x, 
                  top: p.y, 
                  opacity: 1, 
                  scale: 1, 
                  rotate: 0,
                  boxShadow: `0 0 0px ${p.color}`
                }}
                animate={{ 
                  left: p.x + p.tx, 
                  top: p.y + p.ty, 
                  opacity: 0, 
                  scale: (p as any).isSparkle ? [1, 1.5, 0] : 0,
                  rotate: p.rotation,
                  boxShadow: (p as any).isSparkle ? [`0 0 10px ${p.color}`, `0 0 30px #ffffff`, `0 0 0px ${p.color}`] : `0 0 20px ${p.color}`
                }}
                transition={{ 
                  duration: (p as any).isSparkle ? 1.2 : 0.6 + Math.random() * 0.4, 
                  ease: [0.1, 0.9, 0.2, 1] // Custom cubic-bezier for "explosive" feel
                }}
                className="absolute z-50 pointer-events-none"
                style={{ 
                  width: (p as any).isSparkle ? p.size * 1.5 : p.size, 
                  height: (p as any).isSparkle ? p.size * 1.5 : p.size, 
                  backgroundColor: (p as any).isSparkle ? '#ffffff' : p.color,
                  borderRadius: (p as any).isSparkle ? '50%' : (Math.random() > 0.5 ? '2px' : '0px'), // Mix of cubes and slight rounds
                  border: (p as any).isSparkle ? 'none' : '1px solid rgba(255, 255, 255, 0.5)', // Bright edge
                  clipPath: (p as any).isSparkle ? 'polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)' : 'none' // Star shape for sparkles
                }}
              />
            ))}
          </motion.div>
          
          <AnimatePresence>
            {ghostText && lastMatchColor && (
              <motion.div
                initial={{ scale: 0.5, opacity: 0, y: 0 }}
                animate={{ scale: 2, opacity: 0.8, y: -50 }}
                exit={{ opacity: 0, scale: 2.5 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 pointer-events-none font-black text-6xl ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}
                style={{ 
                  WebkitTextStroke: `2px ${getThemeColor(lastMatchColor, activeUnlockables)}`, 
                  filter: `drop-shadow(0 0 20px ${getThemeColor(lastMatchColor, activeUnlockables)})` 
                }}
              >
                {ghostText}
              </motion.div>
            )}

            {floatingPoints && (
              <motion.div
                key={floatingPoints.id}
                initial={{ y: 50, opacity: 0, scale: 0.5, rotate: -10 }}
                animate={{ 
                  y: [0, -100, -120], 
                  opacity: [0, 1, 1, 0], 
                  scale: [1, 1.5, 1.2],
                  rotate: [0, 5, 0]
                }}
                transition={{ duration: 1.2, times: [0, 0.2, 0.8, 1] }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 z-[60] pointer-events-none"
              >
                <div className="flex flex-col items-center">
                  <motion.div 
                    animate={{ 
                      textShadow: [
                        `0 0 20px ${getThemeColor(floatingPoints.color, activeUnlockables)}`,
                        `0 0 40px ${getThemeColor(floatingPoints.color, activeUnlockables)}`,
                        `0 0 20px ${getThemeColor(floatingPoints.color, activeUnlockables)}`
                      ]
                    }}
                    transition={{ repeat: Infinity, duration: 0.5 }}
                    className={`text-7xl font-black italic tracking-tighter ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}
                    style={{
                      WebkitTextStroke: `2px ${getThemeColor(floatingPoints.color, activeUnlockables)}`,
                    }}
                  >
                    +{floatingPoints.points}
                  </motion.div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        <footer className="w-full pb-safe pb-6 mt-auto relative z-50">
          <div className="flex flex-col items-center gap-4">
            <div className={`flex justify-center items-center gap-4 p-4 rounded-2xl backdrop-blur-md border ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10' : 'bg-white/5 border-white/10'}`}>
              {queue.map((piece, i) => (
                <QueuePieceView key={i} piece={piece} index={i} hints={hints} onDrop={handleDrop} activeUnlockables={activeUnlockables} haptics={haptics} />
              ))}
            </div>

            <div className="w-full flex justify-center px-4">
              <div className={`w-full max-w-[320px] h-[50px] relative rounded-lg flex items-center justify-center text-[8px] uppercase tracking-[0.3em] backdrop-blur-md border shadow-lg transition-colors ${activeUnlockables.light_theme ? 'bg-slate-900/5 border-slate-900/10 text-slate-900/30' : 'bg-black/40 border-white/10 text-white/30'}`}>
                <div className={`absolute top-0 left-2 -translate-y-1/2 px-1.5 py-0.5 rounded text-[6px] border font-bold ${activeUnlockables.light_theme ? 'bg-white border-slate-900/10 text-slate-900/50' : 'bg-black border-white/10 text-white/50'}`}>AD</div>
                Advertisement
              </div>
            </div>
          </div>
        </footer>
        
        <AnimatePresence>
          {tutorialStep !== null && (
            <TutorialOverlay 
              step={tutorialStep} 
              onNext={nextTutorialStep} 
              onSkip={completeTutorial} 
              activeUnlockables={activeUnlockables} 
            />
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

const UserMenu = ({ user, activeUnlockables, onLogin, onAppleLogin, onLogout, onDeleteAccount }: { user: User | null, activeUnlockables: any, onLogin: () => void, onAppleLogin: () => void, onLogout: () => void, onDeleteAccount: () => void }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center h-11 gap-2 px-4 rounded-xl border transition-all ${activeUnlockables.light_theme ? 'bg-white border-slate-200 text-slate-900 shadow-sm' : 'bg-slate-900/50 border-white/10 text-white'} hover:scale-105 active:scale-95`}
      >
        {user ? (
          <>
            <img src={user.photoURL || ''} alt="" className="w-7 h-7 rounded-full border border-white/20" />
            <span className="text-xs font-bold truncate max-w-[80px]">{user.displayName}</span>
          </>
        ) : (
          <>
            <UserIcon size={20} />
            <span className="text-xs font-bold">Sign In</span>
          </>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 z-[1000]"
            />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className={`absolute top-full right-0 mt-2 w-48 rounded-2xl border shadow-2xl z-[1001] backdrop-blur-xl p-2 ${activeUnlockables.light_theme ? 'bg-white/90 border-slate-200' : 'bg-slate-900/90 border-white/10'}`}
            >
              {user ? (
                <div className="space-y-1">
                  <div className="px-3 py-2 border-b border-white/5 mb-1">
                    <p className="text-[10px] font-black text-[#00f2ff] uppercase tracking-widest">Account</p>
                    <p className={`text-[11px] font-bold truncate ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>{user.email}</p>
                  </div>
                  <button 
                    onClick={() => { onLogout(); setIsOpen(false); }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-slate-400 hover:bg-slate-400/10 transition-colors text-xs font-bold"
                  >
                    <LogOut size={16} />
                    Sign Out
                  </button>
                  <button 
                    onClick={() => { 
                      if (confirm("Are you sure you want to delete your account? This action is permanent and will delete all your cloud data.")) {
                        onDeleteAccount(); 
                        setIsOpen(false); 
                      }
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-red-500 hover:bg-red-500/10 transition-colors text-xs font-bold"
                  >
                    <AlertCircle size={16} />
                    Delete Account
                  </button>
                </div>
              ) : (
                <div className="space-y-1">
                  <button 
                    onClick={() => { onLogin(); setIsOpen(false); }}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors text-xs font-bold ${activeUnlockables.light_theme ? 'text-slate-900 hover:bg-slate-100' : 'text-white hover:bg-white/5'}`}
                  >
                    <LogIn size={16} />
                    Sign in with Google
                  </button>
                  <button 
                    onClick={() => { onAppleLogin(); setIsOpen(false); }}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors text-xs font-bold ${activeUnlockables.light_theme ? 'bg-black text-white hover:bg-black/90' : 'bg-white text-black hover:bg-white/90'}`}
                  >
                    <Apple size={16} fill="currentColor" />
                    Sign in with Apple
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

const Leaderboard = ({ onClose, activeUnlockables, currentMode, isOnline }: { onClose: () => void, activeUnlockables: any, currentMode: string, isOnline: boolean }) => {
  const [entries, setEntries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState(currentMode);

  useEffect(() => {
    setLoading(true);
    const q = query(
      collection(db, 'leaderboards', mode, 'entries'),
      orderBy('score', 'desc'),
      limit(50)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newEntries = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setEntries(newEntries);
      setLoading(false);
    }, (error) => {
      console.error("Leaderboard error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [mode]);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 z-[2000] flex items-center justify-center p-4 pt-safe pb-safe bg-black/60 backdrop-blur-sm"
    >
      <div className={`w-full max-w-md max-h-[80vh] rounded-3xl border flex flex-col overflow-hidden shadow-2xl ${activeUnlockables.light_theme ? 'bg-white border-slate-200' : 'bg-slate-900 border-white/10'}`}>
        <div className="p-6 flex items-center justify-between border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#00f2ff]/20 rounded-xl text-[#00f2ff]">
              <Globe size={24} />
            </div>
            <div>
              <h2 className={`text-xl font-black uppercase tracking-tighter ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>Global Ranks</h2>
              <p className="text-[10px] font-bold text-[#00f2ff] uppercase tracking-widest">Top 50 Players</p>
            </div>
          </div>
          <button onClick={onClose} className={`p-2 rounded-xl transition-colors ${activeUnlockables.light_theme ? 'hover:bg-slate-100 text-slate-400' : 'hover:bg-white/5 text-white/40'}`}>
            <X size={24} />
          </button>
        </div>

        <div className="flex gap-2 p-4 overflow-x-auto custom-scrollbar border-b border-white/5">
          {['default', 'combo_rush', 'zen_mode', 'time_attack', 'god_mode'].map(m => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                mode === m 
                  ? 'bg-[#00f2ff] text-slate-900' 
                  : (activeUnlockables.light_theme ? 'bg-slate-100 text-slate-400 hover:bg-slate-200' : 'bg-white/5 text-white/40 hover:bg-white/10')
              }`}
            >
              {m.replace('_', ' ')}
            </button>
          ))}
        </div>

        <div className="flex-grow overflow-y-auto custom-scrollbar p-4 space-y-2">
          {!isOnline && entries.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
              <div className="p-4 bg-red-500/10 rounded-full text-red-400">
                <Globe size={32} />
              </div>
              <div>
                <p className="text-sm font-bold uppercase tracking-widest text-white">You're Offline</p>
                <p className="text-[10px] font-medium text-white/40 max-w-[200px] mt-1">Global ranks are unavailable while disconnected.</p>
              </div>
            </div>
          ) : loading ? (
            <div className="space-y-2">
              {[...Array(8)].map((_, i) => (
                <div key={i} className={`flex items-center justify-between p-3 rounded-2xl border animate-pulse ${activeUnlockables.light_theme ? 'bg-slate-50 border-slate-100' : 'bg-white/5 border-white/5'}`}>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-white/10" />
                    <div className="w-8 h-8 rounded-full bg-white/10" />
                    <div className="space-y-1">
                      <div className="w-24 h-3 bg-white/10 rounded" />
                      <div className="w-16 h-2 bg-white/10 rounded" />
                    </div>
                  </div>
                  <div className="text-right space-y-1">
                    <div className="w-16 h-4 bg-white/10 rounded ml-auto" />
                    <div className="w-8 h-2 bg-white/10 rounded ml-auto" />
                  </div>
                </div>
              ))}
            </div>
          ) : entries.length > 0 ? (
            entries.map((entry, i) => (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                key={entry.id}
                className={`flex items-center justify-between p-3 rounded-2xl border transition-all ${
                  i === 0 ? 'bg-yellow-400/10 border-yellow-400/30' :
                  i === 1 ? 'bg-slate-300/10 border-slate-300/30' :
                  i === 2 ? 'bg-amber-600/10 border-amber-600/30' :
                  (activeUnlockables.light_theme ? 'bg-slate-50 border-slate-100' : 'bg-white/5 border-white/5')
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-sm ${
                    i === 0 ? 'bg-yellow-400 text-slate-900' :
                    i === 1 ? 'bg-slate-300 text-slate-900' :
                    i === 2 ? 'bg-amber-600 text-slate-900' :
                    (activeUnlockables.light_theme ? 'text-slate-400' : 'text-white/20')
                  }`}>
                    {i + 1}
                  </div>
                  <img src={entry.photoURL || ''} alt="" className="w-8 h-8 rounded-full border border-white/10" />
                  <div>
                    <p className={`text-sm font-black tracking-tight ${activeUnlockables.light_theme ? 'text-slate-900' : 'text-white'}`}>{entry.displayName}</p>
                    <p className="text-[9px] font-bold text-white/40 uppercase tracking-widest">
                      {new Date(entry.timestamp?.toDate()).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-black italic tracking-tighter text-[#00f2ff]">{entry.score.toLocaleString()}</p>
                  <p className="text-[8px] font-bold text-white/40 uppercase tracking-widest">Points</p>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="text-center py-20">
              <p className="text-xs font-bold text-white/40 uppercase tracking-widest">No scores yet for this mode</p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [adMobReady, setAdMobReady] = useState(false);
  const [view, setView] = useState<ViewState>('menu');
  const [finalScore, setFinalScore] = useState(0);
  const [highScores, setHighScores] = useState<Record<string, number>>(() => {
    const saved = localStorage.getItem('hueRingsHighScores');
    if (saved) return JSON.parse(saved);
    const oldScore = parseInt(localStorage.getItem('hueRingsHighScore') || '0');
    return { 'default': oldScore };
  });

  useEffect(() => {
    localStorage.setItem('hueRingsHighScores', JSON.stringify(highScores));
  }, [highScores]);
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>(JSON.parse(localStorage.getItem('hueRingsAchievements') || '[]'));
  const [stats, setStats] = useState<GameStats>(() => {
    const saved = localStorage.getItem('hueRingsStats');
    return saved ? JSON.parse(saved) : defaultStats;
  });
  const [showAchievements, setShowAchievements] = useState(false);
  const [screenShake, setScreenShake] = useState(() => {
    const saved = localStorage.getItem('hueRingsScreenShake');
    return saved !== 'false';
  });

  useEffect(() => {
    localStorage.setItem('hueRingsScreenShake', screenShake.toString());
  }, [screenShake]);

  const [haptics, setHaptics] = useState(() => {
    const saved = localStorage.getItem('hueRingsHaptics');
    return saved !== 'false';
  });

  useEffect(() => {
    localStorage.setItem('hueRingsHaptics', haptics.toString());
  }, [haptics]);
  
  const [activeUnlockables, setActiveUnlockables] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem('hueRingsActiveUnlockables');
    return saved ? JSON.parse(saved) : {};
  });

  const activeMode = UNLOCKABLES.find(u => u.type === 'mode' && activeUnlockables[u.id])?.id || 'default';

  useEffect(() => {
    const initAdMob = async () => {
      if (Capacitor.isNativePlatform()) {
        try {
          // Request tracking authorization for iOS
          if (Capacitor.getPlatform() === 'ios') {
            await AdMob.requestTrackingAuthorization();
          }
          
          await AdMob.initialize({
            initializeForTesting: false, // Set to false for production
          });
          setAdMobReady(true);
          console.log("AdMob Initialized");
        } catch (e) {
          console.error("AdMob Init Error", e);
        }
      }
    };
    initAdMob();
  }, []);

  useEffect(() => {
    const manageBanner = async () => {
      if (Capacitor.isNativePlatform() && adMobReady) {
        if (view === 'menu' || view === 'settings' || view === 'achievements' || view === 'leaderboard') {
          try {
            await AdMob.showBanner({
              adId: AD_IDS.banner,
              adSize: BannerAdSize.BANNER,
              position: BannerAdPosition.BOTTOM_CENTER,
              margin: 0,
            });
          } catch (e) {
            console.error("Banner Show Error", e);
          }
        } else {
          try {
            await AdMob.hideBanner();
          } catch (e) {
            console.error("Banner Hide Error", e);
          }
        }
      }
    };
    manageBanner();
  }, [view, adMobReady]);

  const showInterstitial = async () => {
    if (Capacitor.isNativePlatform() && adMobReady) {
      try {
        await AdMob.prepareInterstitial({
          adId: AD_IDS.interstitial,
        });
        await AdMob.showInterstitial();
      } catch (e) {
        console.error("Interstitial Error", e);
      }
    }
  };

  // Firebase Auth
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setIsAuthReady(true);
      if (u) {
        loadDataFromCloud(u.uid);
      }
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await signInWithPopup(auth, appleProvider);
    } catch (error: any) {
      console.error("Apple login failed:", error);
      // If the error is related to the popup being blocked or closed, we can show a more user-friendly message
      if (error.code === 'auth/popup-closed-by-user') {
        console.warn("Apple login popup closed by user.");
      } else {
        alert("Apple login failed. Please try again or use another method.");
      }
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    try {
      // Delete user data from Firestore first
      const docRef = doc(db, 'users', user.uid);
      await setDoc(docRef, { deleted: true, deletedAt: Timestamp.now() }, { merge: true });
      
      // Delete the user account from Firebase Auth
      await user.delete();
      alert("Account deleted successfully.");
    } catch (error: any) {
      console.error("Delete account failed:", error);
      if (error.code === 'auth/requires-recent-login') {
        alert("Please sign in again to delete your account.");
        await signOut(auth);
      } else {
        alert("Failed to delete account. Please try again later.");
      }
    }
  };

  const loadDataFromCloud = async (uid: string) => {
    try {
      const docRef = doc(db, 'users', uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.highScores) setHighScores(prev => ({ ...prev, ...data.highScores }));
        if (data.powerUps) {
          const savedPowerUps = JSON.parse(localStorage.getItem('hueRingsPowerUps') || '{}');
          const merged = {
            hammer: Math.max(data.powerUps.hammer || 0, savedPowerUps.hammer || 0),
            reroll: Math.max(data.powerUps.reroll || 0, savedPowerUps.reroll || 0),
            freeze: Math.max(data.powerUps.freeze || 0, savedPowerUps.freeze || 0)
          };
          localStorage.setItem('hueRingsPowerUps', JSON.stringify(merged));
        }
        if (data.unlockedAchievements) setUnlockedAchievements(prev => Array.from(new Set([...prev, ...data.unlockedAchievements])));
        if (data.activeUnlockables) setActiveUnlockables(prev => ({ ...prev, ...data.activeUnlockables }));
        if (data.stats) setStats(prev => ({ ...prev, ...data.stats }));
      }
    } catch (error) {
      console.error("Failed to load cloud data:", error);
    }
  };

  const syncDataToCloud = useCallback(async () => {
    if (!user || !isOnline) return;
    setIsSyncing(true);
    try {
      const powerUps = JSON.parse(localStorage.getItem('hueRingsPowerUps') || '{"hammer":3,"reroll":3,"freeze":3}');
      await setDoc(doc(db, 'users', user.uid), {
        uid: user.uid,
        displayName: user.displayName,
        photoURL: user.photoURL,
        highScores,
        powerUps,
        unlockedAchievements,
        activeUnlockables,
        stats,
        lastUpdated: Timestamp.now()
      }, { merge: true });
    } catch (error) {
      console.error("Failed to sync data to cloud:", error);
    } finally {
      setIsSyncing(false);
    }
  }, [user, highScores, unlockedAchievements, activeUnlockables, stats, isOnline]);

  // Sync to cloud whenever important state changes
  useEffect(() => {
    const timer = setTimeout(() => {
      syncDataToCloud();
    }, 2000); // Debounce sync
    return () => clearTimeout(timer);
  }, [highScores, unlockedAchievements, activeUnlockables, stats, syncDataToCloud]);

  const updateGlobalLeaderboard = async (mode: string, score: number) => {
    if (!user) return;
    try {
      await setDoc(doc(db, 'leaderboards', mode, 'entries', user.uid), {
        uid: user.uid,
        displayName: user.displayName,
        photoURL: user.photoURL,
        score,
        mode,
        timestamp: Timestamp.now()
      });
    } catch (error) {
      console.error("Failed to update leaderboard:", error);
    }
  };

  const toggleUnlockable = (id: string) => {
    setActiveUnlockables(prev => {
      const next = { ...prev, [id]: !prev[id] };
      const item = UNLOCKABLES.find(u => u.id === id);
      if (item?.type === 'mode' && next[id]) {
        UNLOCKABLES.filter(u => u.type === 'mode' && u.id !== id).forEach(u => next[u.id] = false);
      }
      if (item?.type === 'theme' && next[id]) {
        UNLOCKABLES.filter(u => u.type === 'theme' && u.id !== id).forEach(u => next[u.id] = false);
      }
      if (item?.type === 'style' && next[id]) {
        UNLOCKABLES.filter(u => u.type === 'style' && u.id !== id).forEach(u => next[u.id] = false);
      }
      localStorage.setItem('hueRingsActiveUnlockables', JSON.stringify(next));
      return next;
    });
  };

  const clearUnlockables = () => {
    setActiveUnlockables(prev => {
      const next = { ...prev };
      UNLOCKABLES.filter(u => u.type === 'mode' || u.type === 'theme').forEach(u => next[u.id] = false);
      localStorage.setItem('hueRingsActiveUnlockables', JSON.stringify(next));
      return next;
    });
  };

  const resetProgress = () => {
    localStorage.clear();
    window.location.reload();
  };

  const [music, setMusic] = useState(localStorage.getItem('hueRingsMusic') !== 'false');

  useEffect(() => {
    localStorage.setItem('hueRingsMusic', music.toString());
  }, [music]);

  const [sfx, setSfx] = useState(localStorage.getItem('hueRingsSfx') !== 'false');
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [showNowPlaying, setShowNowPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    localStorage.setItem('hueRingsSfx', sfx.toString());
  }, [sfx]);

  const playNextTrack = () => {
    setCurrentTrackIndex(prev => (prev + 1) % TRACKS.length);
    setShowNowPlaying(true);
    setTimeout(() => setShowNowPlaying(false), 3000);
  };

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio(TRACKS[currentTrackIndex].url);
      audioRef.current.loop = true;
      audioRef.current.volume = 0.3;
      
      audioRef.current.onended = () => {
        playNextTrack();
      };
    } else {
      // If in game, try to match track to theme
      if (view === 'game') {
        const activeTheme = Object.keys(activeUnlockables).find(key => 
          activeUnlockables[key] && TRACKS.some(t => t.theme === key)
        );
        
        if (activeTheme) {
          const themeTrackIndex = TRACKS.findIndex(t => t.theme === activeTheme);
          if (themeTrackIndex !== -1 && themeTrackIndex !== currentTrackIndex) {
            setCurrentTrackIndex(themeTrackIndex);
            audioRef.current.src = TRACKS[themeTrackIndex].url;
            audioRef.current.load();
          }
        }
      } else {
        if (audioRef.current.src !== TRACKS[currentTrackIndex].url) {
          audioRef.current.src = TRACKS[currentTrackIndex].url;
          audioRef.current.load();
        }
      }
    }
    
    if (music) {
      audioRef.current.play().catch(e => console.log("Audio play failed (autoplay restriction):", e));
    } else {
      audioRef.current.pause();
    }
    
    localStorage.setItem('hueRingsMusic', music.toString());
  }, [music, view, currentTrackIndex, activeUnlockables]);

  // Handle first interaction to start music if enabled (bypasses autoplay restrictions)
  useEffect(() => {
    const handleFirstInteraction = () => {
      if (music && audioRef.current && audioRef.current.paused) {
        audioRef.current.play().catch(e => console.log("Audio play failed:", e));
      }
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('touchstart', handleFirstInteraction);
    };
    
    window.addEventListener('click', handleFirstInteraction);
    window.addEventListener('touchstart', handleFirstInteraction);
    
    return () => {
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('touchstart', handleFirstInteraction);
    };
  }, [music, view]);

  return (
    <div className={`h-[100dvh] w-full flex flex-col overflow-hidden ${activeUnlockables.light_theme ? 'bg-slate-100 text-slate-900' : 'bg-black text-white'}`}>
      {/* Syncing Indicator */}
      <AnimatePresence>
        {isSyncing && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed bottom-safe mb-24 right-6 z-[2000] flex items-center gap-2 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 shadow-lg"
          >
            <Cloud size={14} className="text-[#00f2ff] animate-pulse" />
            <span className="text-[9px] font-black text-white uppercase tracking-widest">Syncing</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Offline Banner */}
      <AnimatePresence>
        {!isAuthReady && <SplashScreen />}
        {!isOnline && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-red-500/90 text-white text-[10px] font-black uppercase tracking-[0.2em] py-1.5 text-center z-[3000] backdrop-blur-md"
          >
            Offline Mode — Progress will sync when reconnected
          </motion.div>
        )}
      </AnimatePresence>

      {/* Now Playing Notification */}
      <AnimatePresence>
        {showNowPlaying && music && (
          <motion.div 
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 20, opacity: 1 }}
            exit={{ y: -50, opacity: 0 }}
            className="fixed top-0 left-1/2 -translate-x-1/2 z-[2000] px-4 py-2 rounded-full bg-black/80 border border-[#00f2ff]/30 backdrop-blur-md flex items-center gap-3 shadow-[0_0_20px_rgba(0,242,255,0.2)]"
          >
            <div className="size-8 rounded-full bg-gradient-to-br from-[#00f2ff] to-[#ff007f] flex items-center justify-center animate-spin-slow">
              <Video size={14} className="text-white" />
            </div>
            <div>
              <p className="text-[10px] font-black text-[#00f2ff] uppercase tracking-widest leading-none mb-1">Now Playing</p>
              <p className="text-xs font-bold text-white leading-none">{TRACKS[currentTrackIndex].name}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 relative overflow-hidden">
        <AnimatePresence mode="wait">
          {view === 'menu' && (
            <motion.div key="menu" className="absolute inset-0">
              <MenuView 
                onPlay={() => setView('game')} 
                onTutorial={() => setView('tutorial')} 
                onSettings={() => setView('settings')} 
                onAchievements={() => setView('achievements')} 
                onLeaderboard={() => setView('leaderboard')} 
                highScore={Math.max(0, ...Object.values(highScores) as number[])} 
                activeUnlockables={activeUnlockables} 
                haptics={haptics} 
                music={music} 
                setMusic={setMusic} 
                toggleUnlockable={toggleUnlockable}
                user={user}
                onLogin={handleLogin}
                onAppleLogin={handleAppleLogin}
                onLogout={handleLogout}
                onDeleteAccount={handleDeleteAccount}
                isOnline={isOnline}
              />
            </motion.div>
          )}
          {view === 'leaderboard' && (
            <motion.div 
              key="leaderboard" 
              className="absolute inset-0 z-[1000]"
              variants={slideUpVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <Leaderboard 
                onClose={() => { setView('menu'); triggerHaptic(haptics, 5); }} 
                activeUnlockables={activeUnlockables} 
                currentMode={activeMode} 
                isOnline={isOnline}
              />
            </motion.div>
          )}
          {view === 'tutorial' && (
            <motion.div 
              key="tutorial" 
              className="absolute inset-0 bg-black/40 z-10" 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => { setView('menu'); triggerHaptic(haptics, 5); }}
            >
              <motion.div 
                className="h-full w-full"
                variants={slideRightVariants}
                initial="initial"
                animate="animate"
                exit="exit"
              >
                <TutorialView onBack={() => setView('menu')} onPlay={() => setView('game')} activeUnlockables={activeUnlockables} haptics={haptics} />
              </motion.div>
            </motion.div>
          )}
          {view === 'settings' && (
            <motion.div 
              key="settings" 
              className="absolute inset-0 bg-black/40 backdrop-blur-sm z-10" 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => { setView('menu'); triggerHaptic(haptics, 5); }}
            >
              <motion.div 
                className="h-full w-full"
                variants={slideUpVariants}
                initial="initial"
                animate="animate"
                exit="exit"
              >
                <SettingsView 
                  onBack={() => setView('menu')} 
                  music={music} 
                  setMusic={setMusic} 
                  sfx={sfx} 
                  setSfx={setSfx} 
                  haptics={haptics} 
                  setHaptics={setHaptics} 
                  screenShake={screenShake} 
                  setScreenShake={setScreenShake} 
                  activeUnlockables={activeUnlockables} 
                  onResetProgress={resetProgress}
                  currentTrackIndex={currentTrackIndex}
                  playNextTrack={playNextTrack}
                />
              </motion.div>
            </motion.div>
          )}
          {view === 'achievements' && (
            <motion.div 
              key="achievements" 
              className="absolute inset-0 bg-black/40 backdrop-blur-sm z-10" 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => { setView('menu'); triggerHaptic(haptics, 5); }}
            >
              <motion.div 
                className="h-full w-full"
                variants={slideUpVariants}
                initial="initial"
                animate="animate"
                exit="exit"
              >
                <AchievementsView onBack={() => setView('menu')} unlockedIds={unlockedAchievements} activeUnlockables={activeUnlockables} stats={stats} score={0} highScore={highScores[UNLOCKABLES.find(u => u.type === 'mode' && activeUnlockables[u.id])?.id || 'default'] || 0} combo={0} toggleUnlockable={toggleUnlockable} haptics={haptics} />
              </motion.div>
            </motion.div>
          )}
          {view === 'game' && (
            <motion.div 
              key="game" 
              className="absolute inset-0" 
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <GameView 
                sfx={sfx} 
                haptics={haptics} 
                unlockedAchievements={unlockedAchievements} 
                setUnlockedAchievements={setUnlockedAchievements} 
                activeUnlockables={activeUnlockables} 
                toggleUnlockable={toggleUnlockable} 
                clearUnlockables={clearUnlockables} 
                screenShake={screenShake} 
                highScores={highScores} 
                activeMode={UNLOCKABLES.find(u => u.type === 'mode' && activeUnlockables[u.id])?.id || 'default'} 
                music={music} 
                setMusic={setMusic} 
                onGameOver={(score: number) => { 
                  setFinalScore(score); 
                  if (score > (highScores[activeMode] || 0)) { 
                    setHighScores(prev => ({ ...prev, [activeMode]: score }));
                    // Update global leaderboard if user is logged in
                    if (user) {
                      updateGlobalLeaderboard(activeMode, score);
                    }
                  } 
                  showInterstitial();
                  setView('gameover'); 
                }} 
                onHome={() => { setView('menu'); triggerHaptic(haptics, 10); }} 
                showInterstitial={showInterstitial}
                adMobReady={adMobReady}
              />
            </motion.div>
          )}
          {view === 'gameover' && (
            <motion.div 
              key="gameover" 
              className="absolute inset-0" 
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <GameOverView score={finalScore} highScore={highScores[activeMode] || 0} onPlayAgain={() => setView('game')} onHome={() => setView('menu')} activeUnlockables={activeUnlockables} haptics={haptics} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
